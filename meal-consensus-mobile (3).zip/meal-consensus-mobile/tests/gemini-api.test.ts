import { describe, it, expect } from "vitest";

describe("Gemini API Integration", () => {
  it("should validate Gemini API key format", () => {
    const apiKey = process.env.GEMINI_API_KEY;
    expect(apiKey).toBeDefined();
    expect(apiKey).toMatch(/^AQ\./); // Gemini API 키는 AQ.로 시작
    expect(apiKey?.length).toBeGreaterThan(20);
  });

  it("should construct valid Gemini API URL", () => {
    const apiKey = process.env.GEMINI_API_KEY;
    const model = "gemini-2.0-flash";
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    
    expect(url).toContain("generativelanguage.googleapis.com");
    expect(url).toContain(model);
    expect(url).toContain("key=");
  });

  it("should have valid API key structure", () => {
    const apiKey = process.env.GEMINI_API_KEY;
    // Gemini API 키는 특정 패턴을 따름
    const isValidFormat = apiKey?.startsWith("AQ.") && apiKey?.length > 50;
    expect(isValidFormat).toBe(true);
  });
});
