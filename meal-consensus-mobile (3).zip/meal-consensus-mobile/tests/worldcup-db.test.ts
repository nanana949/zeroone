import { describe, it, expect } from 'vitest';
import {
  WORLDCUP_CATEGORIES,
  getCategoryById,
  buildTournamentMenus,
} from '../lib/worldcup-db';

describe('worldcup-db', () => {
  it('카테고리가 9개여야 한다', () => {
    expect(WORLDCUP_CATEGORIES).toHaveLength(9);
  });

  it('각 카테고리에 32개 메뉴가 있어야 한다', () => {
    for (const cat of WORLDCUP_CATEGORIES) {
      expect(cat.menus).toHaveLength(32);
    }
  });

  it('카테고리 ID가 모두 고유해야 한다', () => {
    const ids = WORLDCUP_CATEGORIES.map(c => c.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });

  it('모든 메뉴에 name과 desc가 있어야 한다', () => {
    for (const cat of WORLDCUP_CATEGORIES) {
      for (const menu of cat.menus) {
        expect(menu.name).toBeTruthy();
        expect(menu.desc).toBeTruthy();
      }
    }
  });

  it('getCategoryById로 카테고리를 찾을 수 있어야 한다', () => {
    const cat = getCategoryById('korean-soup');
    expect(cat).toBeDefined();
    expect(cat?.name).toBe('한식-국물류');
  });

  it('존재하지 않는 ID는 undefined를 반환해야 한다', () => {
    expect(getCategoryById('nonexistent')).toBeUndefined();
  });

  it('buildTournamentMenus - 16강: 16개 메뉴를 반환해야 한다', () => {
    const menus = buildTournamentMenus(['korean-soup', 'chinese'], 16);
    expect(menus).toHaveLength(16);
  });

  it('buildTournamentMenus - 32강: 32개 메뉴를 반환해야 한다', () => {
    const menus = buildTournamentMenus(['korean-soup', 'chinese', 'japanese'], 32);
    expect(menus).toHaveLength(32);
  });

  it('buildTournamentMenus - 카테고리 없으면 빈 배열 반환', () => {
    const menus = buildTournamentMenus([], 16);
    expect(menus).toHaveLength(0);
  });

  it('buildTournamentMenus - 단일 카테고리에서 16개 추출 가능', () => {
    const menus = buildTournamentMenus(['pizza'], 16);
    expect(menus).toHaveLength(16);
  });

  it('buildTournamentMenus - 결과 메뉴는 선택한 카테고리 내에 있어야 한다', () => {
    const catIds = ['chicken', 'burger'];
    const allMenuNames = WORLDCUP_CATEGORIES
      .filter(c => catIds.includes(c.id))
      .flatMap(c => c.menus.map(m => m.name));
    const menus = buildTournamentMenus(catIds, 16);
    for (const menu of menus) {
      expect(allMenuNames).toContain(menu.name);
    }
  });

  it('카테고리 이름에 한식-국물류, 한식-일반식, 중식, 일식, 양식, 치킨, 햄버거, 분식, 피자가 포함되어야 한다', () => {
    const names = WORLDCUP_CATEGORIES.map(c => c.name);
    expect(names).toContain('한식-국물류');
    expect(names).toContain('한식-일반식');
    expect(names).toContain('중식');
    expect(names).toContain('일식');
    expect(names).toContain('양식');
    expect(names).toContain('치킨');
    expect(names).toContain('햄버거');
    expect(names).toContain('분식');
    expect(names).toContain('피자');
  });
});
