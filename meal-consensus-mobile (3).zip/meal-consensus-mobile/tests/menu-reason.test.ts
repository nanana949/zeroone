import { describe, it, expect } from "vitest";
import { MENU_DATABASE, filterMenus, type Menu } from "../lib/menu-db";

describe("Menu Reason Feature", () => {
  it("should have 585 menus in database", () => {
    expect(MENU_DATABASE.length).toBe(585);
  });

  it("all menus should have reason field", () => {
    const menusWithoutReason = MENU_DATABASE.filter((menu) => !menu.reason || menu.reason.trim() === "");
    expect(menusWithoutReason).toHaveLength(0);
  });

  it("reason field should not be empty", () => {
    MENU_DATABASE.forEach((menu) => {
      expect(menu.reason).toBeDefined();
      expect(menu.reason.length).toBeGreaterThan(0);
    });
  });

  it("should filter menus by category and return menus with reasons", () => {
    const koreanMenus = filterMenus("한식");
    expect(koreanMenus.length).toBeGreaterThanOrEqual(100); // 585개 중 한식이 많음
    koreanMenus.forEach((menu) => {
      expect(menu.category).toBe("한식");
      expect(menu.reason).toBeDefined();
      expect(menu.reason.length).toBeGreaterThan(0);
    });
  });

  it("should filter by budget and return menus with reasons", () => {
    const cheapMenus = filterMenus(undefined, "10,000원 이하");
    expect(cheapMenus.length).toBeGreaterThan(0);
    cheapMenus.forEach((menu) => {
      expect(menu.budget).toBe("10,000원 이하");
      expect(menu.reason).toBeDefined();
    });
  });

  it("should filter by hunger level and return menus with reasons", () => {
    const normalHunger = filterMenus(undefined, undefined, "보통");
    expect(normalHunger.length).toBeGreaterThan(0);
    normalHunger.forEach((menu) => {
      expect(menu.hunger).toBe("보통");
      expect(menu.reason).toBeDefined();
    });
  });

  it("should filter by spiciness and return menus with reasons", () => {
    const mildMenus = filterMenus(undefined, undefined, undefined, "하");
    expect(mildMenus.length).toBeGreaterThan(0);
    mildMenus.forEach((menu) => {
      expect(menu.spicy).toBe("하");
      expect(menu.reason).toBeDefined();
    });
  });

  it("should filter by multiple criteria and return menus with reasons", () => {
    const filtered = filterMenus("한식", "10,000원 이하", "보통", "중");
    filtered.forEach((menu) => {
      expect(menu.category).toBe("한식");
      expect(menu.budget).toBe("10,000원 이하");
      expect(menu.hunger).toBe("보통");
      expect(menu.spicy).toBe("중");
      expect(menu.reason).toBeDefined();
      expect(menu.reason.length).toBeGreaterThan(0);
    });
  });

  it("should have consistent menu structure with reason field", () => {
    const testMenu = MENU_DATABASE[0];
    expect(testMenu).toHaveProperty("id");
    expect(testMenu).toHaveProperty("name");
    expect(testMenu).toHaveProperty("category");
    expect(testMenu).toHaveProperty("budget");
    expect(testMenu).toHaveProperty("hunger");
    expect(testMenu).toHaveProperty("spicy");
    expect(testMenu).toHaveProperty("sideDishes");
    expect(testMenu).toHaveProperty("reason");
  });

  it("reason should contain meaningful content (not just placeholder)", () => {
    MENU_DATABASE.forEach((menu) => {
      // 추천 이유가 최소 10글자 이상이어야 함
      expect(menu.reason.length).toBeGreaterThanOrEqual(10);
      // 특수 문자나 이모지가 포함될 수 있으므로 실제 텍스트 확인
      expect(menu.reason).toMatch(/[가-힣a-zA-Z0-9]/);
    });
  });

  it("should return empty array when no menus match criteria", () => {
    // 존재하지 않는 카테고리로 필터링
    const result = filterMenus("존재하지않는카테고리" as any);
    expect(result).toHaveLength(0);
  });
});
