import { describe, it, expect } from "vitest";
import {
  analyzeAdvancedNLP,
  calculateRecommendationConfidence,
  evaluateInputQuality,
} from "../lib/advanced-nlp";

describe("Advanced NLP", () => {
  describe("analyzeAdvancedNLP", () => {
    it("피곤함 상태를 감지한다", () => {
      const result = analyzeAdvancedNLP("오늘 너무 피곤해");
      expect(result.condition).toBe("tired");
      expect(result.keywords).toContain("피곤");
      expect(result.suggestedMenus.length).toBeGreaterThan(0);
    });

    it("스트레스 상태를 감지한다", () => {
      const result = analyzeAdvancedNLP("일이 너무 많아서 스트레스받아");
      expect(result.condition).toBe("stressed");
      expect(result.suggestedMenus).toContain("매운 음식");
    });

    it("행복한 상태를 감지한다", () => {
      const result = analyzeAdvancedNLP("오늘 정말 행복해");
      expect(result.condition).toBe("happy");
      expect(result.moodScore).toBe(1);
    });

    it("슬픈 상태를 감지한다", () => {
      const result = analyzeAdvancedNLP("요즘 기분이 우울해");
      expect(result.condition).toBe("sad");
      expect(result.moodScore).toBe(-1);
    });

    it("예산을 파싱한다 (만원 단위)", () => {
      const result = analyzeAdvancedNLP("2만원 이하로 먹고 싶어");
      expect(result.budget).toBe(20000);
    });

    it("예산을 파싱한다 (천원 단위)", () => {
      const result = analyzeAdvancedNLP("8천원 정도로");
      expect(result.budget).toBe(8000);
    });

    it("건강 선호도를 감지한다", () => {
      const result = analyzeAdvancedNLP("건강하게 가볍게 먹고 싶어");
      expect(result.healthPreference).toBe("healthy");
    });

    it("푸짐한 음식 선호도를 감지한다", () => {
      const result = analyzeAdvancedNLP("배고파서 푸짐하게 먹고 싶어");
      expect(result.healthPreference).toBe("indulgent");
    });

    it("데이트 상황을 감지한다", () => {
      const result = analyzeAdvancedNLP("소개팅 첫 만남인데 어디가 좋을까");
      expect(result.condition).toBe("date");
      expect(result.suggestedMenus).toContain("분위기 좋은 카페");
    });

    it("팀 활동을 감지한다", () => {
      const result = analyzeAdvancedNLP("팀 점심 어디서 먹을까");
      expect(result.condition).toBe("teamwork");
    });

    it("항상 설명을 반환한다", () => {
      const result = analyzeAdvancedNLP("아무거나 먹고 싶어");
      expect(result.explanation).toBeTruthy();
      expect(result.explanation.length).toBeGreaterThan(0);
    });

    it("신뢰도를 계산한다", () => {
      const result = analyzeAdvancedNLP("오늘 피곤해서 2만원 이하로 가볍게 먹고 싶어");
      expect(result.confidence).toBeGreaterThan(0.5);
      expect(result.confidence).toBeLessThanOrEqual(1);
    });
  });

  describe("calculateRecommendationConfidence", () => {
    it("여러 키워드가 있으면 신뢰도가 높다", () => {
      const result1 = analyzeAdvancedNLP("피곤해");
      const result2 = analyzeAdvancedNLP("피곤하고 스트레스받고 배고파");
      const conf1 = calculateRecommendationConfidence(result1);
      const conf2 = calculateRecommendationConfidence(result2);
      expect(conf2).toBeGreaterThan(conf1);
    });

    it("예산이 있으면 신뢰도가 높다", () => {
      const result1 = analyzeAdvancedNLP("피곤해");
      const result2 = analyzeAdvancedNLP("피곤해서 1만원 이하로");
      const conf1 = calculateRecommendationConfidence(result1);
      const conf2 = calculateRecommendationConfidence(result2);
      expect(conf2).toBeGreaterThan(conf1);
    });

    it("신뢰도는 0~1 범위", () => {
      const result = analyzeAdvancedNLP("매우 길고 상세한 설명입니다. 저는 피곤하고 스트레스받고 배고프지만 건강하게 먹고 싶습니다. 예산은 15000원 이하입니다.");
      const conf = calculateRecommendationConfidence(result);
      expect(conf).toBeGreaterThanOrEqual(0);
      expect(conf).toBeLessThanOrEqual(1);
    });
  });

  describe("evaluateInputQuality", () => {
    it("짧은 입력은 poor 품질", () => {
      const result = evaluateInputQuality("먹고싶어");
      expect(result.quality).toBe("poor");
      expect(result.score).toBeLessThan(0.4);
    });

    it("중간 길이 입력은 fair 이상", () => {
      const result = evaluateInputQuality("오늘 피곤해서 뭐 먹고 싶어");
      expect(["fair", "good", "excellent"]).toContain(result.quality);
    });

    it("상세한 입력은 good 이상", () => {
      const result = evaluateInputQuality("오늘 일이 많아서 스트레스받고 피곤한데, 2만원 이하로 건강하게 먹고 싶어");
      expect(["good", "excellent"]).toContain(result.quality);
      expect(result.score).toBeGreaterThan(0.7);
    });

    it("피드백을 항상 제공한다", () => {
      const result = evaluateInputQuality("먹고싶어");
      expect(result.feedback).toBeTruthy();
      expect(result.feedback.length).toBeGreaterThan(0);
    });
  });
});
