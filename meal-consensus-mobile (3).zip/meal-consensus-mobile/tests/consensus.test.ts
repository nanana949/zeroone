import { describe, it, expect } from "vitest";
import { calculateConsensus, parseNaturalLanguage } from "../lib/consensus";
import type { GroupMember } from "../lib/store";

// ─── 합의 엔진 테스트 ──────────────────────────────────────────────────────────

describe("calculateConsensus", () => {
  it("멤버가 없으면 빈 결과를 반환한다", () => {
    const result = calculateConsensus([]);
    expect(result.recommendations).toHaveLength(0);
    expect(result.conflictMap).toHaveLength(0);
  });

  it("단일 멤버에 대해 추천을 반환한다", () => {
    const members: GroupMember[] = [
      {
        id: "1",
        name: "테스트",
        wants: ["한식"],
        avoids: [],
        maxBudget: 15000,
        maxDistance: 15,
        mood: "캐주얼",
        purpose: "점심",
      },
    ];
    const result = calculateConsensus(members);
    expect(result.recommendations.length).toBeGreaterThan(0);
  });

  it("예산 초과 메뉴는 추천하지 않는다", () => {
    const members: GroupMember[] = [
      {
        id: "1",
        name: "테스트",
        wants: [],
        avoids: [],
        maxBudget: 5000, // 매우 낮은 예산
        maxDistance: 30,
        mood: "캐주얼",
        purpose: "점심",
      },
    ];
    const result = calculateConsensus(members);
    // 모든 추천 메뉴가 예산 이하여야 함
    result.recommendations.forEach((rec) => {
      expect(rec.estimatedPrice).toBeLessThanOrEqual(5000);
    });
  });

  it("싫어하는 카테고리는 추천에서 제외된다", () => {
    const members: GroupMember[] = [
      {
        id: "1",
        name: "테스트",
        wants: [],
        avoids: ["매운"],
        maxBudget: 20000,
        maxDistance: 30,
        mood: "캐주얼",
        purpose: "점심",
      },
    ];
    const result = calculateConsensus(members);
    // 매운 메뉴 (떡볶이, 마라탕, 김치찌개)는 제외되어야 함
    const names = result.recommendations.map((r) => r.name);
    expect(names).not.toContain("떡볶이");
    expect(names).not.toContain("마라탕");
  });

  it("여러 멤버의 최소 예산을 기준으로 계산한다", () => {
    const members: GroupMember[] = [
      {
        id: "1",
        name: "A",
        wants: [],
        avoids: [],
        maxBudget: 20000,
        maxDistance: 30,
        mood: "캐주얼",
        purpose: "점심",
      },
      {
        id: "2",
        name: "B",
        wants: [],
        avoids: [],
        maxBudget: 8000, // 더 낮은 예산
        maxDistance: 30,
        mood: "캐주얼",
        purpose: "점심",
      },
    ];
    const result = calculateConsensus(members);
    // 최소 예산(8000원) 이하 메뉴만 추천
    result.recommendations.forEach((rec) => {
      expect(rec.estimatedPrice).toBeLessThanOrEqual(8000);
    });
  });

  it("최근 먹은 메뉴는 추천에서 제외된다", () => {
    const members: GroupMember[] = [
      {
        id: "1",
        name: "테스트",
        wants: [],
        avoids: [],
        maxBudget: 20000,
        maxDistance: 30,
        mood: "캐주얼",
        purpose: "점심",
      },
    ];
    const recentlyEaten = ["돈가스", "비빔밥", "라멘"];
    const result = calculateConsensus(members, recentlyEaten);
    const names = result.recommendations.map((r) => r.name);
    expect(names).not.toContain("돈가스");
    expect(names).not.toContain("비빔밥");
    expect(names).not.toContain("라멘");
  });

  it("추천 결과에 이유가 포함된다", () => {
    const members: GroupMember[] = [
      {
        id: "1",
        name: "테스트",
        wants: ["한식"],
        avoids: [],
        maxBudget: 15000,
        maxDistance: 15,
        mood: "캐주얼",
        purpose: "점심",
      },
    ];
    const result = calculateConsensus(members);
    if (result.recommendations.length > 0) {
      expect(result.recommendations[0].reasons.length).toBeGreaterThan(0);
    }
  });
});

// ─── 자연어 파싱 테스트 ────────────────────────────────────────────────────────

describe("parseNaturalLanguage", () => {
  it("피곤함 키워드를 감지한다", () => {
    const result = parseNaturalLanguage("오늘 너무 피곤해");
    expect(result.condition).toBe("tired");
    expect(result.keywords).toContain("피곤함");
  });

  it("속 예민 키워드를 감지한다", () => {
    const result = parseNaturalLanguage("속이 안 좋아서");
    expect(result.condition).toBe("sensitive_stomach");
  });

  it("예산을 파싱한다 (만원 단위)", () => {
    const result = parseNaturalLanguage("오늘 2만원 이하로 먹고 싶어");
    expect(result.budget).toBe(20000);
  });

  it("예산을 파싱한다 (천원 단위)", () => {
    const result = parseNaturalLanguage("8천원 이하로 먹을게");
    expect(result.budget).toBe(8000);
  });

  it("특별한 날 키워드를 감지한다", () => {
    const result = parseNaturalLanguage("오늘 월급날이라 특별하게 먹고 싶어");
    expect(result.suggestedMenus.length).toBeGreaterThan(0);
  });

  it("소개팅 키워드를 감지한다", () => {
    const result = parseNaturalLanguage("소개팅 첫 만남인데");
    expect(result.suggestedMenus.length).toBeGreaterThan(0);
    expect(result.explanation).toBeTruthy();
  });

  it("기분전환 키워드를 감지한다", () => {
    const result = parseNaturalLanguage("기분전환하고 싶어");
    expect(result.condition).toBe("mood_change");
  });

  it("항상 suggestedMenus를 반환한다", () => {
    const result = parseNaturalLanguage("아무거나 먹고 싶어");
    expect(result.suggestedMenus.length).toBeGreaterThan(0);
  });
});
