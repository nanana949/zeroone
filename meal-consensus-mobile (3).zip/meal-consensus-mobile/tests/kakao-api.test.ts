import { describe, it, expect } from 'vitest';

/**
 * 카카오 REST API 키 유효성 테스트
 * 실제 API 호출로 키가 올바르게 설정되었는지 확인
 */
describe('Kakao Local API', () => {
  it('KAKAO_REST_API_KEY 환경변수가 설정되어 있어야 한다', () => {
    const key = process.env.KAKAO_REST_API_KEY;
    expect(key).toBeTruthy();
    expect(key?.length).toBeGreaterThan(10);
  });

  it('카카오 로컬 API 키워드 검색이 성공해야 한다', async () => {
    const key = process.env.KAKAO_REST_API_KEY;
    if (!key) {
      console.warn('KAKAO_REST_API_KEY not set, skipping live test');
      return;
    }

    const url = new URL('https://dapi.kakao.com/v2/local/search/keyword.json');
    url.searchParams.set('query', '제육볶음');
    url.searchParams.set('x', '127.027621'); // 서울 강남 경도
    url.searchParams.set('y', '37.497952'); // 서울 강남 위도
    url.searchParams.set('radius', '2000');
    url.searchParams.set('sort', 'distance');
    url.searchParams.set('size', '5');

    const response = await fetch(url.toString(), {
      headers: { Authorization: `KakaoAK ${key}` },
    });

    expect(response.status).toBe(200);

    const data = await response.json() as { documents: unknown[]; meta: { total_count: number } };
    expect(data).toHaveProperty('documents');
    expect(data).toHaveProperty('meta');
    expect(Array.isArray(data.documents)).toBe(true);
  }, 10000);

  it('반경 2km 내 결과 없을 때 5km로 재검색 로직이 동작해야 한다', async () => {
    const key = process.env.KAKAO_REST_API_KEY;
    if (!key) return;

    // 바다 한가운데 좌표 (결과 없을 것)
    const url = new URL('https://dapi.kakao.com/v2/local/search/keyword.json');
    url.searchParams.set('query', '제육볶음');
    url.searchParams.set('x', '126.0'); // 서해 바다
    url.searchParams.set('y', '36.0');
    url.searchParams.set('radius', '2000');
    url.searchParams.set('sort', 'distance');
    url.searchParams.set('size', '5');

    const response = await fetch(url.toString(), {
      headers: { Authorization: `KakaoAK ${key}` },
    });

    expect(response.status).toBe(200);
    const data = await response.json() as { documents: unknown[] };
    // 결과가 없거나 있거나 모두 정상 응답이면 OK
    expect(Array.isArray(data.documents)).toBe(true);
  }, 10000);
});
