import { describe, it, expect } from "vitest";
import {
  calculateCategoryScores,
  FOOD_CATEGORIES,
  WEATHER_OPTIONS,
  TIME_OPTIONS,
  DAY_OPTIONS,
  CATEGORY_EMOJI,
} from "../lib/category-weights";

describe("카테고리 가중치 추천 시스템", () => {
  it("모든 카테고리가 9개여야 한다", () => {
    expect(FOOD_CATEGORIES).toHaveLength(9);
  });

  it("모든 카테고리에 이모지가 매핑되어야 한다", () => {
    for (const cat of FOOD_CATEGORIES) {
      expect(CATEGORY_EMOJI[cat]).toBeDefined();
    }
  });

  it("모두 null이면 모든 점수가 0이어야 한다", () => {
    const scores = calculateCategoryScores(null, null, null);
    expect(scores).toHaveLength(9);
    for (const s of scores) {
      expect(s.score).toBe(0);
    }
  });

  it("추운 날씨에 한식-국물류가 날씨 점수 3점을 받아야 한다", () => {
    const scores = calculateCategoryScores("추움", null, null);
    const soup = scores.find((s) => s.category === "한식-국물류");
    expect(soup!.weatherScore).toBe(3);
  });

  it("야식 시간에 치킨이 시간 점수 3점을 받아야 한다", () => {
    const scores = calculateCategoryScores(null, "야식", null);
    const chicken = scores.find((s) => s.category === "치킨");
    expect(chicken!.timeScore).toBe(3);
  });

  it("금·토 저녁에 치킨과 피자가 요일 점수 2점을 받아야 한다", () => {
    const scores = calculateCategoryScores(null, null, "금·토 저녁");
    const chicken = scores.find((s) => s.category === "치킨");
    const pizza = scores.find((s) => s.category === "피자");
    expect(chicken!.dayScore).toBe(2);
    expect(pizza!.dayScore).toBe(2);
  });

  it("추움 + 아침 → 한식-국물류가 1위(5점)여야 한다", () => {
    const scores = calculateCategoryScores("추움", "아침", null);
    expect(scores[0].category).toBe("한식-국물류");
    expect(scores[0].score).toBe(5);
  });

  it("맑음·선선 + 야식 + 금·토 저녁 → 치킨이 1위(7점)여야 한다", () => {
    const scores = calculateCategoryScores("맑음·선선", "야식", "금·토 저녁");
    const chicken = scores.find((s) => s.category === "치킨");
    expect(chicken!.score).toBe(7);
    expect(scores[0].category).toBe("치킨");
  });

  it("결과가 점수 내림차순으로 정렬되어야 한다", () => {
    const scores = calculateCategoryScores("추움", "점심", "평일");
    for (let i = 0; i < scores.length - 1; i++) {
      expect(scores[i].score).toBeGreaterThanOrEqual(scores[i + 1].score);
    }
  });

  it("날씨 옵션이 4개여야 한다", () => {
    expect(WEATHER_OPTIONS).toHaveLength(4);
  });

  it("시간대 옵션이 4개여야 한다", () => {
    expect(TIME_OPTIONS).toHaveLength(4);
  });

  it("요일 옵션이 2개여야 한다", () => {
    expect(DAY_OPTIONS).toHaveLength(2);
  });
});
