import { MENU_DATABASE, type MenuOption } from "./consensus";

// ─── 사용자 상황 분석 ──────────────────────────────────────────────────────────

export interface UserContext {
  mood: "happy" | "tired" | "sad" | "stressed" | "neutral";
  energy: number; // 1-5 (낮음-높음)
  appetite: number; // 1-5 (적음-많음)
  budget: "low" | "medium" | "high";
  isHungry: boolean;
  wantSpicy: boolean;
  wantHeavy: boolean;
  wantHealthy: boolean;
  occasion: "lunch" | "dinner" | "snack" | "special" | "casual";
  timeAvailable: "quick" | "normal" | "plenty";
  companions: "alone" | "friend" | "family" | "date" | "team";
}

// ─── 자연어 분석 ──────────────────────────────────────────────────────────────

export function analyzeUserInput(input: string): UserContext {
  const lowerInput = input.toLowerCase();

  // 기분 분석
  let mood: UserContext["mood"] = "neutral";
  if (
    lowerInput.includes("행복") ||
    lowerInput.includes("좋아") ||
    lowerInput.includes("신남")
  ) {
    mood = "happy";
  } else if (
    lowerInput.includes("피곤") ||
    lowerInput.includes("졸려") ||
    lowerInput.includes("힘들어")
  ) {
    mood = "tired";
  } else if (
    lowerInput.includes("슬픔") ||
    lowerInput.includes("우울") ||
    lowerInput.includes("속상")
  ) {
    mood = "sad";
  } else if (
    lowerInput.includes("스트레스") ||
    lowerInput.includes("화남") ||
    lowerInput.includes("짜증")
  ) {
    mood = "stressed";
  }

  // 에너지 레벨 분석
  let energy = 3;
  if (lowerInput.includes("피곤") || lowerInput.includes("지쳤")) energy = 1;
  else if (lowerInput.includes("조금 피곤")) energy = 2;
  else if (lowerInput.includes("활기") || lowerInput.includes("신나")) energy = 5;
  else if (lowerInput.includes("괜찮")) energy = 4;

  // 배고픔 분석
  let appetite = 3;
  if (
    lowerInput.includes("배고파") ||
    lowerInput.includes("엄청 먹고") ||
    lowerInput.includes("든든하게")
  )
    appetite = 5;
  else if (lowerInput.includes("조금") || lowerInput.includes("가볍게"))
    appetite = 1;
  else if (lowerInput.includes("보통")) appetite = 3;

  // 예산 분석
  let budget: UserContext["budget"] = "medium";
  if (
    lowerInput.includes("저렴") ||
    lowerInput.includes("싸게") ||
    lowerInput.includes("5천") ||
    lowerInput.includes("6천")
  )
    budget = "low";
  else if (
    lowerInput.includes("비싼") ||
    lowerInput.includes("2만") ||
    lowerInput.includes("3만") ||
    lowerInput.includes("특별")
  )
    budget = "high";

  // 맵기 선호도
  const wantSpicy =
    lowerInput.includes("맵") ||
    lowerInput.includes("자극") ||
    lowerInput.includes("매운");

  // 무거움 선호도
  const wantHeavy =
    lowerInput.includes("든든") ||
    lowerInput.includes("푸짐") ||
    lowerInput.includes("고기");

  // 건강식 선호도
  const wantHealthy =
    lowerInput.includes("건강") ||
    lowerInput.includes("다이어트") ||
    lowerInput.includes("가벼운");

  // 배고픔 여부
  const isHungry = appetite >= 4;

  // 시간 여유
  let timeAvailable: UserContext["timeAvailable"] = "normal";
  if (
    lowerInput.includes("빨리") ||
    lowerInput.includes("빠르게") ||
    lowerInput.includes("10분")
  )
    timeAvailable = "quick";
  else if (
    lowerInput.includes("충분") ||
    lowerInput.includes("여유") ||
    lowerInput.includes("천천히")
  )
    timeAvailable = "plenty";

  // 함께할 사람
  let companions: UserContext["companions"] = "alone";
  if (
    lowerInput.includes("친구") ||
    lowerInput.includes("동료") ||
    lowerInput.includes("팀")
  )
    companions = "friend";
  else if (lowerInput.includes("가족")) companions = "family";
  else if (
    lowerInput.includes("데이트") ||
    lowerInput.includes("연인") ||
    lowerInput.includes("소개팅")
  )
    companions = "date";
  else if (lowerInput.includes("회식")) companions = "team";

  // 상황 분석
  let occasion: UserContext["occasion"] = "casual";
  if (
    lowerInput.includes("점심") ||
    lowerInput.includes("오전") ||
    lowerInput.includes("12시")
  )
    occasion = "lunch";
  else if (
    lowerInput.includes("저녁") ||
    lowerInput.includes("저녁 먹") ||
    lowerInput.includes("6시")
  )
    occasion = "dinner";
  else if (
    lowerInput.includes("간식") ||
    lowerInput.includes("카페") ||
    lowerInput.includes("디저트")
  )
    occasion = "snack";
  else if (
    lowerInput.includes("특별") ||
    lowerInput.includes("기념") ||
    lowerInput.includes("월급날")
  )
    occasion = "special";

  return {
    mood,
    energy,
    appetite,
    budget,
    isHungry,
    wantSpicy,
    wantHeavy,
    wantHealthy,
    occasion,
    timeAvailable,
    companions,
  };
}

// ─── 메뉴 추천 엔진 ──────────────────────────────────────────────────────────

export function recommendMenus(context: UserContext): MenuOption[] {
  let scores = MENU_DATABASE.map((menu) => ({
    menu,
    score: 0,
  }));

  // 기분에 따른 점수
  if (context.mood === "tired") {
    // 피곤할 때: 든든하고 따뜻한 음식
    scores = scores.map((item) => ({
      ...item,
      score:
        item.score +
        (item.menu.tags.includes("국물") ? 3 : 0) +
        (item.menu.oilyLevel >= 2 ? 2 : 0),
    }));
  } else if (context.mood === "happy") {
    // 행복할 때: 특별한 음식
    scores = scores.map((item) => ({
      ...item,
      score:
        item.score +
        (item.menu.purposes.includes("특별한날") ? 3 : 0) +
        (item.menu.atmosphere.includes("고급") ? 2 : 0),
    }));
  } else if (context.mood === "stressed") {
    // 스트레스: 자극적인 음식
    scores = scores.map((item) => ({
      ...item,
      score:
        item.score +
        (item.menu.spicyLevel >= 3 ? 3 : 0) +
        (item.menu.tags.includes("자극") ? 2 : 0),
    }));
  }

  // 에너지 레벨에 따른 점수
  if (context.energy <= 2) {
    // 피곤함: 가벼운 음식
    scores = scores.map((item) => ({
      ...item,
      score:
        item.score + (item.menu.oilyLevel <= 2 ? 2 : 0) + (item.menu.isSafe ? 1 : 0),
    }));
  } else if (context.energy >= 4) {
    // 활기참: 푸짐한 음식
    scores = scores.map((item) => ({
      ...item,
      score:
        item.score +
        (item.menu.purposes.includes("점심") ? 1 : 0) +
        (item.menu.tags.includes("고기") ? 2 : 0),
    }));
  }

  // 배고픔에 따른 점수
  if (context.isHungry) {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.avgPrice >= 10000 ? 2 : 0),
    }));
  } else {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.avgPrice <= 8000 ? 2 : 0),
    }));
  }

  // 맵기 선호도
  if (context.wantSpicy) {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + item.menu.spicyLevel * 0.5,
    }));
  } else {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.spicyLevel <= 2 ? 1 : 0),
    }));
  }

  // 무거움 선호도
  if (context.wantHeavy) {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.oilyLevel >= 3 ? 2 : 0),
    }));
  } else if (context.wantHealthy) {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.oilyLevel <= 2 ? 2 : 0),
    }));
  }

  // 예산에 따른 점수
  if (context.budget === "low") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.avgPrice <= 7000 ? 3 : 0),
    }));
  } else if (context.budget === "high") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.avgPrice >= 15000 ? 2 : 0),
    }));
  }

  // 상황에 따른 점수
  if (context.occasion === "lunch") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.purposes.includes("점심") ? 2 : 0),
    }));
  } else if (context.occasion === "dinner") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.purposes.includes("저녁") ? 2 : 0),
    }));
  } else if (context.occasion === "special") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.purposes.includes("특별한날") ? 3 : 0),
    }));
  }

  // 동반자에 따른 점수
  if (context.companions === "date") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.atmosphere.includes("데이트") ? 3 : 0),
    }));
  } else if (context.companions === "team") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.purposes.includes("회식") ? 2 : 0),
    }));
  }

  // 시간 여유에 따른 점수
  if (context.timeAvailable === "quick") {
    scores = scores.map((item) => ({
      ...item,
      score: item.score + (item.menu.avgDistance <= 5 ? 2 : 0),
    }));
  }

  // 점수가 높은 순서로 정렬
  return scores
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((item) => item.menu);
}

// ─── 추천 설명 생성 ──────────────────────────────────────────────────────────

export function generateRecommendationExplanation(
  menu: MenuOption,
  context: UserContext
): string {
  let explanation = `${menu.name}을(를) 추천합니다!\n\n`;

  // 기분 기반 설명
  if (context.mood === "tired") {
    explanation += `피곤한 당신을 위해 ${menu.tags.includes("국물") ? "따뜻한 국물로 몸을 데워주고" : "든든하게"} 에너지를 충전할 수 있는 메뉴를 골랐어요.\n`;
  } else if (context.mood === "happy") {
    explanation += `행복한 기분을 더욱 특별하게 만들어줄 메뉴예요!\n`;
  } else if (context.mood === "stressed") {
    explanation += `스트레스를 풀어줄 자극적인 맛의 메뉴를 추천합니다.\n`;
  }

  // 특징 설명
  explanation += `\n특징:\n`;
  explanation += `• 가격: ${menu.avgPrice.toLocaleString()}원\n`;
  explanation += `• 맵기: ${"🌶️".repeat(menu.spicyLevel)}${"☆".repeat(5 - menu.spicyLevel)}\n`;
  explanation += `• 무거움: ${"🍖".repeat(Math.min(menu.oilyLevel, 5))}${"☆".repeat(Math.max(5 - menu.oilyLevel, 0))}\n`;

  // 상황 기반 추가 설명
  if (context.isHungry) {
    explanation += `\n배고픈 당신을 위해 푸짐한 양의 메뉴를 골랐어요!`;
  } else {
    explanation += `\n가볍게 즐길 수 있는 메뉴입니다.`;
  }

  return explanation;
}
