// ─── 합의 모드 데이터 및 알고리즘 ─────────────────────────────────

export type FoodCategory =
  | "한식-일반식"
  | "한식-국물류"
  | "치킨"
  | "분식"
  | "중식"
  | "피자"
  | "일식"
  | "햄버거"
  | "양식";

// ─── 취향 프로필 ──────────────────────────────────────────────────
export interface TasteProfile {
  name: string; // 참여자 이름 (예: "나", "친구1")
  spicy: "못먹음" | "약간" | "보통" | "매운거좋아"; // 매운맛 선호도
  meat: "좋아함" | "상관없음" | "채식선호"; // 고기 선호도
  categories: FoodCategory[]; // 선호 카테고리 (복수 선택)
  budget: "5천원이하" | "1만원이하" | "1만5천원이하" | "상관없음"; // 예산
  avoid: string[]; // 절대 안 되는 메뉴 이름 목록
}

// ─── 메뉴 데이터 (속성 태그 포함) ────────────────────────────────
export interface ConsensusMenu {
  id: number;
  name: string;
  category: FoodCategory;
  tags: Record<string, string>; // 카테고리별 속성 태그
  spicyLevel: 0 | 1 | 2 | 3; // 0=안매움, 1=약간, 2=보통, 3=매움
  hasMeat: boolean;
  priceRange: "저렴" | "보통" | "비쌈"; // 저렴=5천이하, 보통=1만이하, 비쌈=1만5천이상
}

// ─── 메뉴 DB (카테고리별 속성 태그 포함) ─────────────────────────
export const CONSENSUS_MENUS: ConsensusMenu[] = [
  // 한식-일반식 (45개)
  { id: 1, name: "비빔밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "채소", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 1, hasMeat: false, priceRange: "저렴" },
  { id: 2, name: "육회비빔밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "고기", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 1, hasMeat: true, priceRange: "보통" },
  { id: 3, name: "산채비빔밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "채소", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 4, name: "돌솥비빔밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "채소", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 1, hasMeat: false, priceRange: "저렴" },
  { id: 5, name: "제육볶음", category: "한식-일반식", tags: { 형태: "볶음", 주재료: "고기", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 2, hasMeat: true, priceRange: "저렴" },
  { id: 6, name: "닭갈비", category: "한식-일반식", tags: { 형태: "볶음", 주재료: "고기", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 2, hasMeat: true, priceRange: "보통" },
  { id: 7, name: "불고기덮밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "고기", 맛: "단짠", 구성: "한그릇식사" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 8, name: "오징어덮밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "해물", 맛: "매콤함", 구성: "한그릇식사" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 9, name: "참치마요덮밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "해물", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 10, name: "계란덮밥", category: "한식-일반식", tags: { 형태: "비빔덮밥", 주재료: "계란·채소", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 11, name: "삼겹살", category: "한식-일반식", tags: { 형태: "구이", 주재료: "고기", 맛: "삼삼함", 구성: "밥+반찬" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 12, name: "목살구이", category: "한식-일반식", tags: { 형태: "구이", 주재료: "고기", 맛: "삼삼함", 구성: "밥+반찬" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 13, name: "소불고기", category: "한식-일반식", tags: { 형태: "볶음", 주재료: "고기", 맛: "단짠", 구성: "밥+반찬" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 14, name: "닭볶음탕", category: "한식-일반식", tags: { 형태: "볶음", 주재료: "고기", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 2, hasMeat: true, priceRange: "보통" },
  { id: 15, name: "두부조림", category: "한식-일반식", tags: { 형태: "조림", 주재료: "계란·채소", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 1, hasMeat: false, priceRange: "저렴" },
  { id: 16, name: "감자조림", category: "한식-일반식", tags: { 형태: "조림", 주재료: "계란·채소", 맛: "단짠", 구성: "밥+반찬" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 17, name: "고등어조림", category: "한식-일반식", tags: { 형태: "조림", 주재료: "해물", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 1, hasMeat: false, priceRange: "저렴" },
  { id: 18, name: "갈치조림", category: "한식-일반식", tags: { 형태: "조림", 주재료: "해물", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 1, hasMeat: false, priceRange: "보통" },
  { id: 19, name: "순두부찌개", category: "한식-일반식", tags: { 형태: "찌개", 주재료: "계란·채소", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 20, name: "된장찌개정식", category: "한식-일반식", tags: { 형태: "찌개", 주재료: "계란·채소", 맛: "삼삼함", 구성: "밥+반찬" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 21, name: "김치볶음밥", category: "한식-일반식", tags: { 형태: "볶음밥", 주재료: "계란·채소", 맛: "매콤함", 구성: "한그릇식사" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 22, name: "새우볶음밥", category: "한식-일반식", tags: { 형태: "볶음밥", 주재료: "해물", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 23, name: "베이컨볶음밥", category: "한식-일반식", tags: { 형태: "볶음밥", 주재료: "고기", 맛: "삼삼함", 구성: "한그릇식사" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 24, name: "낙지볶음", category: "한식-일반식", tags: { 형태: "볶음", 주재료: "해물", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 3, hasMeat: false, priceRange: "보통" },
  { id: 25, name: "쭈꾸미볶음", category: "한식-일반식", tags: { 형태: "볶음", 주재료: "해물", 맛: "매콤함", 구성: "밥+반찬" }, spicyLevel: 3, hasMeat: false, priceRange: "보통" },

  // 한식-국물류 (40개)
  { id: 101, name: "김치찌개", category: "한식-국물류", tags: { 맛강도: "칼칼", 주재료: "채소·두부", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 102, name: "된장찌개", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "채소·두부", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 103, name: "부대찌개", category: "한식-국물류", tags: { 맛강도: "칼칼", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 2, hasMeat: true, priceRange: "보통" },
  { id: 104, name: "순두부찌개", category: "한식-국물류", tags: { 맛강도: "칼칼", 주재료: "채소·두부", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 105, name: "청국장", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "채소·두부", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 106, name: "갈비탕", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "고기", 국물진하기: "맑은국물", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 107, name: "설렁탕", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 108, name: "곰탕", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 109, name: "육개장", category: "한식-국물류", tags: { 맛강도: "얼큰", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 3, hasMeat: true, priceRange: "보통" },
  { id: 110, name: "해장국", category: "한식-국물류", tags: { 맛강도: "얼큰", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 2, hasMeat: true, priceRange: "보통" },
  { id: 111, name: "순댓국", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 112, name: "돼지국밥", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "고기", 국물진하기: "진한육수", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 113, name: "삼계탕", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "고기", 국물진하기: "진한육수", 계절감: "보양식" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 114, name: "미역국", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "해물", 국물진하기: "맑은국물", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 115, name: "콩나물국", category: "한식-국물류", tags: { 맛강도: "담백", 주재료: "채소·두부", 국물진하기: "맑은국물", 계절감: "뜨끈한국물" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },

  // 치킨 (40개)
  { id: 201, name: "후라이드치킨", category: "치킨", tags: { 맛: "후라이드", 부위: "뼈있는", 조리법: "튀김", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 202, name: "후라이드순살", category: "치킨", tags: { 맛: "후라이드", 부위: "순살", 조리법: "튀김", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 203, name: "양념치킨", category: "치킨", tags: { 맛: "양념", 부위: "뼈있는", 조리법: "튀김", 구성: "단품" }, spicyLevel: 1, hasMeat: true, priceRange: "보통" },
  { id: 204, name: "양념순살", category: "치킨", tags: { 맛: "양념", 부위: "순살", 조리법: "튀김", 구성: "단품" }, spicyLevel: 1, hasMeat: true, priceRange: "보통" },
  { id: 205, name: "간장치킨", category: "치킨", tags: { 맛: "간장", 부위: "뼈있는", 조리법: "튀김", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 206, name: "마늘치킨", category: "치킨", tags: { 맛: "마늘", 부위: "뼈있는", 조리법: "튀김", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 207, name: "불닭", category: "치킨", tags: { 맛: "매운", 부위: "순살", 조리법: "볶음", 구성: "단품" }, spicyLevel: 3, hasMeat: true, priceRange: "보통" },
  { id: 208, name: "파닭", category: "치킨", tags: { 맛: "후라이드", 부위: "뼈있는", 조리법: "튀김", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 209, name: "치킨버거세트", category: "치킨", tags: { 맛: "후라이드", 부위: "순살", 조리법: "튀김", 구성: "세트" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 210, name: "치킨+피자콤보", category: "치킨", tags: { 맛: "후라이드", 부위: "뼈있는", 조리법: "튀김", 구성: "콤보" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },

  // 분식 (35개)
  { id: 301, name: "떡볶이", category: "분식", tags: { 메인: "떡볶이", 맛강도: "보통맛", 국물유무: "볶음형", 구성: "단품" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 302, name: "국물떡볶이", category: "분식", tags: { 메인: "떡볶이", 맛강도: "보통맛", 국물유무: "국물형", 구성: "단품" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 303, name: "로제떡볶이", category: "분식", tags: { 메인: "떡볶이", 맛강도: "순한맛", 국물유무: "볶음형", 구성: "단품" }, spicyLevel: 1, hasMeat: false, priceRange: "저렴" },
  { id: 304, name: "마라떡볶이", category: "분식", tags: { 메인: "떡볶이", 맛강도: "매운맛", 국물유무: "볶음형", 구성: "단품" }, spicyLevel: 3, hasMeat: false, priceRange: "저렴" },
  { id: 305, name: "라볶이", category: "분식", tags: { 메인: "떡볶이", 맛강도: "보통맛", 국물유무: "국물형", 구성: "단품" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 306, name: "순대", category: "분식", tags: { 메인: "순대", 맛강도: "순한맛", 국물유무: "없음", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 307, name: "튀김", category: "분식", tags: { 메인: "튀김", 맛강도: "순한맛", 국물유무: "없음", 구성: "단품" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 308, name: "김밥", category: "분식", tags: { 메인: "김밥", 맛강도: "순한맛", 국물유무: "없음", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 309, name: "참치김밥", category: "분식", tags: { 메인: "김밥", 맛강도: "순한맛", 국물유무: "없음", 구성: "단품" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 310, name: "치즈김밥", category: "분식", tags: { 메인: "김밥", 맛강도: "순한맛", 국물유무: "없음", 구성: "단품" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },

  // 중식 (35개)
  { id: 401, name: "짜장면", category: "중식", tags: { 형태: "면", 맛강도: "단짠", 조리법: "볶음", 재료: "채소두부" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 402, name: "짬뽕", category: "중식", tags: { 형태: "면", 맛강도: "얼큰", 조리법: "볶음", 재료: "해물" }, spicyLevel: 3, hasMeat: false, priceRange: "저렴" },
  { id: 403, name: "탕수육", category: "중식", tags: { 형태: "튀김", 맛강도: "단짠", 조리법: "튀김", 재료: "고기" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 404, name: "마파두부", category: "중식", tags: { 형태: "볶음", 맛강도: "얼큰", 조리법: "볶음", 재료: "채소두부" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 405, name: "마라탕", category: "중식", tags: { 형태: "탕", 맛강도: "마라", 조리법: "탕", 재료: "채소두부" }, spicyLevel: 3, hasMeat: false, priceRange: "보통" },
  { id: 406, name: "마라샹궈", category: "중식", tags: { 형태: "볶음", 맛강도: "마라", 조리법: "볶음", 재료: "채소두부" }, spicyLevel: 3, hasMeat: false, priceRange: "보통" },
  { id: 407, name: "짬뽕밥", category: "중식", tags: { 형태: "밥", 맛강도: "얼큰", 조리법: "볶음", 재료: "해물" }, spicyLevel: 2, hasMeat: false, priceRange: "저렴" },
  { id: 408, name: "볶음밥", category: "중식", tags: { 형태: "밥", 맛강도: "단짠", 조리법: "볶음", 재료: "채소두부" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
  { id: 409, name: "깐풍기", category: "중식", tags: { 형태: "튀김", 맛강도: "단짠", 조리법: "튀김", 재료: "고기" }, spicyLevel: 1, hasMeat: true, priceRange: "보통" },
  { id: 410, name: "유린기", category: "중식", tags: { 형태: "튀김", 맛강도: "단짠", 조리법: "튀김", 재료: "고기" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },

  // 피자 (30개)
  { id: 501, name: "페퍼로니피자(씬)", category: "피자", tags: { 토핑: "고기", 도우: "씬", 맛: "기본", 구성: "라지단일" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 502, name: "페퍼로니피자(팬)", category: "피자", tags: { 토핑: "고기", 도우: "팬", 맛: "기본", 구성: "라지단일" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 503, name: "치즈피자", category: "피자", tags: { 토핑: "치즈", 도우: "씬", 맛: "치즈크리미", 구성: "라지단일" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },
  { id: 504, name: "불고기피자", category: "피자", tags: { 토핑: "고기", 도우: "팬", 맛: "단짠", 구성: "라지단일" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 505, name: "새우피자", category: "피자", tags: { 토핑: "해물", 도우: "씬", 맛: "기본", 구성: "라지단일" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },
  { id: 506, name: "콤비네이션피자", category: "피자", tags: { 토핑: "고기", 도우: "팬", 맛: "기본", 구성: "라지단일" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 507, name: "고구마피자", category: "피자", tags: { 토핑: "채소", 도우: "팬", 맛: "달콤", 구성: "라지단일" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },
  { id: 508, name: "포테이토피자", category: "피자", tags: { 토핑: "채소", 도우: "팬", 맛: "치즈크리미", 구성: "라지단일" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },
  { id: 509, name: "하프앤하프", category: "피자", tags: { 토핑: "고기", 도우: "씬", 맛: "기본", 구성: "하프앤하프" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 510, name: "마르게리타", category: "피자", tags: { 토핑: "치즈", 도우: "씬", 맛: "기본", 구성: "라지단일" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },

  // 일식 (30개)
  { id: 601, name: "초밥세트", category: "일식", tags: { 형태: "초밥회", 온도: "차가운", 국물유무: "없음", 맛: "담백" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },
  { id: 602, name: "사시미모듬", category: "일식", tags: { 형태: "초밥회", 온도: "차가운", 국물유무: "없음", 맛: "담백" }, spicyLevel: 0, hasMeat: false, priceRange: "비쌈" },
  { id: 603, name: "라멘", category: "일식", tags: { 형태: "면", 온도: "뜨거운", 국물유무: "있음", 맛: "진한육수" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 604, name: "쇼유라멘", category: "일식", tags: { 형태: "면", 온도: "뜨거운", 국물유무: "있음", 맛: "담백" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 605, name: "돈코츠라멘", category: "일식", tags: { 형태: "면", 온도: "뜨거운", 국물유무: "있음", 맛: "진한육수" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 606, name: "카레라이스", category: "일식", tags: { 형태: "밥", 온도: "뜨거운", 국물유무: "있음", 맛: "단짠" }, spicyLevel: 1, hasMeat: true, priceRange: "저렴" },
  { id: 607, name: "돈카츠", category: "일식", tags: { 형태: "튀김", 온도: "뜨거운", 국물유무: "없음", 맛: "담백" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 608, name: "규동", category: "일식", tags: { 형태: "덮밥", 온도: "뜨거운", 국물유무: "없음", 맛: "단짠" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 609, name: "오야코동", category: "일식", tags: { 형태: "덮밥", 온도: "뜨거운", 국물유무: "없음", 맛: "담백" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 610, name: "우동", category: "일식", tags: { 형태: "면", 온도: "뜨거운", 국물유무: "있음", 맛: "담백" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },

  // 햄버거 (25개)
  { id: 701, name: "기본버거", category: "햄버거", tags: { 패티: "소고기", 맛: "기본", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 702, name: "치즈버거", category: "햄버거", tags: { 패티: "소고기", 맛: "치즈크리미", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 703, name: "더블패티버거", category: "햄버거", tags: { 패티: "소고기", 맛: "기본", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 704, name: "치킨버거", category: "햄버거", tags: { 패티: "닭고기", 맛: "기본", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 705, name: "스파이시버거", category: "햄버거", tags: { 패티: "닭고기", 맛: "매운", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 2, hasMeat: true, priceRange: "저렴" },
  { id: 706, name: "베이컨버거", category: "햄버거", tags: { 패티: "소고기", 맛: "스모키", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 707, name: "버거세트", category: "햄버거", tags: { 패티: "소고기", 맛: "기본", 빵종류: "일반번", 구성: "세트" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 708, name: "쉑쉑버거", category: "햄버거", tags: { 패티: "소고기", 맛: "기본", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 709, name: "빅맥", category: "햄버거", tags: { 패티: "소고기", 맛: "기본", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 710, name: "와퍼", category: "햄버거", tags: { 패티: "소고기", 맛: "스모키", 빵종류: "일반번", 구성: "단품" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },

  // 양식 (20개)
  { id: 801, name: "토마토파스타", category: "양식", tags: { 종류: "파스타", 소스: "토마토", 재료: "채소", 상황: "든든하게" }, spicyLevel: 0, hasMeat: false, priceRange: "보통" },
  { id: 802, name: "크림파스타", category: "양식", tags: { 종류: "파스타", 소스: "크림", 재료: "고기", 상황: "든든하게" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 803, name: "알리오올리오", category: "양식", tags: { 종류: "파스타", 소스: "오일", 재료: "채소", 상황: "가볍게" }, spicyLevel: 1, hasMeat: false, priceRange: "보통" },
  { id: 804, name: "까르보나라", category: "양식", tags: { 종류: "파스타", 소스: "크림", 재료: "고기", 상황: "든든하게" }, spicyLevel: 0, hasMeat: true, priceRange: "보통" },
  { id: 805, name: "스테이크", category: "양식", tags: { 종류: "메인요리", 소스: "기타", 재료: "고기", 상황: "특별한날" }, spicyLevel: 0, hasMeat: true, priceRange: "비쌈" },
  { id: 806, name: "리조또", category: "양식", tags: { 종류: "밥요리", 소스: "크림", 재료: "채소", 상황: "든든하게" }, spicyLevel: 0, hasMeat: false, priceRange: "보통" },
  { id: 807, name: "그라탱", category: "양식", tags: { 종류: "오븐요리", 소스: "크림", 재료: "채소", 상황: "든든하게" }, spicyLevel: 0, hasMeat: false, priceRange: "보통" },
  { id: 808, name: "샐러드", category: "양식", tags: { 종류: "샐러드", 소스: "드레싱", 재료: "채소", 상황: "가볍게" }, spicyLevel: 0, hasMeat: false, priceRange: "보통" },
  { id: 809, name: "클럽샌드위치", category: "양식", tags: { 종류: "샌드위치", 소스: "마요", 재료: "고기", 상황: "가볍게" }, spicyLevel: 0, hasMeat: true, priceRange: "저렴" },
  { id: 810, name: "수프+빵", category: "양식", tags: { 종류: "수프", 소스: "크림", 재료: "채소", 상황: "가볍게" }, spicyLevel: 0, hasMeat: false, priceRange: "저렴" },
];

// ─── 취향 매칭 알고리즘 ───────────────────────────────────────────

/** 매운맛 레벨 매핑 */
const SPICY_LEVEL_MAP: Record<TasteProfile["spicy"], number> = {
  "못먹음": 0,
  "약간": 1,
  "보통": 2,
  "매운거좋아": 3,
};

/** 예산 레벨 매핑 */
const BUDGET_LEVEL_MAP: Record<TasteProfile["budget"], number> = {
  "5천원이하": 0,
  "1만원이하": 1,
  "1만5천원이하": 2,
  "상관없음": 3,
};

const PRICE_LEVEL_MAP: Record<ConsensusMenu["priceRange"], number> = {
  "저렴": 0,
  "보통": 1,
  "비쌈": 2,
};

export interface MatchResult {
  menu: ConsensusMenu;
  score: number; // 0~100
  satisfactionBreakdown: {
    participant: string;
    score: number;
    reasons: string[];
  }[];
}

/**
 * 그룹 취향 매칭 알고리즘
 * 각 메뉴에 대해 모든 참여자의 만족도를 계산하고 평균을 반환
 */
export function calculateGroupMatch(
  menus: ConsensusMenu[],
  profiles: TasteProfile[],
): MatchResult[] {
  return menus
    .map((menu) => {
      const breakdown = profiles.map((profile) => {
        let score = 60; // 기본 점수
        const reasons: string[] = [];

        // 1. 거부 메뉴 체크
        if (profile.avoid.includes(menu.name)) {
          return { participant: profile.name, score: 0, reasons: ["절대 안 됨"] };
        }

        // 2. 카테고리 선호도
        if (profile.categories.includes(menu.category)) {
          score += 20;
          reasons.push("선호 카테고리");
        } else if (profile.categories.length > 0) {
          score -= 10;
        }

        // 3. 매운맛 체크
        const maxSpicy = SPICY_LEVEL_MAP[profile.spicy];
        if (menu.spicyLevel > maxSpicy) {
          const diff = menu.spicyLevel - maxSpicy;
          score -= diff * 20;
          reasons.push(`매운맛 초과 (${menu.spicyLevel > 2 ? "많이" : "약간"})`);
        } else if (profile.spicy === "매운거좋아" && menu.spicyLevel >= 2) {
          score += 10;
          reasons.push("매운맛 선호");
        }

        // 4. 고기 선호도
        if (profile.meat === "채식선호" && menu.hasMeat) {
          score -= 15;
          reasons.push("채식 선호");
        } else if (profile.meat === "좋아함" && menu.hasMeat) {
          score += 5;
          reasons.push("고기 선호");
        }

        // 5. 예산 체크
        const budgetLevel = BUDGET_LEVEL_MAP[profile.budget];
        const priceLevel = PRICE_LEVEL_MAP[menu.priceRange];
        if (budgetLevel !== 3 && priceLevel > budgetLevel) {
          score -= (priceLevel - budgetLevel) * 15;
          reasons.push("예산 초과");
        }

        score = Math.max(0, Math.min(100, score));
        if (score >= 70) reasons.push("적합");

        return { participant: profile.name, score, reasons };
      });

      // 전체 만족도: 가장 낮은 점수를 가중치로 반영 (모두가 싫어하지 않아야 함)
      const scores = breakdown.map((b) => b.score);
      const minScore = Math.min(...scores);
      const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;

      // 최솟값 40% + 평균 60% 가중 합산
      const finalScore = Math.round(minScore * 0.4 + avgScore * 0.6);

      return { menu, score: finalScore, satisfactionBreakdown: breakdown };
    })
    .filter((r) => r.score > 0) // 거부 메뉴 완전 제외
    .sort((a, b) => b.score - a.score);
}

/** 카테고리별 메뉴 필터링 */
export function getMenusByCategory(category: FoodCategory): ConsensusMenu[] {
  return CONSENSUS_MENUS.filter((m) => m.category === category);
}

/** 모든 메뉴 반환 */
export function getAllMenus(): ConsensusMenu[] {
  return CONSENSUS_MENUS;
}

export const CATEGORIES: FoodCategory[] = [
  "한식-일반식", "한식-국물류", "치킨", "분식", "중식", "피자", "일식", "햄버거", "양식"
];

export const CATEGORY_EMOJIS: Record<FoodCategory, string> = {
  "한식-일반식": "🍚",
  "한식-국물류": "🍲",
  "치킨": "🍗",
  "분식": "🥢",
  "중식": "🥡",
  "피자": "🍕",
  "일식": "🍜",
  "햄버거": "🍔",
  "양식": "🍝",
};
