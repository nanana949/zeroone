import type { GroupMember, RecommendationItem, ConflictItem, RecommendationTag } from "./store";

// ─── 메뉴 데이터베이스 ──────────────────────────────────────────────────────────

export interface MenuOption {
  id: string;
  name: string;
  category: string;
  tags: string[];
  avgPrice: number;
  avgDistance: number;
  spicyLevel: number;       // 0-5
  oilyLevel: number;        // 0-5
  isNew: boolean;
  isSafe: boolean;
  atmosphere: string[];
  purposes: string[];
}

export const MENU_DATABASE: MenuOption[] = [
  {
    id: "1",
    name: "돈가스",
    category: "일식",
    tags: ["고기", "튀김", "무난"],
    avgPrice: 10000,
    avgDistance: 5,
    spicyLevel: 0,
    oilyLevel: 3,
    isNew: false,
    isSafe: true,
    atmosphere: ["캐주얼", "혼밥", "점심"],
    purposes: ["점심", "혼밥", "팀식사"],
  },
  {
    id: "2",
    name: "파스타",
    category: "이탈리안",
    tags: ["면", "서양식", "분위기"],
    avgPrice: 14000,
    avgDistance: 8,
    spicyLevel: 1,
    oilyLevel: 2,
    isNew: false,
    isSafe: true,
    atmosphere: ["캐주얼", "데이트", "저녁"],
    purposes: ["데이트", "저녁", "특별한날"],
  },
  {
    id: "3",
    name: "샤브샤브",
    category: "일식",
    tags: ["고기", "채소", "건강"],
    avgPrice: 18000,
    avgDistance: 10,
    spicyLevel: 1,
    oilyLevel: 1,
    isNew: false,
    isSafe: true,
    atmosphere: ["고급", "단체", "저녁"],
    purposes: ["회식", "가족", "특별한날"],
  },
  {
    id: "4",
    name: "김치찌개",
    category: "한식",
    tags: ["국물", "한식", "매운"],
    avgPrice: 9000,
    avgDistance: 3,
    spicyLevel: 4,
    oilyLevel: 2,
    isNew: false,
    isSafe: true,
    atmosphere: ["서민적", "혼밥", "점심"],
    purposes: ["점심", "혼밥", "팀식사"],
  },
  {
    id: "5",
    name: "초밥",
    category: "일식",
    tags: ["해산물", "신선", "고급"],
    avgPrice: 20000,
    avgDistance: 12,
    spicyLevel: 0,
    oilyLevel: 1,
    isNew: false,
    isSafe: false,
    atmosphere: ["고급", "데이트", "저녁"],
    purposes: ["데이트", "특별한날", "저녁"],
  },
  {
    id: "6",
    name: "떡볶이",
    category: "분식",
    tags: ["분식", "매운", "저렴"],
    avgPrice: 6000,
    avgDistance: 2,
    spicyLevel: 4,
    oilyLevel: 2,
    isNew: false,
    isSafe: true,
    atmosphere: ["서민적", "간식", "혼밥"],
    purposes: ["간식", "혼밥", "점심"],
  },
  {
    id: "7",
    name: "삼겹살",
    category: "한식",
    tags: ["고기", "술안주", "회식"],
    avgPrice: 16000,
    avgDistance: 7,
    spicyLevel: 1,
    oilyLevel: 4,
    isNew: false,
    isSafe: true,
    atmosphere: ["캐주얼", "회식", "저녁"],
    purposes: ["회식", "저녁", "술자리"],
  },
  {
    id: "8",
    name: "마라탕",
    category: "중식",
    tags: ["매운", "중식", "트렌디"],
    avgPrice: 13000,
    avgDistance: 9,
    spicyLevel: 5,
    oilyLevel: 3,
    isNew: true,
    isSafe: false,
    atmosphere: ["트렌디", "혼밥", "점심"],
    purposes: ["점심", "혼밥", "도전"],
  },
  {
    id: "9",
    name: "비빔밥",
    category: "한식",
    tags: ["건강", "채소", "한식"],
    avgPrice: 10000,
    avgDistance: 4,
    spicyLevel: 2,
    oilyLevel: 1,
    isNew: false,
    isSafe: true,
    atmosphere: ["건강", "혼밥", "점심"],
    purposes: ["점심", "혼밥", "건강식"],
  },
  {
    id: "10",
    name: "스테이크",
    category: "양식",
    tags: ["고기", "고급", "서양식"],
    avgPrice: 35000,
    avgDistance: 15,
    spicyLevel: 0,
    oilyLevel: 3,
    isNew: false,
    isSafe: false,
    atmosphere: ["고급", "데이트", "저녁"],
    purposes: ["특별한날", "데이트", "저녁"],
  },
  {
    id: "11",
    name: "라멘",
    category: "일식",
    tags: ["면", "국물", "일식"],
    avgPrice: 12000,
    avgDistance: 6,
    spicyLevel: 2,
    oilyLevel: 3,
    isNew: false,
    isSafe: true,
    atmosphere: ["캐주얼", "혼밥", "점심"],
    purposes: ["점심", "혼밥", "저녁"],
  },
  {
    id: "12",
    name: "피자",
    category: "양식",
    tags: ["서양식", "단체", "배달"],
    avgPrice: 18000,
    avgDistance: 10,
    spicyLevel: 1,
    oilyLevel: 3,
    isNew: false,
    isSafe: true,
    atmosphere: ["캐주얼", "단체", "저녁"],
    purposes: ["회식", "가족", "파티"],
  },
];

// ─── 합의 알고리즘 ─────────────────────────────────────────────────────────────

export function calculateConsensus(
  members: GroupMember[],
  recentlyEaten: string[] = []
): { recommendations: RecommendationItem[]; conflictMap: ConflictItem[] } {
  if (members.length === 0) {
    return { recommendations: [], conflictMap: [] };
  }

  const maxBudget = Math.min(...members.map((m) => m.maxBudget));
  const maxDistance = Math.min(...members.map((m) => m.maxDistance));

  // 모든 멤버의 싫어하는 것 합집합
  const allAvoids = new Set(members.flatMap((m) => m.avoids));
  // 모든 멤버의 원하는 것
  const allWants = members.flatMap((m) => m.wants);

  const scored: Array<{ menu: MenuOption; score: number; reasons: string[]; tags: RecommendationTag[] }> = [];

  for (const menu of MENU_DATABASE) {
    // 최근 먹은 메뉴 제외
    if (recentlyEaten.includes(menu.name) || recentlyEaten.includes(menu.category)) {
      continue;
    }

    // 예산 초과 제외
    if (menu.avgPrice > maxBudget) {
      continue;
    }

    // 거리 초과 제외
    if (menu.avgDistance > maxDistance) {
      continue;
    }

    let score = 50;
    const reasons: string[] = [];
    const tags: RecommendationTag[] = [];

    // 싫어하는 것 체크 (태그 기반)
    let hasConflict = false;
    for (const avoid of allAvoids) {
      if (
        menu.tags.some((t) => t.includes(avoid)) ||
        menu.category.includes(avoid) ||
        menu.name.includes(avoid)
      ) {
        hasConflict = true;
        break;
      }
    }
    if (hasConflict) continue;

    // 원하는 것 매칭
    let wantMatches = 0;
    for (const want of allWants) {
      if (
        menu.tags.some((t) => t.includes(want)) ||
        menu.category.includes(want) ||
        menu.name.includes(want)
      ) {
        wantMatches++;
        score += 10;
      }
    }

    if (wantMatches > 0) {
      const uniqueWants = [...new Set(allWants.filter(w =>
        menu.tags.some(t => t.includes(w)) || menu.category.includes(w) || menu.name.includes(w)
      ))];
      reasons.push(`${members.length}명 중 ${Math.min(wantMatches, members.length)}명이 선호하는 카테고리`);
    }

    // 예산 여유
    const budgetRatio = menu.avgPrice / maxBudget;
    if (budgetRatio <= 0.7) {
      score += 15;
      reasons.push(`예산 ${maxBudget.toLocaleString()}원 이하 충족 (${menu.avgPrice.toLocaleString()}원)`);
      tags.push("best_value");
    } else {
      reasons.push(`예산 ${maxBudget.toLocaleString()}원 이하 충족`);
    }

    // 거리
    if (menu.avgDistance <= maxDistance * 0.6) {
      score += 10;
      reasons.push(`도보 ${menu.avgDistance}분 거리 (기준 ${maxDistance}분 이내)`);
    } else {
      reasons.push(`도보 약 ${menu.avgDistance}분 거리`);
    }

    // 안전한 선택
    if (menu.isSafe) {
      score += 5;
      tags.push("safe_choice");
    }

    // 새로운 경험
    if (menu.isNew) {
      score += 8;
      tags.push("new_experience");
    }

    // 그룹 합의 태그
    if (members.length > 1) {
      tags.push("team_consensus");
      reasons.push(`${members.length}명 모두 수용 가능한 타협안`);
    }

    // 혼잡도 (시뮬레이션)
    const hour = new Date().getHours();
    if (hour >= 12 && hour <= 13) {
      reasons.push("현재 시간대 혼잡 예상 — 빠른 결정 추천");
    } else {
      reasons.push("현재 시간대 혼잡도 낮음");
    }

    scored.push({ menu, score, reasons, tags });
  }

  // 점수 순 정렬
  scored.sort((a, b) => b.score - a.score);

  const recommendations: RecommendationItem[] = scored.slice(0, 5).map((item, idx) => ({
    id: item.menu.id,
    name: item.menu.name,
    category: item.menu.category,
    reasons: item.reasons,
    tags: item.tags,
    estimatedPrice: item.menu.avgPrice,
    estimatedDistance: item.menu.avgDistance,
    score: item.score,
    planBOptions: scored
      .filter((s) => s.menu.id !== item.menu.id)
      .slice(0, 2)
      .map((s) => s.menu.name),
  }));

  // 충돌 맵 생성
  const conflictMap: ConflictItem[] = MENU_DATABASE.slice(0, 8).map((menu) => {
    let okCount = 0;
    for (const member of members) {
      const memberAvoids = member.avoids;
      const hasConflict = memberAvoids.some(
        (a) => menu.tags.includes(a) || menu.category.includes(a) || menu.name.includes(a)
      );
      const budgetOk = menu.avgPrice <= member.maxBudget;
      const distanceOk = menu.avgDistance <= member.maxDistance;
      if (!hasConflict && budgetOk && distanceOk) {
        okCount++;
      }
    }

    const ratio = members.length > 0 ? okCount / members.length : 0;
    let status: ConflictItem["status"] = "conflict";
    if (ratio === 1) status = "all_ok";
    else if (ratio >= 0.7) status = "mostly_ok";
    else if (menu.avgPrice > maxBudget) status = "budget_over";

    return {
      menuName: menu.name,
      status,
      okCount,
      totalCount: members.length,
    };
  });

  return { recommendations, conflictMap };
}

// ─── 컨디션 기반 추천 ──────────────────────────────────────────────────────────

export type ConditionType =
  | "tired"
  | "sensitive_stomach"
  | "want_filling"
  | "mood_change"
  | "want_drink"
  | "light_meal";

export interface ConditionRecommendation {
  condition: ConditionType;
  label: string;
  emoji: string;
  menuSuggestions: string[];
  avoidTags: string[];
  preferTags: string[];
  message: string;
}

export const CONDITION_RECOMMENDATIONS: ConditionRecommendation[] = [
  {
    condition: "tired",
    label: "피곤함",
    emoji: "😴",
    menuSuggestions: ["삼겹살", "갈비탕", "순대국"],
    avoidTags: ["매운", "자극적"],
    preferTags: ["든든", "국물", "고기"],
    message: "피곤할 때는 든든한 국물 요리나 고기가 원기 회복에 좋아요.",
  },
  {
    condition: "sensitive_stomach",
    label: "속이 예민함",
    emoji: "🤢",
    menuSuggestions: ["죽", "비빔밥", "샤브샤브"],
    avoidTags: ["매운", "느끼한", "튀김"],
    preferTags: ["건강", "채소", "담백"],
    message: "속이 예민할 때는 자극적이지 않은 담백한 음식이 좋아요.",
  },
  {
    condition: "want_filling",
    label: "든든하게",
    emoji: "💪",
    menuSuggestions: ["삼겹살", "돈가스", "피자"],
    avoidTags: ["가벼운", "샐러드"],
    preferTags: ["고기", "든든", "포만감"],
    message: "든든하게 먹고 싶을 때는 고기류나 탄수화물이 풍부한 메뉴를 추천해요.",
  },
  {
    condition: "mood_change",
    label: "기분전환",
    emoji: "✨",
    menuSuggestions: ["마라탕", "타코", "태국음식"],
    avoidTags: ["무난", "익숙한"],
    preferTags: ["새로운", "트렌디", "이색"],
    message: "기분전환에는 평소에 잘 안 먹던 새로운 음식을 도전해보세요!",
  },
  {
    condition: "want_drink",
    label: "술이 땡김",
    emoji: "🍺",
    menuSuggestions: ["삼겹살", "치킨", "회"],
    avoidTags: ["건강식", "다이어트"],
    preferTags: ["술안주", "고기", "해산물"],
    message: "술자리에는 삼겹살, 치킨, 회 같은 안주류가 잘 어울려요.",
  },
  {
    condition: "light_meal",
    label: "가볍게",
    emoji: "🥗",
    menuSuggestions: ["샐러드", "샌드위치", "죽"],
    avoidTags: ["느끼한", "고기", "튀김"],
    preferTags: ["건강", "가벼운", "채소"],
    message: "가볍게 먹고 싶을 때는 샐러드나 죽 같은 가벼운 메뉴를 추천해요.",
  },
];

export function getConditionRecommendation(condition: ConditionType): ConditionRecommendation {
  return CONDITION_RECOMMENDATIONS.find((c) => c.condition === condition)!;
}

// ─── 자연어 파싱 ───────────────────────────────────────────────────────────────

export function parseNaturalLanguage(input: string): {
  condition?: ConditionType;
  budget?: number;
  keywords: string[];
  suggestedMenus: string[];
  explanation: string;
} {
  const lower = input.toLowerCase();
  const keywords: string[] = [];
  let condition: ConditionType | undefined;
  let budget: number | undefined;
  let suggestedMenus: string[] = [];
  let explanation = "";

  // 컨디션 감지
  if (lower.includes("피곤") || lower.includes("힘들")) {
    condition = "tired";
    keywords.push("피곤함");
  } else if (lower.includes("속") && (lower.includes("예민") || lower.includes("안좋") || lower.includes("안 좋") || lower.includes("아파"))) {
    condition = "sensitive_stomach";
    keywords.push("속 예민");
  } else if (lower.includes("든든") || lower.includes("배고파") || lower.includes("많이")) {
    condition = "want_filling";
    keywords.push("든든하게");
  } else if (lower.includes("기분전환") || lower.includes("새로운") || lower.includes("색다른")) {
    condition = "mood_change";
    keywords.push("기분전환");
  } else if (lower.includes("술") || lower.includes("한잔")) {
    condition = "want_drink";
    keywords.push("술자리");
  } else if (lower.includes("가볍") || lower.includes("다이어트") || lower.includes("건강")) {
    condition = "light_meal";
    keywords.push("가벼운 식사");
  }

  // 예산 감지
  const budgetMatch = lower.match(/(\d+)(만원|만 원|천원|천 원)/);
  if (budgetMatch) {
    const amount = parseInt(budgetMatch[1]);
    if (budgetMatch[2].includes("만")) {
      budget = amount * 10000;
    } else {
      budget = amount * 1000;
    }
    keywords.push(`예산 ${budget.toLocaleString()}원`);
  }

  // 특수 상황 감지
  if (lower.includes("월급날") || lower.includes("특별") || lower.includes("기념")) {
    keywords.push("특별한 날");
    suggestedMenus = ["스테이크", "초밥", "샤브샤브"];
    explanation = "특별한 날에는 평소보다 조금 특별한 메뉴를 즐겨보세요.";
  } else if (lower.includes("팀장") || lower.includes("상사") || lower.includes("무난")) {
    keywords.push("무난한 선택");
    suggestedMenus = ["한정식", "삼겹살", "돈가스"];
    explanation = "상사와 함께하는 자리에는 모두가 무난하게 즐길 수 있는 메뉴가 좋아요.";
  } else if (lower.includes("소개팅") || lower.includes("첫만남") || lower.includes("데이트")) {
    keywords.push("데이트");
    suggestedMenus = ["파스타", "초밥", "샤브샤브"];
    explanation = "소개팅이나 첫 만남에는 대화하기 좋은 분위기의 레스토랑을 추천해요.";
  } else if (condition) {
    const rec = getConditionRecommendation(condition);
    suggestedMenus = rec.menuSuggestions;
    explanation = rec.message;
  } else {
    suggestedMenus = ["돈가스", "비빔밥", "파스타"];
    explanation = "오늘 기분에 맞는 메뉴를 골라봤어요.";
  }

  return { condition, budget, keywords, suggestedMenus, explanation };
}
