/**
 * 고도화된 자연어 처리 (NLP) 유틸리티
 * 사용자의 입력을 분석하여 더 정확한 추천을 제공합니다.
 */

export interface AdvancedNLPResult {
  condition: string;
  budget?: number;
  keywords: string[];
  suggestedMenus: string[];
  explanation: string;
  confidence: number; // 0-1
  moodScore: number; // -1 (나쁨) ~ 1 (좋음)
  healthPreference: "normal" | "healthy" | "indulgent";
}

const CONDITION_KEYWORDS = {
  tired: ["피곤", "힘들", "지쳐", "무기력", "늘어져"],
  stressed: ["스트레스", "답답", "화나", "짜증", "우울"],
  happy: ["행복", "기분좋", "신나", "즐거", "신청"],
  sad: ["슬프", "우울", "외로", "힘들", "괴로"],
  excited: ["신나", "들뜨", "신청", "기대", "설렘"],
  bored: ["심심", "지루", "재미없", "따분"],
  sick: ["아파", "감기", "소화", "속", "구역"],
  hungry: ["배고파", "든든", "많이", "푸짐", "배부"],
  lazy: ["귀찮", "간편", "빠르게", "쉽게"],
  celebration: ["축하", "기념", "특별", "월급", "생일", "합격", "승진"],
  date: ["데이트", "소개팅", "만남", "첫", "인상"],
  teamwork: ["팀", "회의", "팀점심", "단체", "함께"],
};

const BUDGET_PATTERNS = [
  { regex: /(\d+)\s*만\s*원\s*(이하|이내|정도)/g, multiplier: 10000 },
  { regex: /(\d+)\s*천\s*원\s*(이하|이내|정도)/g, multiplier: 1000 },
  { regex: /(\d+)\s*원\s*(이하|이내|정도)/g, multiplier: 1 },
];

const MENU_SUGGESTIONS = {
  tired: ["국밥", "우동", "카페", "스무디", "죽"],
  stressed: ["매운 음식", "고기", "피자", "라면", "카레"],
  happy: ["고급 레스토랑", "스테이크", "와인바", "일식", "프렌치"],
  sad: ["위로 음식", "국밥", "떡볶이", "라면", "치킨"],
  excited: ["새로운 메뉴", "이국적 음식", "핫플레이스", "뷔페"],
  bored: ["새로운 맛", "도전 메뉴", "이색 음식", "트렌디한 카페"],
  sick: ["죽", "미역국", "소화 잘되는 음식", "따뜻한 국"],
  hungry: ["고기", "뷔페", "푸짐한 한정식", "돈가스", "스테이크"],
  lazy: ["배달", "편의점", "분식", "테이크아웃", "간편식"],
  celebration: ["고급 레스토랑", "특식", "와인", "스테이크", "일식"],
  date: ["분위기 좋은 카페", "이탈리안", "일식", "와인바", "루프탑"],
  teamwork: ["한식당", "회식", "고기", "보쌈", "한정식"],
};

export function analyzeAdvancedNLP(input: string): AdvancedNLPResult {
  const lower = input.toLowerCase();
  let condition = "normal";
  let moodScore = 0;
  let healthPreference: "normal" | "healthy" | "indulgent" = "normal";
  const keywords: string[] = [];
  let budget: number | undefined;
  let confidence = 0.5;

  // 컨디션 감지
  for (const [cond, words] of Object.entries(CONDITION_KEYWORDS)) {
    for (const word of words) {
      if (lower.includes(word)) {
        condition = cond;
        keywords.push(word);
        confidence = Math.min(1, confidence + 0.2);
        break;
      }
    }
  }

  // 기분 점수 계산
  if (
    ["happy", "excited", "celebration", "date"].includes(condition)
  ) {
    moodScore = 1;
  } else if (["sad", "stressed", "bored"].includes(condition)) {
    moodScore = -1;
  } else if (["tired", "lazy"].includes(condition)) {
    moodScore = -0.5;
  }

  // 건강 선호도 감지
  if (
    lower.includes("건강") ||
    lower.includes("다이어트") ||
    lower.includes("가볍") ||
    lower.includes("샐러드") ||
    lower.includes("채소")
  ) {
    healthPreference = "healthy";
    keywords.push("건강식");
  } else if (
    lower.includes("푸짐") ||
    lower.includes("든든") ||
    lower.includes("배부") ||
    lower.includes("고기") ||
    lower.includes("뷔페")
  ) {
    healthPreference = "indulgent";
    keywords.push("푸짐함");
  }

  // 예산 파싱
  for (const pattern of BUDGET_PATTERNS) {
    const match = lower.match(pattern.regex);
    if (match) {
      const amount = parseInt(match[0]);
      budget = amount * pattern.multiplier;
      keywords.push(`예산: ${budget}원`);
      confidence = Math.min(1, confidence + 0.15);
      break;
    }
  }

  // 추천 메뉴 생성
  const suggestedMenus = MENU_SUGGESTIONS[condition as keyof typeof MENU_SUGGESTIONS] || [
    "한식",
    "분식",
    "일식",
  ];

  // 설명 생성
  const explanation = generateExplanation(condition, healthPreference, budget);

  return {
    condition,
    budget,
    keywords,
    suggestedMenus,
    explanation,
    confidence,
    moodScore,
    healthPreference,
  };
}

function generateExplanation(
  condition: string,
  healthPreference: string,
  budget?: number
): string {
  const explanations: Record<string, string> = {
    tired: "피곤할 때는 가볍고 따뜻한 음식이 좋습니다. 국밥이나 우동을 추천해요.",
    stressed: "스트레스받을 때는 자극적인 맛이 도움됩니다. 매운 음식이나 고기를 시도해보세요.",
    happy: "좋은 기분을 더 살리려면 분위기 좋은 고급 음식점을 추천합니다.",
    sad: "기분이 안 좋을 때는 위로가 되는 음식이 최고입니다. 국밥이나 떡볶이 어때요?",
    excited: "신나는 기분을 유지하려면 새로운 메뉴에 도전해보세요!",
    bored: "지루함을 깨려면 평소와 다른 이색 음식을 시도해보세요.",
    sick: "소화가 잘되는 따뜻한 음식을 추천합니다. 죽이나 미역국이 좋아요.",
    hungry: "배고플 때는 푸짐한 음식이 최고! 고기나 뷔페를 추천합니다.",
    lazy: "귀찮을 때는 배달이나 편의점 음식이 편합니다.",
    celebration: "특별한 날이군요! 고급 레스토랑에서 특식을 즐겨보세요.",
    date: "좋은 인상을 주려면 분위기 좋은 곳을 선택하세요. 이탈리안이나 일식 추천!",
    teamwork: "팀 활동이군요! 함께 즐길 수 있는 한식당이나 고기 구워먹는 곳 추천합니다.",
    normal: "당신의 취향에 맞는 메뉴를 추천해드리겠습니다.",
  };

  let base = explanations[condition] || explanations.normal;

  if (healthPreference === "healthy") {
    base += " 건강을 생각해서 가벼운 옵션을 추천해요.";
  } else if (healthPreference === "indulgent") {
    base += " 푸짐하게 즐길 수 있는 메뉴를 추천합니다.";
  }

  if (budget) {
    base += ` 예산은 ${budget.toLocaleString()}원 이내로 추천해드릴게요.`;
  }

  return base;
}

/**
 * 사용자 입력 기반 추천 신뢰도 계산
 * 더 많은 정보가 있을수록 신뢰도가 높음
 */
export function calculateRecommendationConfidence(
  result: AdvancedNLPResult
): number {
  let confidence = result.confidence;

  // 여러 키워드가 감지되면 신뢰도 증가
  if (result.keywords.length > 2) confidence += 0.1;

  // 예산이 지정되면 신뢰도 증가
  if (result.budget) confidence += 0.1;

  // 건강 선호도가 명확하면 신뢰도 증가
  if (result.healthPreference !== "normal") confidence += 0.05;

  return Math.min(1, confidence);
}

/**
 * 입력 텍스트의 품질 평가
 */
export function evaluateInputQuality(input: string): {
  quality: "poor" | "fair" | "good" | "excellent";
  score: number;
  feedback: string;
} {
  const length = input.length;
  const hasKeywords = Object.values(CONDITION_KEYWORDS).some((words) =>
    words.some((word) => input.includes(word))
  );
  const hasBudget = BUDGET_PATTERNS.some((p) => p.regex.test(input));

  let score = 0;
  let feedback = "";

  if (length < 5) {
    score = 0.2;
    feedback = "더 자세히 설명해주시면 더 정확한 추천을 드릴 수 있습니다.";
  } else if (length < 20) {
    score = 0.5;
    feedback = "기분이나 예산을 추가로 알려주시면 더 좋습니다.";
  } else if (length < 50) {
    score = 0.75;
    feedback = "좋은 정보입니다!";
  } else {
    score = 0.95;
    feedback = "매우 상세한 정보 감사합니다!";
  }

  if (hasKeywords) score += 0.1;
  if (hasBudget) score += 0.1;

  score = Math.min(1, score);

  const quality: "poor" | "fair" | "good" | "excellent" =
    score < 0.4 ? "poor" : score < 0.6 ? "fair" : score < 0.8 ? "good" : "excellent";

  return { quality, score, feedback };
}
