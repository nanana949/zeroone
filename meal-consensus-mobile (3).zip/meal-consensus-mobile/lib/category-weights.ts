/**
 * 카테고리 추천 가중치 시스템
 * 날씨, 시간대, 요일에 따라 각 카테고리의 점수를 계산하여 추천
 */

export type FoodCategory =
  | "한식-국물류"
  | "한식-일반식"
  | "중식"
  | "일식"
  | "양식"
  | "치킨"
  | "햄버거"
  | "분식"
  | "피자";

export type WeatherType = "더움" | "추움" | "비·눈" | "맑음·선선";
export type TimeSlot = "아침" | "점심" | "저녁" | "야식";
export type DayType = "평일" | "금·토 저녁";

export const FOOD_CATEGORIES: FoodCategory[] = [
  "한식-국물류",
  "한식-일반식",
  "중식",
  "일식",
  "양식",
  "치킨",
  "햄버거",
  "분식",
  "피자",
];

export const WEATHER_OPTIONS: WeatherType[] = ["더움", "추움", "비·눈", "맑음·선선"];
export const TIME_OPTIONS: TimeSlot[] = ["아침", "점심", "저녁", "야식"];
export const DAY_OPTIONS: DayType[] = ["평일", "금·토 저녁"];

// 날씨별 가중치
const WEATHER_WEIGHTS: Record<FoodCategory, Record<WeatherType, number>> = {
  "한식-국물류": { "더움": -2, "추움": 3, "비·눈": 3, "맑음·선선": 0 },
  "한식-일반식": { "더움": 0, "추움": 1, "비·눈": 0, "맑음·선선": 1 },
  "중식": { "더움": -1, "추움": 2, "비·눈": 1, "맑음·선선": 0 },
  "일식": { "더움": -1, "추움": 1, "비·눈": 0, "맑음·선선": 1 },
  "양식": { "더움": 0, "추움": 0, "비·눈": 0, "맑음·선선": 1 },
  "치킨": { "더움": 1, "추움": 0, "비·눈": 1, "맑음·선선": 2 },
  "햄버거": { "더움": 1, "추움": -1, "비·눈": 0, "맑음·선선": 1 },
  "분식": { "더움": -1, "추움": 1, "비·눈": 1, "맑음·선선": 0 },
  "피자": { "더움": 0, "추움": 0, "비·눈": 1, "맑음·선선": 1 },
};

// 시간대별 가중치
const TIME_WEIGHTS: Record<FoodCategory, Record<TimeSlot, number>> = {
  "한식-국물류": { "아침": 2, "점심": 2, "저녁": 1, "야식": 0 },
  "한식-일반식": { "아침": 0, "점심": 2, "저녁": 1, "야식": 0 },
  "중식": { "아침": -1, "점심": 2, "저녁": 1, "야식": 1 },
  "일식": { "아침": 0, "점심": 1, "저녁": 2, "야식": 0 },
  "양식": { "아침": 1, "점심": 1, "저녁": 2, "야식": 0 },
  "치킨": { "아침": -2, "점심": -1, "저녁": 1, "야식": 3 },
  "햄버거": { "아침": -1, "점심": 1, "저녁": 1, "야식": 1 },
  "분식": { "아침": 0, "점심": 2, "저녁": 1, "야식": 2 },
  "피자": { "아침": -2, "점심": 0, "저녁": 1, "야식": 2 },
};

// 요일별 가중치
const DAY_WEIGHTS: Record<FoodCategory, Record<DayType, number>> = {
  "한식-국물류": { "평일": 0, "금·토 저녁": 0 },
  "한식-일반식": { "평일": 0, "금·토 저녁": 0 },
  "중식": { "평일": 0, "금·토 저녁": 1 },
  "일식": { "평일": 0, "금·토 저녁": 0 },
  "양식": { "평일": 0, "금·토 저녁": 0 },
  "치킨": { "평일": 0, "금·토 저녁": 2 },
  "햄버거": { "평일": 0, "금·토 저녁": 0 },
  "분식": { "평일": 0, "금·토 저녁": 0 },
  "피자": { "평일": 0, "금·토 저녁": 2 },
};

export interface CategoryScore {
  category: FoodCategory;
  score: number;
  weatherScore: number;
  timeScore: number;
  dayScore: number;
}

export function calculateCategoryScores(
  weather: WeatherType | null,
  time: TimeSlot | null,
  day: DayType | null
): CategoryScore[] {
  const scores: CategoryScore[] = FOOD_CATEGORIES.map((category) => {
    const weatherScore = weather ? WEATHER_WEIGHTS[category][weather] : 0;
    const timeScore = time ? TIME_WEIGHTS[category][time] : 0;
    const dayScore = day ? DAY_WEIGHTS[category][day] : 0;
    return {
      category,
      score: weatherScore + timeScore + dayScore,
      weatherScore,
      timeScore,
      dayScore,
    };
  });
  return scores.sort((a, b) => b.score - a.score);
}

export const CATEGORY_EMOJI: Record<FoodCategory, string> = {
  "한식-국물류": "🍲",
  "한식-일반식": "🍚",
  "중식": "🥟",
  "일식": "🍣",
  "양식": "🍝",
  "치킨": "🍗",
  "햄버거": "🍔",
  "분식": "🍢",
  "피자": "🍕",
};

export const WEATHER_EMOJI: Record<WeatherType, string> = {
  "더움": "☀️",
  "추움": "❄️",
  "비·눈": "🌧️",
  "맑음·선선": "🌤️",
};

export const TIME_EMOJI: Record<TimeSlot, string> = {
  "아침": "🌅",
  "점심": "☀️",
  "저녁": "🌆",
  "야식": "🌙",
};

export const DAY_EMOJI: Record<DayType, string> = {
  "평일": "📅",
  "금·토 저녁": "🎉",
};
