import AsyncStorage from "@react-native-async-storage/async-storage";

// ─── Types ────────────────────────────────────────────────────────────────────

export type SpicyLevel = 1 | 2 | 3 | 4 | 5;
export type PriceLevel = 1 | 2 | 3 | 4 | 5;

export interface TasteDNA {
  spicyTolerance: SpicyLevel;       // 맵기 민감도 (1=매우 민감, 5=매운 거 좋아함)
  oilyTolerance: number;            // 느끼함 허용도 (1-5)
  adventurousness: number;          // 도전 성향 (1=안전, 5=모험)
  familiarPreference: number;       // 익숙한 메뉴 선호 (1-5)
  fullnessFirst: boolean;           // 배부름 우선 vs 분위기 우선
  priceSensitivity: PriceLevel;     // 가격 민감도 (1=매우 민감, 5=상관없음)
  healthFirst: boolean;             // 건강 우선 여부
}

export type RelationshipType = "solo" | "couple" | "team" | "family";

export interface RelationshipProfile {
  type: RelationshipType;
  label: string;
  emoji: string;
  favoriteCategories: string[];
  avoidCategories: string[];
  budgetPerPerson: number;
}

export interface MealRecord {
  id: string;
  date: string;                     // ISO date string
  menuName: string;
  category: string;
  restaurantName?: string;
  rating?: number;                  // 1-5
  withWhom: RelationshipType;
  pricePerPerson?: number;
  notes?: string;
  review?: MealReview;              // 식사 후기
}

export interface MealReview {
  rating: number;                   // 1-5점
  taste: number;                    // 맛 (1-5)
  quantity: number;                 // 양 (1-5)
  price: number;                    // 가성비 (1-5)
  atmosphere: number;               // 분위기 (1-5)
  tags: string[];                   // "다시먹고싶어", "별로였어", "추천", "비추" 등
  comment: string;                  // 한줄 메모
  createdAt: string;                // 리뷰 작성 시간
}

export interface PremiumFeature {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export interface NutritionInfo {
  menuName: string;
  calories: number;
  protein: number;                  // 단백질 (g)
  carbs: number;                    // 탄수화물 (g)
  fat: number;                      // 지방 (g)
  sodium: number;                   // 나트륨 (mg)
  category: string;
}

export interface GroupMember {
  id: string;
  name: string;
  wants: string[];                  // 먹고 싶은 것
  avoids: string[];                 // 절대 싫은 것
  maxBudget: number;                // 예산 (원)
  maxDistance: number;              // 거리 한계 (분)
  mood: string;                     // 분위기
  purpose: string;                  // 식사 목적
}

export interface ConsensusResult {
  id: string;
  timestamp: string;
  members: GroupMember[];
  recommendations: RecommendationItem[];
  conflictMap: ConflictItem[];
}

export interface RecommendationItem {
  id: string;
  name: string;
  category: string;
  reasons: string[];
  tags: RecommendationTag[];
  estimatedPrice: number;
  estimatedDistance: number;
  planBOptions?: string[];
  score: number;
}

export type RecommendationTag =
  | "safe_choice"
  | "new_experience"
  | "best_value"
  | "team_consensus"
  | "condition_match";

export interface ConflictItem {
  menuName: string;
  status: "all_ok" | "mostly_ok" | "conflict" | "budget_over";
  okCount: number;
  totalCount: number;
}

export interface DailyMission {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  emoji: string;
}

export interface AppState {
  tasteDNA: TasteDNA | null;
  onboardingCompleted: boolean;
  mealHistory: MealRecord[];
  relationshipProfiles: RelationshipProfile[];
  recentConsensus: ConsensusResult | null;
  dailyMissions: DailyMission[];
  premiumFeatures: PremiumFeature[];
  isPremiumUser: boolean;
}

// ─── Default Values ───────────────────────────────────────────────────────────

export const DEFAULT_TASTE_DNA: TasteDNA = {
  spicyTolerance: 3,
  oilyTolerance: 3,
  adventurousness: 3,
  familiarPreference: 3,
  fullnessFirst: true,
  priceSensitivity: 3,
  healthFirst: false,
};

export const DEFAULT_RELATIONSHIP_PROFILES: RelationshipProfile[] = [
  {
    type: "solo",
    label: "혼밥",
    emoji: "🍱",
    favoriteCategories: ["한식", "분식", "일식"],
    avoidCategories: [],
    budgetPerPerson: 10000,
  },
  {
    type: "couple",
    label: "커플",
    emoji: "💑",
    favoriteCategories: ["이탈리안", "일식", "카페"],
    avoidCategories: [],
    budgetPerPerson: 20000,
  },
  {
    type: "team",
    label: "팀 점심",
    emoji: "👥",
    favoriteCategories: ["한식", "중식", "분식"],
    avoidCategories: [],
    budgetPerPerson: 12000,
  },
  {
    type: "family",
    label: "가족 외식",
    emoji: "👨‍👩‍👧‍👦",
    favoriteCategories: ["한식", "고기", "뷔페"],
    avoidCategories: [],
    budgetPerPerson: 25000,
  },
];

export const DEFAULT_MISSIONS: DailyMission[] = [
  {
    id: "m1",
    title: "새로운 면 요리 도전",
    description: "이번 주 한 번도 안 먹은 면 요리를 먹어보세요",
    completed: false,
    emoji: "🍜",
  },
  {
    id: "m2",
    title: "1만 원 이하 점심 챌린지",
    description: "오늘 점심은 1만 원 이하로 해결해보세요",
    completed: false,
    emoji: "💰",
  },
  {
    id: "m3",
    title: "다른 나라 음식 탐험",
    description: "평소에 잘 안 먹던 나라의 음식을 시도해보세요",
    completed: false,
    emoji: "🌍",
  },
];

// ─── Storage Keys ─────────────────────────────────────────────────────────────

const STORAGE_KEYS = {
  TASTE_DNA: "@menumate/taste_dna",
  ONBOARDING: "@menumate/onboarding_completed",
  MEAL_HISTORY: "@menumate/meal_history",
  RELATIONSHIP_PROFILES: "@menumate/relationship_profiles",
  RECENT_CONSENSUS: "@menumate/recent_consensus",
  DAILY_MISSIONS: "@menumate/daily_missions",
};

// ─── Storage Helpers ──────────────────────────────────────────────────────────

export async function saveTasteDNA(dna: TasteDNA): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.TASTE_DNA, JSON.stringify(dna));
}

export async function loadTasteDNA(): Promise<TasteDNA | null> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.TASTE_DNA);
  return raw ? JSON.parse(raw) : null;
}

export async function saveOnboardingCompleted(): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.ONBOARDING, "true");
}

export async function loadOnboardingCompleted(): Promise<boolean> {
  const val = await AsyncStorage.getItem(STORAGE_KEYS.ONBOARDING);
  return val === "true";
}

export async function saveMealHistory(history: MealRecord[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.MEAL_HISTORY, JSON.stringify(history));
}

export async function loadMealHistory(): Promise<MealRecord[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.MEAL_HISTORY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveRelationshipProfiles(profiles: RelationshipProfile[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.RELATIONSHIP_PROFILES, JSON.stringify(profiles));
}

export async function loadRelationshipProfiles(): Promise<RelationshipProfile[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.RELATIONSHIP_PROFILES);
  return raw ? JSON.parse(raw) : DEFAULT_RELATIONSHIP_PROFILES;
}

export async function saveRecentConsensus(result: ConsensusResult): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.RECENT_CONSENSUS, JSON.stringify(result));
}

export async function loadRecentConsensus(): Promise<ConsensusResult | null> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.RECENT_CONSENSUS);
  return raw ? JSON.parse(raw) : null;
}

export async function saveDailyMissions(missions: DailyMission[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.DAILY_MISSIONS, JSON.stringify(missions));
}

export async function loadDailyMissions(): Promise<DailyMission[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.DAILY_MISSIONS);
  return raw ? JSON.parse(raw) : DEFAULT_MISSIONS;
}

export async function addMealRecord(record: MealRecord): Promise<void> {
  const history = await loadMealHistory();
  history.unshift(record);
  // 최근 100개만 유지
  const trimmed = history.slice(0, 100);
  await saveMealHistory(trimmed);
}

export async function updateMealReview(mealId: string, review: MealReview): Promise<void> {
  const history = await loadMealHistory();
  const meal = history.find((m) => m.id === mealId);
  if (meal) {
    meal.review = review;
    meal.rating = review.rating;
    await saveMealHistory(history);
  }
}

export async function loadPremiumFeatures(): Promise<PremiumFeature[]> {
  const raw = await AsyncStorage.getItem("@menumate/premium_features");
  return raw ? JSON.parse(raw) : getDefaultPremiumFeatures();
}

export async function savePremiumFeatures(features: PremiumFeature[]): Promise<void> {
  await AsyncStorage.setItem("@menumate/premium_features", JSON.stringify(features));
}

export async function loadIsPremiumUser(): Promise<boolean> {
  const val = await AsyncStorage.getItem("@menumate/is_premium_user");
  return val === "true";
}

export async function setIsPremiumUser(isPremium: boolean): Promise<void> {
  await AsyncStorage.setItem("@menumate/is_premium_user", isPremium ? "true" : "false");
}

export function getDefaultPremiumFeatures(): PremiumFeature[] {
  return [
    {
      id: "unlimited_groups",
      name: "무제한 그룹 생성",
      description: "최대 6명 제한 없이 그룹 생성",
      icon: "👥",
      unlocked: false,
    },
    {
      id: "restaurant_reservation",
      name: "식당 예약 연동",
      description: "추천 메뉴에서 바로 예약",
      icon: "📋",
      unlocked: false,
    },
    {
      id: "monthly_report",
      name: "월리 리포트",
      description: "식사 패턴 분석 PDF 다운로드",
      icon: "📊",
      unlocked: false,
    },
    {
      id: "no_ads",
      name: "광고 제거",
      description: "모든 광고 제거",
      icon: "✨",
      unlocked: false,
    },
  ];
}

export const NUTRITION_DATABASE: Record<string, NutritionInfo> = {
  "돈가스": {
    menuName: "돈가스",
    calories: 680,
    protein: 28,
    carbs: 65,
    fat: 32,
    sodium: 1200,
    category: "양식",
  },
  "비빔밥": {
    menuName: "비빔밥",
    calories: 580,
    protein: 18,
    carbs: 72,
    fat: 18,
    sodium: 1500,
    category: "한식",
  },
  "라멘": {
    menuName: "라멘",
    calories: 620,
    protein: 22,
    carbs: 75,
    fat: 20,
    sodium: 1800,
    category: "일식",
  },
  "떡볶이": {
    menuName: "떡볶이",
    calories: 450,
    protein: 12,
    carbs: 68,
    fat: 14,
    sodium: 2000,
    category: "분식",
  },
  "마라탕": {
    menuName: "마라탕",
    calories: 520,
    protein: 20,
    carbs: 55,
    fat: 22,
    sodium: 2200,
    category: "중식",
  },
  "김치찌개": {
    menuName: "김치찌개",
    calories: 380,
    protein: 24,
    carbs: 28,
    fat: 18,
    sodium: 1600,
    category: "한식",
  },
  "파스타": {
    menuName: "파스타",
    calories: 650,
    protein: 24,
    carbs: 78,
    fat: 24,
    sodium: 1100,
    category: "양식",
  },
  "초밥": {
    menuName: "초밥",
    calories: 420,
    protein: 20,
    carbs: 52,
    fat: 12,
    sodium: 800,
    category: "일식",
  },
};
