import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { geminiStableRouter } from "./routers/gemini-stable";
import { restaurantsRouter } from "./routers/restaurants";
import { aiRecommendationsRouter } from "./routers/ai-recommendations";
import { menuRecommendationsRouter } from "./routers/menu-recommendations";
import { restaurantsSearchRouter } from "./routers/restaurants-search";
import { kakaoLocalRouter } from "./routers/kakao-local";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  gemini: geminiStableRouter,
  restaurants: restaurantsRouter,
  aiRecommendations: aiRecommendationsRouter,
  menuRecommendations: menuRecommendationsRouter,
  restaurantsSearch: restaurantsSearchRouter,
  kakaoLocal: kakaoLocalRouter,
});

export type AppRouter = typeof appRouter;
