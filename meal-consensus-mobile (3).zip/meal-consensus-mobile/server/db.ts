import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  restaurants,
  menus,
  userPreferences,
  recommendations,
  deliveryAppLinks,
  InsertRestaurant,
  InsertMenu,
  InsertUserPreference,
  InsertRecommendation,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ Restaurants ============
export async function getRestaurants(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(restaurants)
    .limit(limit)
    .offset(offset);
}

export async function getRestaurantsByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(restaurants)
    .where(eq(restaurants.category, category));
}

export async function getRestaurantById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(restaurants)
    .where(eq(restaurants.id, id));
  
  return result[0] || null;
}

export async function createRestaurant(data: InsertRestaurant) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(restaurants).values(data);
  return (result as any).insertId || 0;
}

// ============ Menus ============
export async function getMenusByRestaurant(restaurantId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(menus)
    .where(eq(menus.restaurantId, restaurantId));
}

export async function getMenuById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(menus)
    .where(eq(menus.id, id));
  
  return result[0] || null;
}

export async function getMenusByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(menus)
    .where(eq(menus.category, category));
}

export async function createMenu(data: InsertMenu) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(menus).values(data);
  return (result as any).insertId || 0;
}

// ============ User Preferences ============
export async function getUserPreferences(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(userPreferences)
    .where(eq(userPreferences.userId, userId));
  
  return result[0] || null;
}

export async function createUserPreferences(data: InsertUserPreference) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(userPreferences).values(data);
  return (result as any).insertId || 0;
}

export async function updateUserPreferences(
  userId: number,
  data: Partial<InsertUserPreference>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(userPreferences)
    .set(data)
    .where(eq(userPreferences.userId, userId));
}

// ============ Recommendations ============
export async function createRecommendation(data: InsertRecommendation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(recommendations).values(data);
  return (result as any).insertId || 0;
}

export async function getUserRecommendations(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(recommendations)
    .where(eq(recommendations.userId, userId))
    .limit(limit);
}

// ============ Delivery App Links ============
export async function getDeliveryAppLinks(restaurantId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(deliveryAppLinks)
    .where(eq(deliveryAppLinks.restaurantId, restaurantId));
  
  return result[0] || null;
}
