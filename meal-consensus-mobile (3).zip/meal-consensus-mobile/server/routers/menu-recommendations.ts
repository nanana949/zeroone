import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";

// 메뉴 추천 데이터 로드
import recommendationData from "../data/menu_recommendations.json";

type RecommendationProfile = {
  id: number;
  gender: string;
  ageGroup: string;
  situation: string;
  recommendedMenus: Array<{
    name: string;
    reason: string;
  }>;
};

const recommendations: RecommendationProfile[] = recommendationData as RecommendationProfile[];

export const menuRecommendationsRouter = router({
  // 사용자 프로필 기반 메뉴 추천
  getRecommendations: publicProcedure
    .input(
      z.object({
        gender: z.enum(["여자", "남자"]),
        ageGroup: z.enum(["20대", "30대", "40대", "50대+"]),
        situation: z.string(),
      })
    )
    .query(({ input }) => {
      // 사용자 프로필과 일치하는 추천 찾기
      const profile = recommendations.find(
        (r) =>
          r.gender === input.gender &&
          r.ageGroup === input.ageGroup &&
          r.situation === input.situation
      );

      if (!profile) {
        // 상황이 없으면 유사한 상황 찾기
        const similarProfile = recommendations.find(
          (r) => r.gender === input.gender && r.ageGroup === input.ageGroup
        );

        if (similarProfile) {
          return {
            menus: similarProfile.recommendedMenus,
            situation: similarProfile.situation,
            message: `${input.gender} ${input.ageGroup}를 위한 추천입니다.`,
          };
        }

        // 기본 추천
        return {
          menus: [
            { name: "🍽️ 맛있는 음식", reason: "맛있는 음식으로 기분을 업시켜보세요!" },
          ],
          situation: "추천",
          message: "맞춤 추천을 찾을 수 없습니다.",
        };
      }

      return {
        menus: profile.recommendedMenus,
        situation: profile.situation,
        message: `${input.gender} ${input.ageGroup}의 "${input.situation}" 상황에 맞는 추천입니다.`,
      };
    }),

  // 모든 상황 옵션 조회
  getSituations: publicProcedure.query(() => {
    const situations = new Set<string>();
    recommendations.forEach((r) => situations.add(r.situation));
    return Array.from(situations).sort();
  }),

  // 모든 나이 옵션 조회
  getAgeGroups: publicProcedure.query(() => [
    { id: "20대", label: "20대" },
    { id: "30대", label: "30대" },
    { id: "40대", label: "40대" },
    { id: "50대+", label: "50대+" },
  ]),

  // 모든 성별 옵션 조회
  getGenders: publicProcedure.query(() => [
    { id: "여자", label: "여자", emoji: "👩" },
    { id: "남자", label: "남자", emoji: "👨" },
  ]),

  // 특정 성별/나이 조합의 모든 상황 조회
  getSituationsByProfile: publicProcedure
    .input(
      z.object({
        gender: z.enum(["여자", "남자"]),
        ageGroup: z.enum(["20대", "30대", "40대", "50대+"]),
      })
    )
    .query(({ input }) => {
      const situations = new Set<string>();
      recommendations.forEach((r) => {
        if (r.gender === input.gender && r.ageGroup === input.ageGroup) {
          situations.add(r.situation);
        }
      });
      return Array.from(situations).sort();
    }),

  // 모든 추천 프로필 조회 (통계용)
  getAllProfiles: publicProcedure.query(() => {
    return {
      total: recommendations.length,
      genders: ["여자", "남자"],
      ageGroups: ["20대", "30대", "40대", "50대+"],
      situations: Array.from(
        new Set(recommendations.map((r) => r.situation))
      ).sort(),
    };
  }),
});
