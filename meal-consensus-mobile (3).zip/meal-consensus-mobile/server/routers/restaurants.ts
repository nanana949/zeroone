import { publicProcedure, router } from "../_core/trpc";
import {
  getRestaurants,
  getRestaurantsByCategory,
  getRestaurantById,
  getMenusByRestaurant,
  getDeliveryAppLinks,
} from "../db";

// 총 98개 식당 데이터 (한식 15, 국밥 15, 중식 10, 일식 10, 양식 10, 햄버거 9, 치킨 9, 술집 10, 분식 10)
const DEMO_RESTAURANTS = [
  // ─── 한식 (15개) ───────────────────────────────────────────────────────────
  { id: 1, name: "동백본가", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 동백중앙로 283 골드프라자 C동 205호", phone: "02-0000-0001", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 2, name: "동백궁", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 동백동 445-2", phone: "02-0000-0002", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 3, name: "참숯효성한우", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 동백중앙로 213 1층", phone: "02-0000-0003", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 4, name: "산내음", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 석성로521번길 42", phone: "02-0000-0004", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 5, name: "일마레 용인동백점", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 중동 831-3", phone: "02-0000-0005", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 6, name: "동백한옥집 숯불구이", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 언동로 221 1층", phone: "02-0000-0006", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 7, name: "은행골 용인점", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 동백중앙로 265 101호", phone: "02-0000-0007", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 8, name: "서울24시감자탕 동백직영점", category: "한식", categoryId: "korean", address: "경기 용인시 기흥구 평촌2로1번길 4-9", phone: "02-0000-0008", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 9, name: "용인돼지불백", category: "한식", categoryId: "korean", address: "동백동 7로 53", phone: "02-0000-0009", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 10, name: "양산도 용인동백점", category: "한식", categoryId: "korean", address: "기흥구 중동 846 2번지", phone: "02-0000-0010", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 11, name: "해초락", category: "한식", categoryId: "korean", address: "용인시", phone: "02-0000-0011", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 12, name: "하남돼지집 용인동백점", category: "한식", categoryId: "korean", address: "용인시 이마트 뒤 먹자골목", phone: "02-0000-0012", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 13, name: "용범이네꼬부리는쪽갈비", category: "한식", categoryId: "korean", address: "기흥구 동백5로 21-8 103호", phone: "02-0000-0013", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 14, name: "남도주먹고기", category: "한식", categoryId: "korean", address: "기흥구 어정로 134-28", phone: "02-0000-0014", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 15, name: "소원.1 본점", category: "한식", categoryId: "korean", address: "기흥구 신갈동 388-151", phone: "02-0000-0015", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 국밥 (15개) ───────────────────────────────────────────────────────────
  { id: 16, name: "전주명가콩나물국밥", category: "국밥", categoryId: "kimbap", address: "동백중앙로 일대", phone: "02-0000-0016", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 17, name: "동백순대국", category: "국밥", categoryId: "kimbap", address: "동백동 598-4번지 유타운", phone: "02-0000-0017", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 18, name: "명인순대국 본점", category: "국밥", categoryId: "kimbap", address: "기흥구 민속촌로 10", phone: "02-0000-0018", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 19, name: "국민순대국동백점", category: "국밥", categoryId: "kimbap", address: "기흥구 중동 849-3번지 1층 1호 로데", phone: "02-0000-0019", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 20, name: "굴다리전주콩나물국밥", category: "국밥", categoryId: "kimbap", address: "동백동 623-12", phone: "02-0000-0020", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 21, name: "바른순대국찰솥밥", category: "국밥", categoryId: "kimbap", address: "중동 848-1", phone: "02-0000-0021", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 22, name: "Sujin-Og(수진옥)", category: "국밥", categoryId: "kimbap", address: "동백동", phone: "02-0000-0022", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 23, name: "담소사골순대", category: "국밥", categoryId: "kimbap", address: "동백중앙로 일대", phone: "02-0000-0023", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 24, name: "옛날 경성순대국 동백 윤들래점", category: "국밥", categoryId: "kimbap", address: "기흥구 중동 977-1 윤들래뜰 106호", phone: "02-0000-0024", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 25, name: "용인전통순대국", category: "국밥", categoryId: "kimbap", address: "용인시 석성로 인근", phone: "02-0000-0025", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 26, name: "기뜻국밥 용인동백점", category: "국밥", categoryId: "kimbap", address: "동백중앙로 221", phone: "02-0000-0026", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 27, name: "농서리 해장국", category: "국밥", categoryId: "kimbap", address: "기흥구 농서동 142-2", phone: "02-0000-0027", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 28, name: "강릉장칼", category: "국밥", categoryId: "kimbap", address: "동백중앙로 221", phone: "02-0000-0028", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 29, name: "할매순대국", category: "국밥", categoryId: "kimbap", address: "기흥구 중동 831-2번지", phone: "02-0000-0029", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 30, name: "청년감자탕순대국 용인중동점", category: "국밥", categoryId: "kimbap", address: "동백죽전대로 309", phone: "02-0000-0030", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 중식 (10개) ────────────────────────────────────────────────────────────
  { id: 31, name: "난춘반점", category: "중식", categoryId: "chinese", address: "기흥구 평촌2로1번길 10", phone: "02-0000-0031", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 32, name: "명가짜장", category: "중식", categoryId: "chinese", address: "기흥구 동백5로 21-11 1층", phone: "02-0000-0032", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 33, name: "신인반점", category: "중식", categoryId: "chinese", address: "기흥구 평촌2로2번길 6 102호", phone: "02-0000-0033", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 34, name: "Chaina(삼선짬뽕)", category: "중식", categoryId: "chinese", address: "동백동 동백8로 68 가상가 103호", phone: "02-0000-0034", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 35, name: "메이란", category: "중식", categoryId: "chinese", address: "동백죽전대로527번길 98-4", phone: "02-0000-0035", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 36, name: "Hyangchai", category: "중식", categoryId: "chinese", address: "기흥구 중동 665-49", phone: "02-0000-0036", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 37, name: "홍짜장 동백백현점", category: "중식", categoryId: "chinese", address: "기흥구 동백7로 83", phone: "02-0000-0037", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 38, name: "동백차이", category: "중식", categoryId: "chinese", address: "동백동 중동 846-1번지 지젤타워1층", phone: "02-0000-0038", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 39, name: "동백짬뽕24시", category: "중식", categoryId: "chinese", address: "기흥구 중동 848-2번지 미주타운 104호", phone: "02-0000-0039", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 40, name: "보배반점 용인동백점", category: "중식", categoryId: "chinese", address: "동백중앙로 283", phone: "02-0000-0040", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 일식 (10개) ────────────────────────────────────────────────────────────
  { id: 41, name: "이태리 돈까스", category: "일식", categoryId: "japanese", address: "동백중앙로 221", phone: "02-0000-0041", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 42, name: "맛있는초밥 동백점", category: "일식", categoryId: "japanese", address: "어정로 127 상하동", phone: "02-0000-0042", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 43, name: "미락제면(우동)", category: "일식", categoryId: "japanese", address: "중동 1108-1", phone: "02-0000-0043", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 44, name: "Kohane", category: "일식", categoryId: "japanese", address: "동백중앙로 245", phone: "02-0000-0044", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 45, name: "동경규동 동백점", category: "일식", categoryId: "japanese", address: "동백중앙로 273", phone: "02-0000-0045", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 46, name: "올리앙 용인동백점", category: "일식", categoryId: "japanese", address: "상하동 483-2", phone: "02-0000-0046", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 47, name: "용인안쪽집", category: "일식", categoryId: "japanese", address: "동백죽전대로527번길 98-4 102호", phone: "02-0000-0047", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 48, name: "Hacheune(하츄네)", category: "일식", categoryId: "japanese", address: "기흥구 동백5로 22 A동 101호", phone: "02-0000-0048", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 49, name: "도요텐동", category: "일식", categoryId: "japanese", address: "중동 830-1 지스타프라자", phone: "02-0000-0049", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 50, name: "도꼬텐동", category: "일식", categoryId: "japanese", address: "동백동 598-8번지 경안빌딩 105호", phone: "02-0000-0050", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 양식 (10개) ────────────────────────────────────────────────────────────
  { id: 51, name: "La Bella Pasta", category: "양식", categoryId: "western", address: "동백중앙로 100", phone: "02-0000-0051", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 52, name: "Trattoria Italiana", category: "양식", categoryId: "western", address: "기흥구 동백5로 50", phone: "02-0000-0052", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 53, name: "Le Petit Bistro", category: "양식", categoryId: "western", address: "동백동 200", phone: "02-0000-0053", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 54, name: "Ristorante Roma", category: "양식", categoryId: "western", address: "중동 500", phone: "02-0000-0054", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 55, name: "Pasta Fresca", category: "양식", categoryId: "western", address: "동백중앙로 150", phone: "02-0000-0055", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 56, name: "Osteria Moderna", category: "양식", categoryId: "western", address: "기흥구 중동 600", phone: "02-0000-0056", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 57, name: "Cucina Italiana", category: "양식", categoryId: "western", address: "동백동 300", phone: "02-0000-0057", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 58, name: "Pizzeria Napoli", category: "양식", categoryId: "western", address: "기흥구 동백7로 100", phone: "02-0000-0058", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 59, name: "Brasserie Française", category: "양식", categoryId: "western", address: "동백중앙로 250", phone: "02-0000-0059", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 60, name: "Taverna Greca", category: "양식", categoryId: "western", address: "중동 700", phone: "02-0000-0060", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 햄버거 (9개) ───────────────────────────────────────────────────────────
  { id: 61, name: "버거킹 용인점", category: "햄버거", categoryId: "burger", address: "동백중앙로 200", phone: "02-0000-0061", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 62, name: "맥도날드 동백점", category: "햄버거", categoryId: "burger", address: "기흥구 중동 400", phone: "02-0000-0062", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 63, name: "롯데리아 용인점", category: "햄버거", categoryId: "burger", address: "동백동 150", phone: "02-0000-0063", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 64, name: "쉐이크쉑 동백", category: "햄버거", categoryId: "burger", address: "동백중앙로 300", phone: "02-0000-0064", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 65, name: "5 Guys Burgers", category: "햄버거", categoryId: "burger", address: "기흥구 동백5로 80", phone: "02-0000-0065", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 66, name: "Smashburger", category: "햄버거", categoryId: "burger", address: "중동 550", phone: "02-0000-0066", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 67, name: "The Burger Joint", category: "햄버거", categoryId: "burger", address: "동백동 250", phone: "02-0000-0067", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 68, name: "Craft Burger", category: "햄버거", categoryId: "burger", address: "기흥구 중동 650", phone: "02-0000-0068", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 69, name: "Premium Burger House", category: "햄버거", categoryId: "burger", address: "동백중앙로 350", phone: "02-0000-0069", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 치킨 (9개) ─────────────────────────────────────────────────────────────
  { id: 70, name: "BBQ 치킨 용인점", category: "치킨", categoryId: "chicken", address: "동백중앙로 120", phone: "02-0000-0070", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 71, name: "교촌 치킨 동백점", category: "치킨", categoryId: "chicken", address: "기흥구 중동 300", phone: "02-0000-0071", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 72, name: "네네 치킨", category: "치킨", categoryId: "chicken", address: "동백동 100", phone: "02-0000-0072", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 73, name: "처갓집 양념치킨", category: "치킨", categoryId: "chicken", address: "동백중앙로 180", phone: "02-0000-0073", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 74, name: "굽네 치킨", category: "치킨", categoryId: "chicken", address: "기흥구 동백5로 60", phone: "02-0000-0074", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 75, name: "호식이두마리 치킨", category: "치킨", categoryId: "chicken", address: "중동 450", phone: "02-0000-0075", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 76, name: "치킹 용인점", category: "치킨", categoryId: "chicken", address: "동백동 200", phone: "02-0000-0076", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 77, name: "멕시카나 치킨", category: "치킨", categoryId: "chicken", address: "기흥구 중동 550", phone: "02-0000-0077", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 78, name: "또래오래 치킨", category: "치킨", categoryId: "chicken", address: "동백중앙로 220", phone: "02-0000-0078", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 술집 (10개) ────────────────────────────────────────────────────────────
  { id: 79, name: "동백 술집 1호", category: "술집", categoryId: "pub", address: "동백중앙로 80", phone: "02-0000-0079", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 80, name: "용인 호프", category: "술집", categoryId: "pub", address: "기흥구 중동 250", phone: "02-0000-0080", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 81, name: "맥주 천국", category: "술집", categoryId: "pub", address: "동백동 50", phone: "02-0000-0081", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 82, name: "강남 스타일 펍", category: "술집", categoryId: "pub", address: "동백중앙로 140", phone: "02-0000-0082", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 83, name: "용인 주막", category: "술집", categoryId: "pub", address: "기흥구 동백5로 40", phone: "02-0000-0083", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 84, name: "치맥 천지", category: "술집", categoryId: "pub", address: "중동 350", phone: "02-0000-0084", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 85, name: "동백 야주점", category: "술집", categoryId: "pub", address: "동백동 150", phone: "02-0000-0085", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 86, name: "한잔 술집", category: "술집", categoryId: "pub", address: "기흥구 중동 450", phone: "02-0000-0086", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 87, name: "밤의 문화", category: "술집", categoryId: "pub", address: "동백중앙로 160", phone: "02-0000-0087", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 88, name: "용인 주점", category: "술집", categoryId: "pub", address: "중동 600", phone: "02-0000-0088", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },

  // ─── 분식 (10개) ────────────────────────────────────────────────────────────
  { id: 89, name: "김밥천국 동백점", category: "분식", categoryId: "snack", address: "동백중앙로 60", phone: "02-0000-0089", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 90, name: "분식왕 용인점", category: "분식", categoryId: "snack", address: "기흥구 중동 200", phone: "02-0000-0090", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 91, name: "떡볶이 맛집", category: "분식", categoryId: "snack", address: "동백동 30", phone: "02-0000-0091", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 92, name: "순대국 분식", category: "분식", categoryId: "snack", address: "동백중앙로 100", phone: "02-0000-0092", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 93, name: "김밥 전문점", category: "분식", categoryId: "snack", address: "기흥구 동백5로 20", phone: "02-0000-0093", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 94, name: "분식 천국", category: "분식", categoryId: "snack", address: "중동 300", phone: "02-0000-0094", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 95, name: "라면 전문점", category: "분식", categoryId: "snack", address: "동백동 80", phone: "02-0000-0095", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 96, name: "우동 전문점", category: "분식", categoryId: "snack", address: "기흥구 중동 400", phone: "02-0000-0096", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 97, name: "만두 전문점", category: "분식", categoryId: "snack", address: "동백중앙로 120", phone: "02-0000-0097", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
  { id: 98, name: "핫도그 가게", category: "분식", categoryId: "snack", address: "중동 500", phone: "02-0000-0098", rating: 4.5, reviewCount: 100, deliveryTime: 30, minOrderPrice: 10000, latitude: "37.2847", longitude: "127.1084", isOpen: 1 },
];

// ─── 카테고리 매핑 함수 ─────────────────────────────────────────────────────────
function getCategoryId(category: string): string {
  const categoryMap: Record<string, string> = {
    "한식": "korean",
    "국밥": "kimbap",
    "중식": "chinese",
    "일식": "japanese",
    "양식": "western",
    "햄버거": "burger",
    "치킨": "chicken",
    "술집": "pub",
    "분식": "snack",
  };
  return categoryMap[category] || "all";
}

function getCategoryEmoji(category: string): string {
  const emojiMap: Record<string, string> = {
    "한식": "🍲",
    "국밥": "🍚",
    "중식": "🥡",
    "일식": "🍱",
    "양식": "🍝",
    "햄버거": "🍔",
    "치킨": "🍗",
    "술집": "🍺",
    "분식": "🍢",
  };
  return emojiMap[category] || "🍽️";
}

export const restaurantsRouter = router({
  list: publicProcedure
    .input(
      (val: any) => ({
        limit: typeof val?.limit === "number" ? val.limit : 50,
        offset: typeof val?.offset === "number" ? val.offset : 0,
      })
    )
    .query(async ({ input }) => {
      return DEMO_RESTAURANTS.slice(input.offset, input.offset + input.limit);
    }),

  byCategory: publicProcedure
    .input((val: any) => ({
      categoryId: typeof val?.categoryId === "string" ? val.categoryId : "all",
      limit: typeof val?.limit === "number" ? val.limit : 50,
      offset: typeof val?.offset === "number" ? val.offset : 0,
    }))
    .query(async ({ input }) => {
      if (input.categoryId === "all") {
        return DEMO_RESTAURANTS.slice(input.offset, input.offset + input.limit);
      }
      const filtered = DEMO_RESTAURANTS.filter(
        (r) => r.categoryId === input.categoryId
      );
      return filtered.slice(input.offset, input.offset + input.limit);
    }),

  search: publicProcedure
    .input((val: any) => ({
      query: typeof val?.query === "string" ? val.query : "",
      categoryId: typeof val?.categoryId === "string" ? val.categoryId : "all",
    }))
    .query(async ({ input }) => {
      let results = DEMO_RESTAURANTS;

      if (input.categoryId !== "all") {
        results = results.filter((r) => r.categoryId === input.categoryId);
      }

      if (input.query) {
        const q = input.query.toLowerCase();
        results = results.filter(
          (r) =>
            r.name.toLowerCase().includes(q) ||
            r.category.toLowerCase().includes(q)
        );
      }

      return results;
    }),

  getById: publicProcedure
    .input((val: any) => ({
      id: typeof val?.id === "number" ? val.id : 0,
    }))
    .query(async ({ input }) => {
      return DEMO_RESTAURANTS.find((r) => r.id === input.id) || null;
    }),
});
