import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { ENV } from "../_core/env";

// ─── 카카오 로컬 API 응답 타입 ────────────────────────────────────────────────

interface KakaoPlace {
  id: string;
  place_name: string;
  category_name: string;
  category_group_code: string;
  category_group_name: string;
  phone: string;
  address_name: string;
  road_address_name: string;
  x: string; // 경도 (longitude)
  y: string; // 위도 (latitude)
  place_url: string;
  distance: string; // 미터 단위
}

interface KakaoSearchResponse {
  documents: KakaoPlace[];
  meta: {
    is_end: boolean;
    pageable_count: number;
    same_name: {
      keyword: string;
      region: string[];
      selected_region: string;
    };
    total_count: number;
  };
}

// ─── 카카오 로컬 API 호출 함수 ────────────────────────────────────────────────

async function searchKakaoPlaces(params: {
  query: string;
  x: number;
  y: number;
  radius: number;
  size?: number;
}): Promise<KakaoSearchResponse> {
  const apiKey = ENV.kakaoRestApiKey;
  if (!apiKey) {
    throw new Error("카카오 REST API 키가 설정되지 않았습니다.");
  }

  const url = new URL("https://dapi.kakao.com/v2/local/search/keyword.json");
  url.searchParams.set("query", params.query);
  url.searchParams.set("x", String(params.x));
  url.searchParams.set("y", String(params.y));
  url.searchParams.set("radius", String(params.radius));
  url.searchParams.set("sort", "distance");
  url.searchParams.set("size", String(params.size ?? 15));

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: {
      Authorization: `KakaoAK ${apiKey}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`카카오 API 오류 (${response.status}): ${errorText}`);
  }

  return response.json() as Promise<KakaoSearchResponse>;
}

// ─── 라우터 ───────────────────────────────────────────────────────────────────

export const kakaoLocalRouter = router({
  /**
   * 키워드 + 위치 기반 음식점 검색
   * - 2km 반경 내 검색 후 결과 없으면 5km로 재검색
   */
  searchNearby: publicProcedure
    .input(
      z.object({
        query: z.string().min(1).max(100),
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
        radius: z.number().min(100).max(20000).optional().default(2000),
      })
    )
    .query(async ({ input }) => {
      const { query, latitude, longitude, radius } = input;

      // 1차 검색 (기본 반경)
      let result = await searchKakaoPlaces({
        query,
        x: longitude,
        y: latitude,
        radius,
      });

      // 결과 없으면 5km로 재검색
      if (result.documents.length === 0 && radius <= 2000) {
        result = await searchKakaoPlaces({
          query,
          x: longitude,
          y: latitude,
          radius: 5000,
        });
      }

      // 응답 데이터 정제
      const places = result.documents.map((place) => ({
        id: place.id,
        placeName: place.place_name,
        categoryName: place.category_name,
        categoryGroupName: place.category_group_name,
        phone: place.phone,
        addressName: place.address_name,
        roadAddressName: place.road_address_name,
        x: place.x,
        y: place.y,
        placeUrl: place.place_url,
        distance: place.distance ? Number(place.distance) : null, // 미터
      }));

      return {
        query,
        places,
        totalCount: result.meta.total_count,
        isEnd: result.meta.is_end,
        searchedRadius: result.documents.length === 0 ? radius : (radius <= 2000 && result.meta.total_count > 0 ? radius : 5000),
      };
    }),
});
