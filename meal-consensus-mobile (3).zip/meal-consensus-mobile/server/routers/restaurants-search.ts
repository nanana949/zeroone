import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import restaurantData from "../data/restaurants_yongin.json";

type Restaurant = {
  id: number;
  name: string;
  fullName: string;
  category: string;
  address: string;
  region: string;
  rating: number;
  reviewCount: number;
  deliveryTime: string;
  deliveryFee: number;
  minOrder: number;
};

const restaurants: Restaurant[] = restaurantData.restaurants as Restaurant[];

// 메뉴와 카테고리 매핑
const MENU_TO_CATEGORY: Record<string, string[]> = {
  // 한식·고기
  "한우": ["한식·고기"],
  "갈비": ["한식·고기"],
  "불고기": ["한식·고기"],
  "삼겹살": ["한식·고기"],
  "돼지불백": ["한식·고기"],
  "쪽갈비": ["한식·고기"],

  // 국밥·순대국
  "감자탕": ["국밥·순대국"],
  "순대국": ["국밥·순대국"],
  "국밥": ["국밥·순대국"],
  "콩나물국밥": ["국밥·순대국"],
  "설렁탕": ["국밥·순대국"],
  "동태탕": ["국밥·순대국"],
  "해장국": ["국밥·순대국"],

  // 중식
  "짜장면": ["중식"],
  "짬뽕": ["중식"],
  "중식우동": ["중식"],
  "마라": ["중식"],
  "탄탄면": ["중식"],

  // 일식·돈카츠·스시
  "초밥": ["일식·돈카츠·스시"],
  "회": ["일식·돈카츠·스시"],
  "돈까스": ["일식·돈카츠·스시"],
  "돈카츠": ["일식·돈카츠·스시"],
  "규동": ["일식·돈카츠·스시"],
  "텐동": ["일식·돈카츠·스시"],
  "일식우동": ["일식·돈카츠·스시"],
  "장어": ["일식·돈카츠·스시"],

  // 동남아·인도
  "쌀국수": ["동남아·인도"],
  "포쌀국수": ["동남아·인도"],
  "베트남": ["동남아·인도"],
  "태국": ["동남아·인도"],
  "인도카레": ["동남아·인도"],
  "카레": ["동남아·인도"],

  // 양식·스테이크·피자
  "스테이크": ["양식·스테이크·피자"],
  "피자": ["양식·스테이크·피자"],
  "파스타": ["양식·스테이크·피자"],
  "이탈리안": ["양식·스테이크·피자"],
  "버터파스타": ["양식·스테이크·피자"],

  // 버거·패스트푸드
  "버거": ["버거·패스트푸드"],
  "핫도그": ["버거·패스트푸드"],
  "프라이드": ["버거·패스트푸드"],

  // 분식·국물떡볶이
  "떡볶이": ["분식·국물떡볶이"],
  "김밥": ["분식·국물떡볶이"],
  "라면": ["분식·국물떡볶이"],
  "만두": ["분식·국물떡볶이"],
  "튀김": ["분식·국물떡볶이"],

  // 치킨
  "치킨": ["치킨"],
  "닭다리": ["치킨"],
  "순살": ["치킨"],

  // 카페
  "커피": ["카페"],
  "카페라떼": ["카페"],
  "디저트": ["카페"],

  // 술집·이자카야·브루어리
  "맥주": ["술집·이자카야·브루어리"],
  "이자카야": ["술집·이자카야·브루어리"],
  "와인바": ["술집·이자카야·브루어리"],
  "소주": ["술집·이자카야·브루어리"],
};

export const restaurantsSearchRouter = router({
  // 메뉴 이름으로 식당 검색
  searchByMenu: publicProcedure
    .input(
      z.object({
        menuName: z.string(),
        limit: z.number().optional().default(10),
      })
    )
    .query(({ input }) => {
      // 메뉴 이름에 맞는 카테고리 찾기
      const matchedCategories: string[] = [];

      for (const [menu, categories] of Object.entries(MENU_TO_CATEGORY)) {
        if (input.menuName.includes(menu) || menu.includes(input.menuName)) {
          matchedCategories.push(...categories);
        }
      }

      // 중복 제거
      const uniqueCategories = Array.from(new Set(matchedCategories));

      // 해당 카테고리의 식당 찾기
      let results = restaurants.filter((r) =>
        uniqueCategories.includes(r.category)
      );

      // 정렬 (평점순)
      results = results.sort((a, b) => b.rating - a.rating);

      // 제한
      results = results.slice(0, input.limit);

      return {
        menuName: input.menuName,
        matchedCategories: uniqueCategories,
        restaurants: results,
        count: results.length,
      };
    }),

  // 카테고리로 식당 검색
  searchByCategory: publicProcedure
    .input(
      z.object({
        category: z.string(),
        limit: z.number().optional().default(20),
      })
    )
    .query(({ input }) => {
      let results = restaurants.filter((r) => r.category === input.category);

      results = results.sort((a, b) => b.rating - a.rating);
      results = results.slice(0, input.limit);

      return {
        category: input.category,
        restaurants: results,
        count: results.length,
      };
    }),

  // 모든 카테고리 조회
  getCategories: publicProcedure.query(() => {
    const categories = Array.from(new Set(restaurants.map((r) => r.category)));
    return categories.sort();
  }),

  // 식당 상세 정보
  getRestaurantDetail: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => {
      const restaurant = restaurants.find((r) => r.id === input.id);
      return restaurant || null;
    }),

  // 추천 메뉴 기반 식당 추천
  recommendRestaurants: publicProcedure
    .input(
      z.object({
        menus: z.array(z.string()),
        limit: z.number().optional().default(5),
      })
    )
    .query(({ input }) => {
      // 모든 메뉴에 대한 카테고리 수집
      const categoryScores: Record<string, number> = {};

      input.menus.forEach((menu) => {
        for (const [key, categories] of Object.entries(MENU_TO_CATEGORY)) {
          if (menu.includes(key) || key.includes(menu)) {
            categories.forEach((cat) => {
              categoryScores[cat] = (categoryScores[cat] || 0) + 1;
            });
          }
        }
      });

      // 점수가 높은 카테고리부터 식당 추천
      const sortedCategories = Object.entries(categoryScores)
        .sort((a, b) => b[1] - a[1])
        .map(([cat]) => cat);

      const recommendedRestaurants: Restaurant[] = [];
      const seenIds = new Set<number>();

      for (const category of sortedCategories) {
        const categoryRestaurants = restaurants
          .filter((r) => r.category === category && !seenIds.has(r.id))
          .sort((a, b) => b.rating - a.rating);

        for (const restaurant of categoryRestaurants) {
          if (recommendedRestaurants.length >= input.limit) break;
          recommendedRestaurants.push(restaurant);
          seenIds.add(restaurant.id);
        }

        if (recommendedRestaurants.length >= input.limit) break;
      }

      return {
        recommendedMenus: input.menus,
        matchedCategories: sortedCategories,
        restaurants: recommendedRestaurants,
        count: recommendedRestaurants.length,
      };
    }),
});
