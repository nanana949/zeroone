import { router, publicProcedure } from "../_core/trpc";
import { z } from "zod";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = "gemini-2.0-flash";
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

interface GeminiMessage {
  role: "user" | "model";
  parts: Array<{ text: string }>;
}

interface GeminiRequest {
  contents: GeminiMessage[];
  generationConfig?: {
    temperature?: number;
    topK?: number;
    topP?: number;
    maxOutputTokens?: number;
  };
}

interface GeminiResponse {
  candidates?: Array<{
    content?: {
      parts: Array<{ text: string }>;
    };
  }>;
  error?: {
    code: number;
    message: string;
  };
}

/**
 * 메뉴 추천 프롬프트 생성
 */
function createMenuRecommendationPrompt(userInput: string): string {
  return `당신은 음식 추천 전문가입니다. 사용자의 상황을 분석하고 최적의 메뉴를 추천해주세요.

사용자 입력: "${userInput}"

다음 형식으로 응답해주세요:
1. 추천 메뉴 (한국어 메뉴명)
2. 추천 이유 (2-3줄)
3. 예상 가격대 (원)
4. 추천 신뢰도 (1-10)

예시:
메뉴: 국밥
이유: 따뜻한 국물이 피로 회복에 도움되고, 소화가 잘되어 피곤할 때 최적입니다.
가격: 8,000-10,000원
신뢰도: 9`;
}

/**
 * Gemini API 호출 (HTTP 직접 호출)
 */
async function callGeminiAPI(messages: GeminiMessage[]): Promise<string> {
  if (!GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not set");
  }

  const request: GeminiRequest = {
    contents: messages,
    generationConfig: {
      temperature: 0.7,
      topK: 40,
      topP: 0.95,
      maxOutputTokens: 500,
    },
  };

  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error("Gemini API Error:", errorData);
      throw new Error(
        `Gemini API error: ${response.status} - ${JSON.stringify(errorData)}`
      );
    }

    const data: GeminiResponse = await response.json();

    if (data.error) {
      throw new Error(`Gemini API error: ${data.error.message}`);
    }

    if (!data.candidates || data.candidates.length === 0) {
      throw new Error("No response from Gemini API");
    }

    const responseText = data.candidates[0].content?.parts[0].text;
    if (!responseText) {
      throw new Error("Empty response from Gemini API");
    }

    return responseText;
  } catch (error) {
    console.error("Gemini API call failed:", error);
    throw error;
  }
}

/**
 * 응답 파싱
 */
function parseGeminiResponse(response: string): {
  menu: string;
  reason: string;
  price: string;
  confidence: number;
} {
  try {
    // 메뉴명 추출
    const menuMatch = response.match(/메뉴:\s*(.+?)(?:\n|$)/);
    const menu = menuMatch ? menuMatch[1].trim() : "추천 메뉴";

    // 이유 추출
    const reasonMatch = response.match(/이유:\s*(.+?)(?:\n가격|$)/s);
    const reason = reasonMatch ? reasonMatch[1].trim() : "맛있는 메뉴입니다";

    // 가격 추출
    const priceMatch = response.match(/가격:\s*(.+?)(?:\n신뢰도|$)/);
    const price = priceMatch ? priceMatch[1].trim() : "10,000원";

    // 신뢰도 추출
    const confidenceMatch = response.match(/신뢰도:\s*(\d+)/);
    const confidence = confidenceMatch ? parseInt(confidenceMatch[1]) : 7;

    return { menu, reason, price, confidence };
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    return {
      menu: "추천 메뉴",
      reason: "맛있는 메뉴입니다",
      price: "10,000원",
      confidence: 5,
    };
  }
}

export const geminiStableRouter = router({
  /**
   * 메뉴 추천 (단일 턴)
   */
  recommendMenu: publicProcedure
    .input(z.object({ userInput: z.string().min(1) }))
    .mutation(async ({ input }) => {
      try {
        const prompt = createMenuRecommendationPrompt(input.userInput);

        const messages: GeminiMessage[] = [
          {
            role: "user",
            parts: [{ text: prompt }],
          },
        ];

        const response = await callGeminiAPI(messages);
        const parsed = parseGeminiResponse(response);

        return {
          success: true,
          menu: parsed.menu,
          reason: parsed.reason,
          price: parsed.price,
          confidence: parsed.confidence,
          rawResponse: response,
        };
      } catch (error) {
        console.error("Menu recommendation failed:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          menu: "추천 불가",
          reason: "일시적 오류가 발생했습니다. 다시 시도해주세요.",
          price: "-",
          confidence: 0,
        };
      }
    }),

  /**
   * 대화형 메뉴 추천 (멀티턴)
   */
  chatWithCoach: publicProcedure
    .input(
      z.object({
        userMessage: z.string().min(1),
        conversationHistory: z
          .array(
            z.object({
              role: z.enum(["user", "model"]),
              text: z.string(),
            })
          )
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const systemPrompt = `당신은 음식 추천 전문 AI 코치입니다. 사용자와 자연스럽게 대화하면서:
1. 사용자의 현재 상황(기분, 컨디션, 예산 등)을 파악하세요
2. 최적의 메뉴를 추천하세요
3. 추천 이유를 명확하게 설명하세요
4. 친근하고 따뜻한 톤으로 대화하세요

메뉴 추천 시 다음 형식을 사용하세요:
"[메뉴명]을(를) 추천드려요! [이유]"`;

        // 대화 히스토리 구성
        const messages: GeminiMessage[] = [];

        // 시스템 프롬프트 추가
        messages.push({
          role: "user",
          parts: [{ text: systemPrompt }],
        });

        messages.push({
          role: "model",
          parts: [{ text: "네, 음식 추천 전문 AI 코치입니다. 편하게 말씀해주세요!" }],
        });

        // 이전 대화 히스토리 추가
        if (input.conversationHistory && input.conversationHistory.length > 0) {
          for (const msg of input.conversationHistory) {
            messages.push({
              role: msg.role as "user" | "model",
              parts: [{ text: msg.text }],
            });
          }
        }

        // 현재 사용자 메시지 추가
        messages.push({
          role: "user",
          parts: [{ text: input.userMessage }],
        });

        const response = await callGeminiAPI(messages);

        return {
          success: true,
          reply: response,
          conversationHistory: [
            ...(input.conversationHistory || []),
            { role: "user" as const, text: input.userMessage },
            { role: "model" as const, text: response },
          ],
        };
      } catch (error) {
        console.error("Chat with coach failed:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          reply: "죄송합니다. 일시적 오류가 발생했습니다. 다시 시도해주세요.",
          conversationHistory: input.conversationHistory || [],
        };
      }
    }),

  /**
   * API 상태 체크
   */
  healthCheck: publicProcedure.query(async () => {
    try {
      if (!GEMINI_API_KEY) {
        return { status: "error", message: "GEMINI_API_KEY not configured" };
      }

      // 간단한 테스트 요청
      const testMessages: GeminiMessage[] = [
        {
          role: "user",
          parts: [{ text: "Hello" }],
        },
      ];

      await callGeminiAPI(testMessages);

      return { status: "ok", message: "Gemini API is working" };
    } catch (error) {
      return {
        status: "error",
        message: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),
});
