/** @type {const} */
const themeColors = {
  primary: { light: '#FF8566', dark: '#FF9977' },
  secondary: { light: '#7B9FD4', dark: '#9BB5E0' },
  accent: { light: '#F7C59F', dark: '#E8A87C' },
  background: { light: '#FFFBF7', dark: '#0F1117' },
  surface: { light: '#FFF8F3', dark: '#1C1F2E' },
  foreground: { light: '#2D2D3D', dark: '#F0F0F5' },
  muted: { light: '#8B9BA8', dark: '#9CA3AF' },
  border: { light: '#F0E6DC', dark: '#2D3561' },
  success: { light: '#7FD8BE', dark: '#66BB6A' },
  warning: { light: '#FFB366', dark: '#FFA726' },
  error: { light: '#FF9999', dark: '#EF5350' },
  card: { light: '#FFF8F3', dark: '#1C1F2E' },
  tint: { light: '#FF8566', dark: '#FF9977' },
};

module.exports = { themeColors };
