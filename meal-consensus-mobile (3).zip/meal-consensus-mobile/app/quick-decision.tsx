import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  Animated,
  useWindowDimensions,
} from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ImpactFeedbackStyle, NotificationFeedbackType } from "expo-haptics";
import { Platform } from "react-native";
import { useState, useRef, useEffect } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

// ─── 음식 메뉴 데이터 ────────────────────────────────────────────
const MENUS = [
  { name: "🍕 피자", emoji: "🍕", color: "#FFD9D0" },
  { name: "🍔 버거", emoji: "🍔", color: "#FFE8D6" },
  { name: "🍜 라면", emoji: "🍜", color: "#D4F1D4" },
  { name: "🍱 초밥", emoji: "🍱", color: "#D6E8F7" },
  { name: "🍝 파스타", emoji: "🍝", color: "#E8D5F2" },
  { name: "🥗 샐러드", emoji: "🥗", color: "#FFF4D6" },
  { name: "🍲 찌개", emoji: "🍲", color: "#FFD9D0" },
  { name: "🍛 카레", emoji: "🍛", color: "#D4F1D4" },
];

export default function QuickDecisionScreen() {
  const router = useRouter();
  const colors = useColors();
  const [isSpinning, setIsSpinning] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState(MENUS[0]);
  const spinAnim = useRef(new Animated.Value(0)).current;

  const handleSpin = () => {
    if (isSpinning) return;

    setIsSpinning(true);

    if (Platform.OS !== "web") {
      Haptics.impactAsync(ImpactFeedbackStyle.Light);
    }

    // 랜덤 회전 각도 계산 (최소 5바퀴 + 추가 회전)
    const randomIndex = Math.floor(Math.random() * MENUS.length);
    const rotations = 5;
    const additionalRotation = (randomIndex / MENUS.length) * 360;
    const totalRotation = rotations * 360 + additionalRotation;

    Animated.timing(spinAnim, {
      toValue: totalRotation,
      duration: 3000,
      useNativeDriver: true,
    }).start(() => {
      setSelectedMenu(MENUS[randomIndex]);
      setIsSpinning(false);

      if (Platform.OS !== "web") {
        Haptics.notificationAsync(NotificationFeedbackType.Success);
      }
    });
  };

  const handleGoBack = () => {
    router.back();
  };

  const spin = spinAnim.interpolate({
    inputRange: [0, 360],
    outputRange: ["0deg", "360deg"],
  });

  const wheelStyle = {
    transform: [{ rotate: spin }],
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      paddingHorizontal: 16,
      paddingVertical: 12,
      alignItems: "center",
      justifyContent: "center",
      minHeight: "100%",
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      width: "100%",
      marginBottom: 32,
      paddingTop: 8,
    },
    backButton: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: colors.surface,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1.5,
      borderColor: colors.border,
    },
    backButtonText: {
      fontSize: 20,
      color: colors.foreground,
    },
    title: {
      fontSize: 24,
      fontWeight: "900",
      color: colors.foreground,
      letterSpacing: -0.5,
    },
    spacer: {
      width: 44,
    },
    wheelContainer: {
      alignItems: "center",
      justifyContent: "center",
      marginVertical: 32,
    },
    wheel: {
      width: 280,
      height: 280,
      borderRadius: 140,
      borderWidth: 8,
      borderColor: colors.primary,
      backgroundColor: colors.surface,
      alignItems: "center",
      justifyContent: "center",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.15,
      shadowRadius: 16,
      elevation: 8,
    },
    wheelSegment: {
      position: "absolute",
      width: 280,
      height: 280,
      borderRadius: 140,
      alignItems: "center",
      justifyContent: "flex-start",
      paddingTop: 20,
    },
    wheelText: {
      fontSize: 32,
      fontWeight: "900",
      textAlign: "center",
    },
    pointer: {
      width: 0,
      height: 0,
      borderLeftWidth: 12,
      borderRightWidth: 12,
      borderTopWidth: 20,
      borderLeftColor: "transparent",
      borderRightColor: "transparent",
      borderTopColor: colors.primary,
      marginBottom: -8,
    },
    resultCard: {
      backgroundColor: colors.surface,
      borderRadius: 24,
      padding: 32,
      alignItems: "center",
      justifyContent: "center",
      gap: 16,
      marginVertical: 32,
      borderWidth: 2,
      borderColor: colors.border,
      minWidth: 280,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.1,
      shadowRadius: 12,
      elevation: 5,
    },
    resultEmoji: {
      fontSize: 64,
      marginBottom: 8,
    },
    resultText: {
      fontSize: 28,
      fontWeight: "900",
      color: colors.foreground,
      textAlign: "center",
      letterSpacing: -0.3,
    },
    resultSubtext: {
      fontSize: 14,
      color: colors.muted,
      marginTop: 8,
    },
    spinButton: {
      backgroundColor: colors.primary,
      borderRadius: 28,
      paddingVertical: 18,
      paddingHorizontal: 48,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 24,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.2,
      shadowRadius: 12,
      elevation: 6,
    },
    spinButtonText: {
      fontSize: 18,
      fontWeight: "900",
      color: "#fff",
      letterSpacing: -0.2,
    },
    spinButtonDisabled: {
      opacity: 0.6,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* 헤더 */}
        <View style={styles.header}>
          <Pressable
            onPress={handleGoBack}
            style={({ pressed }) => [
              styles.backButton,
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={styles.backButtonText}>←</Text>
          </Pressable>
          <Text style={styles.title}>1초 결정</Text>
          <View style={styles.spacer} />
        </View>

        {/* 룰렛 휠 */}
        <View style={styles.wheelContainer}>
          <View style={styles.pointer} />
          <Animated.View style={[styles.wheel, wheelStyle]}>
            {MENUS.map((menu, index) => {
              const angle = (index / MENUS.length) * 360;
              return (
                <View
                  key={index}
                  style={[
                    styles.wheelSegment,
                    {
                      backgroundColor: menu.color,
                      transform: [{ rotate: `${angle}deg` }],
                    },
                  ]}
                >
                  <Text style={styles.wheelText}>{menu.emoji}</Text>
                </View>
              );
            })}
          </Animated.View>
        </View>

        {/* 결과 카드 */}
        <View style={styles.resultCard}>
          <Text style={styles.resultEmoji}>{selectedMenu.emoji}</Text>
          <Text style={styles.resultText}>{selectedMenu.name}</Text>
          <Text style={styles.resultSubtext}>
            {isSpinning ? "선택 중..." : "오늘의 추천"}
          </Text>
        </View>

        {/* 스핀 버튼 */}
        <Pressable
          onPress={handleSpin}
          disabled={isSpinning}
          style={({ pressed }) => [
            styles.spinButton,
            isSpinning && styles.spinButtonDisabled,
            pressed && { transform: [{ scale: 0.97 }] },
          ]}
        >
          <Text style={styles.spinButtonText}>
            {isSpinning ? "⏳ 선택 중..." : "🎯 지금 선택!"}
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
