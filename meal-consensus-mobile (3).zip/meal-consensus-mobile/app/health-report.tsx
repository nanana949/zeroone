import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function HealthReportScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    reportCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            📈 건강 리포트
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            주간 식습관 분석 결과입니다
          </Text>

          <View style={styles.reportCard}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
              🎯 건강 점수
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <View
                style={{
                  flex: 1,
                  height: 8,
                  backgroundColor: colors.border,
                  borderRadius: 4,
                  marginRight: 12,
                  overflow: "hidden",
                }}
              >
                <View
                  style={{
                    width: "75%",
                    height: "100%",
                    backgroundColor: colors.success,
                  }}
                />
              </View>
              <Text style={{ fontSize: 14, fontWeight: "700", color: colors.success }}>75/100</Text>
            </View>
          </View>

          <View style={styles.reportCard}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
              📊 주간 통계
            </Text>
            <View style={{ marginBottom: 10 }}>
              <Text style={{ fontSize: 13, color: colors.muted }}>평균 칼로리</Text>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginTop: 4 }}>
                1,850 kcal/일
              </Text>
            </View>
            <View style={{ marginBottom: 10 }}>
              <Text style={{ fontSize: 13, color: colors.muted }}>가장 많이 먹은 음식</Text>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginTop: 4 }}>
                🍚 밥 (5회)
              </Text>
            </View>
            <View>
              <Text style={{ fontSize: 13, color: colors.muted }}>영양 균형</Text>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginTop: 4 }}>
                탄수화물 50% • 단백질 25% • 지방 25%
              </Text>
            </View>
          </View>

          <View style={styles.reportCard}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
              💡 건강 팁
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, lineHeight: 18 }}>
              단백질 섭취가 조금 부족합니다. 계란, 두부, 생선 등을 더 많이 섭취해보세요!
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
