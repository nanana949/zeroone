import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const VOTE_OPTIONS = [
  { id: 1, name: "피자", emoji: "🍕", votes: 5 },
  { id: 2, name: "치킨", emoji: "🍗", votes: 3 },
  { id: 3, name: "라면", emoji: "🍜", votes: 2 },
];

export default function GroupVoteScreen() {
  const colors = useColors();
  const router = useRouter();
  const totalVotes = VOTE_OPTIONS.reduce((sum, opt) => sum + opt.votes, 0);

  const styles = StyleSheet.create({
    voteCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            🗳️ 그룹 투표
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            친구들과 함께 메뉴를 정하세요
          </Text>

          {VOTE_OPTIONS.map((option) => (
            <View key={option.id} style={styles.voteCard}>
              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
                <Text style={{ fontSize: 28, marginRight: 12 }}>{option.emoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>
                    {option.name}
                  </Text>
                  <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
                    {option.votes}표
                  </Text>
                </View>
              </View>
              <View
                style={{
                  height: 8,
                  backgroundColor: colors.border,
                  borderRadius: 4,
                  overflow: "hidden",
                }}
              >
                <View
                  style={{
                    width: `${(option.votes / totalVotes) * 100}%`,
                    height: "100%",
                    backgroundColor: colors.primary,
                  }}
                />
              </View>
            </View>
          ))}

          <Pressable
            style={{
              marginTop: 20,
              paddingVertical: 12,
              paddingHorizontal: 16,
              backgroundColor: colors.primary,
              borderRadius: 12,
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: "700", color: "#fff" }}>
              투표하기
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
