import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const DAYS = ["월", "화", "수", "목", "금", "토", "일"];
const DEMO_MEALS = {
  월: { breakfast: "계란 토스트", lunch: "김밥", dinner: "된장찌개" },
  화: { breakfast: "시리얼", lunch: "돈까스", dinner: "스파게티" },
  수: { breakfast: "팬케이크", lunch: "비빔밥", dinner: "치킨" },
  목: { breakfast: "계란 덮밥", lunch: "라면", dinner: "삼겹살" },
  금: { breakfast: "요거트", lunch: "버거", dinner: "피자" },
  토: { breakfast: "팬케이크", lunch: "회전초밥", dinner: "갈비" },
  일: { breakfast: "계란말이", lunch: "국수", dinner: "보리밥" },
};

export default function WeeklyMealPlanScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    dayCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    mealRow: {
      flexDirection: "row",
      alignItems: "center",
      marginVertical: 6,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            📅 주간 식단
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            월~일 식단을 미리 계획하세요
          </Text>

          {DAYS.map((day) => (
            <View key={day} style={styles.dayCard}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 10 }}>
                {day}요일
              </Text>
              <View style={styles.mealRow}>
                <Text style={{ fontSize: 12, color: colors.muted, width: 40 }}>아침</Text>
                <Text style={{ fontSize: 13, color: colors.foreground, flex: 1 }}>
                  {DEMO_MEALS[day as keyof typeof DEMO_MEALS].breakfast}
                </Text>
              </View>
              <View style={styles.mealRow}>
                <Text style={{ fontSize: 12, color: colors.muted, width: 40 }}>점심</Text>
                <Text style={{ fontSize: 13, color: colors.foreground, flex: 1 }}>
                  {DEMO_MEALS[day as keyof typeof DEMO_MEALS].lunch}
                </Text>
              </View>
              <View style={styles.mealRow}>
                <Text style={{ fontSize: 12, color: colors.muted, width: 40 }}>저녁</Text>
                <Text style={{ fontSize: 13, color: colors.foreground, flex: 1 }}>
                  {DEMO_MEALS[day as keyof typeof DEMO_MEALS].dinner}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
