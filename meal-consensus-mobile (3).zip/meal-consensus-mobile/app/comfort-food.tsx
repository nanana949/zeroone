import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const MOODS = [
  { id: 1, emoji: "😢", label: "우울할 때", selected: true },
  { id: 2, emoji: "😤", label: "화날 때", selected: false },
  { id: 3, emoji: "😴", label: "피곤할 때", selected: false },
  { id: 4, emoji: "😰", label: "불안할 때", selected: false },
];

const COMFORT_FOODS = [
  { name: "라면", emoji: "🍜", reason: "따뜻하고 위로가 되는 음식" },
  { name: "치킨", emoji: "🍗", reason: "기분을 업시켜주는 음식" },
  { name: "초콜릿", emoji: "🍫", reason: "달콤한 맛이 기분을 좋게 해줍니다" },
];

export default function ComfortFoodScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    moodButton: {
      width: "48%",
      aspectRatio: 1.2,
      borderRadius: 12,
      marginHorizontal: "1%",
      marginBottom: 12,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 2,
    },
    foodCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            🍜 위로 음식
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            지금의 기분에 맞는 음식을 추천해드립니다
          </Text>

          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
            지금 기분은?
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
            {MOODS.map((mood) => (
              <Pressable
                key={mood.id}
                style={[
                  styles.moodButton,
                  {
                    backgroundColor: mood.selected ? colors.primary + "30" : colors.surface,
                    borderColor: mood.selected ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text style={{ fontSize: 28, marginBottom: 4 }}>{mood.emoji}</Text>
                <Text
                  style={{
                    fontSize: 11,
                    fontWeight: "600",
                    color: colors.foreground,
                    textAlign: "center",
                  }}
                >
                  {mood.label}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginTop: 24, marginBottom: 12 }}>
            추천 음식
          </Text>
          {COMFORT_FOODS.map((food, idx) => (
            <View key={idx} style={styles.foodCard}>
              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
                <Text style={{ fontSize: 32, marginRight: 12 }}>{food.emoji}</Text>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>
                  {food.name}
                </Text>
              </View>
              <Text style={{ fontSize: 12, color: colors.muted, lineHeight: 16 }}>
                {food.reason}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
