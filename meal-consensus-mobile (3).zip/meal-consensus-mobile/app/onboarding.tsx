import { useState, useCallback } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  Platform,
} from "react-native";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  saveTasteDNA,
  saveOnboardingCompleted,
  DEFAULT_TASTE_DNA,
  type TasteDNA,
} from "@/lib/store";

// ─── 슬라이더 컴포넌트 ─────────────────────────────────────────────────────────

function ScaleSelector({
  value,
  onChange,
  leftLabel,
  rightLabel,
  color,
  emojis,
}: {
  value: number;
  onChange: (v: number) => void;
  leftLabel: string;
  rightLabel: string;
  color: string;
  emojis: string[];
}) {
  const colors = useColors();

  return (
    <View>
      <View style={{ flexDirection: "row", gap: 8 }}>
        {[1, 2, 3, 4, 5].map((level) => (
          <Pressable
            key={level}
            onPress={() => {
              if (Platform.OS !== "web") {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }
              onChange(level);
            }}
            style={({ pressed }) => [
              {
                flex: 1,
                aspectRatio: 1,
                borderRadius: 12,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: value === level ? color : colors.surface,
                borderWidth: value === level ? 0 : 1.5,
                borderColor: colors.border,
              },
              pressed && { opacity: 0.7, transform: [{ scale: 0.95 }] },
            ]}
          >
            <Text style={{ fontSize: 20 }}>{emojis[level - 1]}</Text>
            <Text
              style={{
                fontSize: 10,
                fontWeight: "700",
                color: value === level ? "#FFFFFF" : colors.muted,
                marginTop: 2,
              }}
            >
              {level}
            </Text>
          </Pressable>
        ))}
      </View>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginTop: 6,
        }}
      >
        <Text style={{ fontSize: 10, color: colors.muted }}>{leftLabel}</Text>
        <Text style={{ fontSize: 10, color: colors.muted }}>{rightLabel}</Text>
      </View>
    </View>
  );
}

// ─── 메인 화면 ─────────────────────────────────────────────────────────────────

export default function OnboardingScreen() {
  const colors = useColors();
  const router = useRouter();
  const [dna, setDna] = useState<TasteDNA>({ ...DEFAULT_TASTE_DNA });

  const handleSave = useCallback(async () => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    await saveTasteDNA(dna);
    await saveOnboardingCompleted();
    router.back();
  }, [dna, router]);

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 헤더 */}
        <View
          style={{
            paddingHorizontal: 20,
            paddingTop: 20,
            paddingBottom: 24,
            backgroundColor: colors.primary,
            borderBottomLeftRadius: 28,
            borderBottomRightRadius: 28,
            marginBottom: 24,
          }}
        >
          <Text style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", marginBottom: 6 }}>
            나의 취향을 알려주세요
          </Text>
          <Text
            style={{
              fontSize: 26,
              fontWeight: "800",
              color: "#FFFFFF",
              letterSpacing: -0.5,
            }}
          >
            🧬 취향 DNA 설정
          </Text>
          <Text
            style={{
              fontSize: 13,
              color: "rgba(255,255,255,0.85)",
              marginTop: 6,
              lineHeight: 18,
            }}
          >
            단 7가지 질문으로 나만의 식사 성향을 분석해요
          </Text>
        </View>

        <View style={{ paddingHorizontal: 20, gap: 28 }}>
          {/* 1. 맵기 민감도 */}
          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 4 }}>
              🌶️ 맵기 민감도
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12 }}>
              매운 음식에 얼마나 민감한가요?
            </Text>
            <ScaleSelector
              value={dna.spicyTolerance}
              onChange={(v) => setDna({ ...dna, spicyTolerance: v as 1 | 2 | 3 | 4 | 5 })}
              leftLabel="매우 민감"
              rightLabel="매운 거 좋아함"
              color="#FF6B35"
              emojis={["😰", "😅", "😊", "😋", "🔥"]}
            />
          </View>

          {/* 2. 느끼함 허용도 */}
          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 4 }}>
              🧈 느끼함 허용도
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12 }}>
              기름진 음식을 얼마나 좋아하나요?
            </Text>
            <ScaleSelector
              value={dna.oilyTolerance}
              onChange={(v) => setDna({ ...dna, oilyTolerance: v })}
              leftLabel="기름진 거 싫음"
              rightLabel="느끼해도 OK"
              color="#FF9800"
              emojis={["🥗", "🥙", "🍱", "🍔", "🍟"]}
            />
          </View>

          {/* 3. 도전 성향 */}
          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 4 }}>
              🗺️ 도전 성향
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12 }}>
              새로운 음식에 얼마나 도전하나요?
            </Text>
            <ScaleSelector
              value={dna.adventurousness}
              onChange={(v) => setDna({ ...dna, adventurousness: v })}
              leftLabel="익숙한 게 좋아"
              rightLabel="새로운 거 좋아"
              color="#9C27B0"
              emojis={["🏠", "🚶", "🚴", "🏃", "🚀"]}
            />
          </View>

          {/* 4. 가격 민감도 */}
          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 4 }}>
              💰 가격 민감도
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12 }}>
              식사 가격에 얼마나 민감한가요?
            </Text>
            <ScaleSelector
              value={dna.priceSensitivity}
              onChange={(v) => setDna({ ...dna, priceSensitivity: v as 1 | 2 | 3 | 4 | 5 })}
              leftLabel="가성비 최우선"
              rightLabel="가격 상관없음"
              color="#2196F3"
              emojis={["💸", "🤑", "😊", "💳", "💎"]}
            />
          </View>

          {/* 5. 포만감 vs 분위기 */}
          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
              💪 식사 우선순위
            </Text>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable
                onPress={() => setDna({ ...dna, fullnessFirst: true })}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    padding: 16,
                    borderRadius: 14,
                    alignItems: "center",
                    backgroundColor: dna.fullnessFirst ? colors.primary + "20" : colors.surface,
                    borderWidth: 2,
                    borderColor: dna.fullnessFirst ? colors.primary : colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Text style={{ fontSize: 28, marginBottom: 6 }}>💪</Text>
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "700",
                    color: dna.fullnessFirst ? colors.primary : colors.muted,
                    textAlign: "center",
                  }}
                >
                  배부름 우선
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setDna({ ...dna, fullnessFirst: false })}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    padding: 16,
                    borderRadius: 14,
                    alignItems: "center",
                    backgroundColor: !dna.fullnessFirst ? colors.primary + "20" : colors.surface,
                    borderWidth: 2,
                    borderColor: !dna.fullnessFirst ? colors.primary : colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Text style={{ fontSize: 28, marginBottom: 6 }}>🌟</Text>
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "700",
                    color: !dna.fullnessFirst ? colors.primary : colors.muted,
                    textAlign: "center",
                  }}
                >
                  분위기 우선
                </Text>
              </Pressable>
            </View>
          </View>

          {/* 6. 건강 우선 */}
          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
              🥗 건강 식단 우선 여부
            </Text>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable
                onPress={() => setDna({ ...dna, healthFirst: true })}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    padding: 16,
                    borderRadius: 14,
                    alignItems: "center",
                    backgroundColor: dna.healthFirst ? colors.success + "20" : colors.surface,
                    borderWidth: 2,
                    borderColor: dna.healthFirst ? colors.success : colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Text style={{ fontSize: 28, marginBottom: 6 }}>🥗</Text>
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "700",
                    color: dna.healthFirst ? colors.success : colors.muted,
                    textAlign: "center",
                  }}
                >
                  건강 우선
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setDna({ ...dna, healthFirst: false })}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    padding: 16,
                    borderRadius: 14,
                    alignItems: "center",
                    backgroundColor: !dna.healthFirst ? colors.warning + "20" : colors.surface,
                    borderWidth: 2,
                    borderColor: !dna.healthFirst ? colors.warning : colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Text style={{ fontSize: 28, marginBottom: 6 }}>😋</Text>
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "700",
                    color: !dna.healthFirst ? colors.warning : colors.muted,
                    textAlign: "center",
                  }}
                >
                  맛 우선
                </Text>
              </Pressable>
            </View>
          </View>

          {/* 저장 버튼 */}
          <Pressable
            onPress={handleSave}
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                paddingVertical: 18,
                borderRadius: 18,
                alignItems: "center",
                marginTop: 8,
              },
              pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
          >
            <Text style={{ fontSize: 17, fontWeight: "800", color: "#FFFFFF" }}>
              🧬 취향 DNA 저장하기
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
