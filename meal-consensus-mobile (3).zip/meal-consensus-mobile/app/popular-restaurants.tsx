import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const RESTAURANTS = [
  { id: 1, name: "맛있는 돈까스", category: "돈까스", rating: 4.8, reviews: 245, emoji: "🍖" },
  { id: 2, name: "라면 천국", category: "라면", rating: 4.6, reviews: 189, emoji: "🍜" },
  { id: 3, name: "피자 파티", category: "피자", rating: 4.5, reviews: 312, emoji: "🍕" },
];

export default function PopularRestaurantsScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    restaurantCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            ⭐ 인기 맛집
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            동네 최고 인기 맛집 TOP 3
          </Text>

          {RESTAURANTS.map((restaurant, index) => (
            <View key={restaurant.id} style={styles.restaurantCard}>
              <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    backgroundColor: colors.primary + "30",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Text style={{ fontSize: 20 }}>{restaurant.emoji}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 4 }}>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: colors.primary, marginRight: 6 }}>
                      #{index + 1}
                    </Text>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>
                      {restaurant.name}
                    </Text>
                  </View>
                  <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 6 }}>
                    {restaurant.category}
                  </Text>
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>
                      ⭐ {restaurant.rating}
                    </Text>
                    <Text style={{ fontSize: 12, color: colors.muted, marginLeft: 6 }}>
                      ({restaurant.reviews} 리뷰)
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
