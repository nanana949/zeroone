import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  Animated,
} from "react-native";
import { useState, useRef } from "react";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

// ─── 메뉴 데이터 ────────────────────────────────────────────────────────────

const MENUS = [
  "🍕 피자",
  "🍜 국수",
  "🍱 일식",
  "🍔 버거",
  "🥗 샐러드",
  "🍲 찌개",
  "🍝 파스타",
  "🥡 중식",
  "🍖 고기",
  "🍛 카레",
  "🌮 타코",
  "🍣 초밥",
];

export default function QuickDecisionScreen() {
  const colors = useColors();
  const [selectedMenu, setSelectedMenu] = useState<string | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const spinAnim = useRef(new Animated.Value(0)).current;

  const handleSpin = () => {
    if (isSpinning) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsSpinning(true);
    setSelectedMenu(null);

    // 회전 애니메이션 (3-5바퀴)
    const spins = 3 + Math.random() * 2;
    const randomIndex = Math.floor(Math.random() * MENUS.length);

    Animated.timing(spinAnim, {
      toValue: spins,
      duration: 2000,
      useNativeDriver: true,
    }).start(() => {
      setSelectedMenu(MENUS[randomIndex]);
      setIsSpinning(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    });
  };

  const handleReset = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    spinAnim.setValue(0);
    setSelectedMenu(null);
  };

  const spin = spinAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  const styles = StyleSheet.create({
    headerCard: {
      backgroundColor: colors.primary,
      borderRadius: 20,
      padding: 20,
      marginBottom: 24,
      gap: 8,
    },
    headerTitle: {
      fontSize: 28,
      fontWeight: "800",
      color: "#fff",
    },
    headerSubtitle: {
      fontSize: 13,
      color: "rgba(255,255,255,0.9)",
    },
    wheelContainer: {
      alignItems: "center",
      marginBottom: 32,
      gap: 16,
    },
    needle: {
      fontSize: 32,
      marginBottom: 8,
    },
    wheel: {
      width: 280,
      height: 280,
      borderRadius: 140,
      backgroundColor: colors.surface,
      borderWidth: 3,
      borderColor: colors.primary,
      justifyContent: "center",
      alignItems: "center",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.15,
      shadowRadius: 12,
      elevation: 8,
    },
    wheelContent: {
      width: 260,
      height: 260,
      borderRadius: 130,
      justifyContent: "center",
      alignItems: "center",
      overflow: "hidden",
    },
    segment: {
      position: "absolute",
      width: 260,
      height: 260,
      borderRadius: 130,
      justifyContent: "flex-start",
      alignItems: "center",
      paddingTop: 20,
    },
    segmentText: {
      fontSize: 16,
      fontWeight: "700",
      color: "#fff",
      textAlign: "center",
    },
    buttonContainer: {
      gap: 12,
      marginBottom: 24,
    },
    spinButton: {
      backgroundColor: colors.primary,
      borderRadius: 16,
      padding: 16,
      alignItems: "center",
      justifyContent: "center",
    },
    spinButtonText: {
      fontSize: 16,
      fontWeight: "700",
      color: "#fff",
    },
    resetButton: {
      backgroundColor: colors.muted,
      borderRadius: 16,
      padding: 12,
      alignItems: "center",
      justifyContent: "center",
    },
    resetButtonText: {
      fontSize: 14,
      fontWeight: "600",
      color: "#fff",
    },
    resultCard: {
      backgroundColor: colors.surface,
      borderRadius: 20,
      padding: 24,
      gap: 12,
      borderWidth: 2,
      borderColor: colors.primary,
      alignItems: "center",
    },
    resultEmoji: {
      fontSize: 48,
    },
    resultText: {
      fontSize: 20,
      fontWeight: "700",
      color: colors.foreground,
      textAlign: "center",
    },
  });

  // 색상 팔레트
  const colors_palette = [
    "#FF6B6B",
    "#4ECDC4",
    "#45B7D1",
    "#FFA07A",
    "#98D8C8",
    "#F7DC6F",
    "#BB8FCE",
    "#85C1E2",
    "#F8B88B",
    "#A8E6CF",
    "#FFD3B6",
    "#FFAAA5",
  ];

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>⚡ 1초 결정</Text>
          <Text style={styles.headerSubtitle}>
            돌림판을 돌려 메뉴를 정하세요!
          </Text>
        </View>

        {/* 돌림판 */}
        <View style={styles.wheelContainer}>
          <Text style={styles.needle}>👆</Text>

          <Animated.View
            style={[
              styles.wheel,
              {
                transform: [{ rotate: spin }],
              },
            ]}
          >
            <View style={styles.wheelContent}>
              {MENUS.map((menu, index) => {
                const angle = (index / MENUS.length) * 360;
                return (
                  <View
                    key={index}
                    style={[
                      styles.segment,
                      {
                        backgroundColor: colors_palette[index],
                        transform: [{ rotate: `${angle}deg` }],
                      },
                    ]}
                  >
                    <Text style={styles.segmentText}>{menu}</Text>
                  </View>
                );
              })}
            </View>
          </Animated.View>
        </View>

        {/* 버튼 */}
        <View style={styles.buttonContainer}>
          <Pressable
            style={({ pressed }) => [
              styles.spinButton,
              pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
              isSpinning && { opacity: 0.6 },
            ]}
            onPress={handleSpin}
            disabled={isSpinning}
          >
            <Text style={styles.spinButtonText}>
              {isSpinning ? "🔄 회전 중..." : "🎡 돌림판 돌리기"}
            </Text>
          </Pressable>

          {selectedMenu && (
            <Pressable
              style={({ pressed }) => [
                styles.resetButton,
                pressed && { opacity: 0.8 },
              ]}
              onPress={handleReset}
            >
              <Text style={styles.resetButtonText}>다시 돌리기</Text>
            </Pressable>
          )}
        </View>

        {/* 결과 */}
        {selectedMenu && (
          <View style={styles.resultCard}>
            <Text style={styles.resultEmoji}>{selectedMenu.split(" ")[0]}</Text>
            <Text style={styles.resultText}>{selectedMenu}</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 8 }}>
              오늘의 선택! 🎉
            </Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
