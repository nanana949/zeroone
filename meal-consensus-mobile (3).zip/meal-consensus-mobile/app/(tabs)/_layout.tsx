import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform, Text } from "react-native";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 60 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          borderTopWidth: 0.5,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: "600",
          marginTop: 2,
        },
      }}
    >
      {/* 홈 탭 */}
      <Tabs.Screen
        name="index"
        options={{
          title: "홈",
          tabBarLabel: "홈",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🏠</Text>,
        }}
      />

      {/* 식당 탭 */}
      <Tabs.Screen
        name="restaurants"
        options={{
          title: "식당",
          tabBarLabel: "식당",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🍽️</Text>,
        }}
      />

      {/* 커뮤니티 탭 */}
      <Tabs.Screen
        name="community"
        options={{
          title: "커뮤니티",
          tabBarLabel: "커뮤니티",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>👥</Text>,
        }}
      />

      {/* 캘린더 탭 */}
      <Tabs.Screen
        name="calendar"
        options={{
          title: "캘린더",
          tabBarLabel: "캘린더",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>📅</Text>,
        }}
      />

      {/* 프로필 탭 */}
      <Tabs.Screen
        name="profile"
        options={{
          title: "프로필",
          tabBarLabel: "프로필",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>👤</Text>,
        }}
      />

      {/* 질문으로 추천 (내부 내비게이션) */}
      <Tabs.Screen
        name="question-recommendation"
        options={{
          title: "질문으로 추천",
          href: null,
          headerShown: false,
        }}
      />

      {/* 맞춤추천 - 탭 바 숨김 (루트 레벨 fullScreenModal로 이동) */}
      <Tabs.Screen
        name="custom-recommendation"
        options={{
          href: null,
          headerShown: false,
        }}
      />

      {/* 1초 결정 (내부 내비게이션) */}
      <Tabs.Screen
        name="quick-decision"
        options={{
          title: "1초 결정",
          href: null,
          headerShown: false,
        }}
      />

      {/* 프로필 설정 (내부 내비게이션) */}
      <Tabs.Screen
        name="profile-setup"
        options={{
          title: "프로필 설정",
          href: null,
          headerShown: false,
        }}
      />

      {/* 음식 월드컵 (내부 내비게이션) */}
      <Tabs.Screen
        name="food-worldcup"
        options={{
          title: "음식 월드컵",
          href: null,
          headerShown: false,
        }}
      />

      {/* AI 코치 (탭 바 숨김) */}
      <Tabs.Screen
        name="coach"
        options={{
          href: null,
          headerShown: false,
        }}
      />

      {/* AI 맞춤추천 (탭 바 숨김) */}
      <Tabs.Screen
        name="ai-custom-recommendation"
        options={{
          href: null,
          headerShown: false,
        }}
      />
    </Tabs>
  );
}
