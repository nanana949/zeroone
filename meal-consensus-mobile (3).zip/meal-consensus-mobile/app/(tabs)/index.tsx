import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
} from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";
import { useState, useEffect } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

// ─── 결정 모드 데이터 ──────────────────────────────────────────
const DECISION_MODES = [
  {
    id: "consensus",
    label: "합의 모드",
    description: "여러 명 의견 모으기",
    emoji: "🤝",
    color: "#E8D5F2",
    route: "/consensus-mode",
  },
  {
    id: "food_worldcup",
    label: "음식 월드컵",
    description: "토너먼트로 선택하기",
    emoji: "🏆",
    color: "#FFE8B6",
    route: "/(tabs)/food-worldcup",
  },
  {
    id: "home_cooking",
    label: "집밥 모드",
    description: "냉장고 모드 · 장보기 모드",
    emoji: "🍳",
    color: "#FFF0D6",
    route: "/home-cooking-hub",
  },
  {
    id: "custom_recommendation",
    label: "맞춤추천",
    description: "질문으로 메뉴 추천",
    emoji: "🎯",
    color: "#E8F5E9",
    route: "/custom-recommendation",
  },

];

// ─── 더 많은 기능 ────────────────────────────────────────────
const OTHER_FEATURES = [
  {
    id: "popular_restaurants",
    title: "인기 맛집",
    description: "동네별 실시간 랭킹",
    icon: "⭐",
    color: "#FFE8D6",
    route: "/popular-restaurants",
  },
];

// ─── 명언 데이터 ────────────────────────────────────────────
const QUOTES = [
  { text: "함께 먹는 밥이 더 맛있다.", emoji: "🐰" },
  { text: "좋은 음식은 좋은 기억을 만든다.", emoji: "🐱" },
  { text: "배고픔은 최고의 양념이다.", emoji: "🐶" },
  { text: "음식으로 마음을 나누자.", emoji: "🦊" },
  { text: "매일 새로운 맛을 발견하자.", emoji: "🐻" },
  { text: "먹는 것도 예술이다.", emoji: "🐼" },
  { text: "건강한 음식, 행복한 삶.", emoji: "🐨" },
  { text: "맛있는 순간을 소중히.", emoji: "🐯" },
];

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const [todayQuote, setTodayQuote] = useState(QUOTES[0]);

  useEffect(() => {
    const dayOfYear = Math.floor(
      (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) /
        86400000
    );
    setTodayQuote(QUOTES[dayOfYear % QUOTES.length]);
  }, []);

  const handleDecisionModePress = (mode: (typeof DECISION_MODES)[0]) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    if (mode.route) {
      router.push(mode.route as any);
    }
  };

  const handleFeaturePress = (route: string) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push(route as any);
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      paddingHorizontal: 16,
      paddingVertical: 12,
    },
    // ─── 헤더 ────────────────────────────────────────────────────────
    headerCard: {
      backgroundColor: colors.primary,
      borderRadius: 24,
      padding: 24,
      marginBottom: 24,
      gap: 6,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.12,
      shadowRadius: 12,
      elevation: 6,
    },
    headerTitle: {
      fontSize: 32,
      fontWeight: "900",
      color: "#fff",
      letterSpacing: -0.5,
    },
    headerSubtitle: {
      fontSize: 14,
      color: "rgba(255,255,255,0.85)",
      fontWeight: "500",
    },
    // ─── 명언 카드 ────────────────────────────────────────────────────────
    quoteCard: {
      backgroundColor: colors.surface,
      borderRadius: 28,
      padding: 32,
      marginBottom: 32,
      borderWidth: 2,
      borderColor: colors.border,
      minHeight: 220,
      justifyContent: "center",
      alignItems: "center",
      gap: 16,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 3 },
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 4,
    },
    characterEmoji: {
      fontSize: 72,
      marginBottom: 8,
    },
    quoteText: {
      fontSize: 20,
      fontWeight: "800",
      color: colors.foreground,
      textAlign: "center",
      lineHeight: 32,
      letterSpacing: 0.3,
    },
    // ─── 섹션 제목 ────────────────────────────────────────────────────────
    sectionTitle: {
      fontSize: 18,
      fontWeight: "900",
      color: colors.foreground,
      marginBottom: 16,
      marginTop: 8,
      letterSpacing: -0.3,
    },
    // ─── 결정 모드 ────────────────────────────────────────────────────────
    decisionModesContainer: {
      marginBottom: 36,
      paddingBottom: 24,
      borderBottomWidth: 1.5,
      borderBottomColor: colors.border,
    },
    modeGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 12,
      justifyContent: "space-between",
    },
    modeCard: {
      width: "48%",
      borderRadius: 22,
      padding: 18,
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.06,
      shadowRadius: 6,
      elevation: 2,
    },
    modeEmoji: {
      fontSize: 44,
      marginBottom: 2,
    },
    modeLabel: {
      fontSize: 14,
      fontWeight: "800",
      color: colors.foreground,
      textAlign: "center",
      letterSpacing: -0.2,
    },
    modeDescription: {
      fontSize: 12,
      color: colors.muted,
      textAlign: "center",
      marginTop: 2,
      fontWeight: "500",
    },
    // ─── 기능 카드 ────────────────────────────────────────────────────────
    featureGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 12,
      justifyContent: "space-between",
      marginBottom: 24,
    },
    featureCard: {
      width: "48%",
      borderRadius: 20,
      padding: 16,
      alignItems: "center",
      justifyContent: "center",
      gap: 6,
      minHeight: 140,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.06,
      shadowRadius: 6,
      elevation: 2,
    },
    featureIcon: {
      fontSize: 40,
      marginBottom: 4,
    },
    featureTitle: {
      fontSize: 13,
      fontWeight: "800",
      color: colors.foreground,
      textAlign: "center",
      letterSpacing: -0.2,
    },
    featureDescription: {
      fontSize: 11,
      color: colors.muted,
      textAlign: "center",
      marginTop: 2,
      fontWeight: "500",
    },
  });

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* 헤더 */}
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>🍽️ 메뉴메이트</Text>
          <Text style={styles.headerSubtitle}>식사 결정을 가장 쉽게</Text>
        </View>

        {/* 도전 자극 문구 */}
        <View style={{
          backgroundColor: colors.primary + "12",
          borderLeftWidth: 4,
          borderLeftColor: colors.primary,
          paddingHorizontal: 14,
          paddingVertical: 12,
          borderRadius: 12,
          marginBottom: 24,
        }}>
          <Text style={{
            fontSize: 14,
            fontWeight: "600",
            color: colors.foreground,
            lineHeight: 20,
          }}>
            ✨ 새로운 맛의 세계에 발을 들여보세요!
          </Text>
          <Text style={{
            fontSize: 13,
            fontWeight: "500",
            color: colors.muted,
            marginTop: 6,
            lineHeight: 18,
          }}>
            오늘은 어떤 음식으로 모험을 떠날까요?
          </Text>
        </View>

        {/* 명언 카드 */}
        <View style={styles.quoteCard}>
          <Text style={styles.characterEmoji}>{todayQuote.emoji}</Text>
          <Text style={styles.quoteText}>{todayQuote.text}</Text>
        </View>

        {/* 결정 모드 */}
        <View style={styles.decisionModesContainer}>
          <Text style={styles.sectionTitle}>🎯 결정 모드</Text>
          <View style={styles.modeGrid}>
            {DECISION_MODES.map((mode) => (
              <Pressable
                key={mode.id}
                onPress={() => handleDecisionModePress(mode)}
                style={({ pressed }) => [
                  styles.modeCard,
                  { backgroundColor: mode.color },
                  pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                ]}
              >
                <Text style={styles.modeEmoji}>{mode.emoji}</Text>
                <Text style={styles.modeLabel}>{mode.label}</Text>
                <Text style={styles.modeDescription}>{mode.description}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* 더 많은 기능 */}
        <View style={{ marginBottom: 32 }}>
          <Text style={styles.sectionTitle}>✨ 더 많은 기능</Text>
          <View style={styles.featureGrid}>
            {OTHER_FEATURES.map((feature) => (
              <Pressable
                key={feature.id}
                onPress={() => handleFeaturePress(feature.route)}
                style={({ pressed }) => [
                  styles.featureCard,
                  { backgroundColor: feature.color },
                  pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                ]}
              >
                <Text style={styles.featureIcon}>{feature.icon}</Text>
                <Text style={styles.featureTitle}>{feature.title}</Text>
                <Text style={styles.featureDescription}>
                  {feature.description}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
