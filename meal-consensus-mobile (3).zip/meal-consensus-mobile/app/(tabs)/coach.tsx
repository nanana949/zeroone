import {
  ScrollView,
  Text,
  View,
  Pressable,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import * as Haptics from "expo-haptics";
import { useRef, useState, useCallback } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { addMealRecord } from "@/lib/store";
import { trpc } from "@/lib/trpc";

// ─── 타입 ──────────────────────────────────────────────────────────────────────

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  suggestions?: string[];
}

// ─── 컴포넌트 ──────────────────────────────────────────────────────────────────

export default function CoachScreen() {
  const colors = useColors();
  const scrollRef = useRef<ScrollView>(null);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "안녕하세요! 저는 메뉴메이트 AI 코치예요 🍽️\n\n오늘 어떤 상황인지 자유롭게 말씀해주세요.\n예: \"속 안 좋은데 든든한 거\", \"오늘 월급날이라 조금 써도 됨\", \"소개팅 첫 만남인데 너무 무겁지 않은 곳\"",
      suggestions: ["피곤해서 든든하게", "가볍게 먹고 싶어", "새로운 거 먹고 싶어", "오늘 특별한 날"],
    },
  ]);

  // Gemini API 뮤테이션
  const chatMutation = trpc.gemini.chatWithCoach.useMutation();

  const sendMessage = useCallback(
    async (messageText?: string) => {
      const text = messageText || input;
      if (!text.trim() || isLoading) return;

      setIsLoading(true);

      try {
        // 사용자 메시지 추가
        const userMessage: ChatMessage = {
          id: `user-${Date.now()}`,
          role: "user",
          content: text,
        };

        setMessages((prev) => [...prev, userMessage]);
        setInput("");

        // 음성 피드백
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

        // Gemini API 호출
        const conversationHistory = messages
          .filter((m) => m.role !== "assistant" || m.content.length < 500) // 너무 긴 메시지 제외
          .map((m) => ({
            role: (m.role === "assistant" ? "model" : "user") as "user" | "model",
            text: m.content,
          }));

        const response = await chatMutation.mutateAsync({
          userMessage: text,
          conversationHistory,
        });

        if (response.success) {
          const assistantMessage: ChatMessage = {
            id: `assistant-${Date.now()}`,
            role: "assistant",
            content: response.reply,
          };

          setMessages((prev) => [...prev, assistantMessage]);

          // 스크롤
          setTimeout(() => {
            scrollRef.current?.scrollToEnd({ animated: true });
          }, 100);

          // 성공 피드백
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        } else {
          // 에러 메시지
          const errorMessage: ChatMessage = {
            id: `error-${Date.now()}`,
            role: "assistant",
            content: `죄송합니다. 오류가 발생했습니다: ${response.error || "알 수 없는 오류"}`,
          };

          setMessages((prev) => [...prev, errorMessage]);

          // 에러 피드백
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        }
      } catch (error) {
        console.error("Chat error:", error);

        const errorMessage: ChatMessage = {
          id: `error-${Date.now()}`,
          role: "assistant",
          content: "죄송합니다. 일시적 오류가 발생했습니다. 다시 시도해주세요.",
        };

        setMessages((prev) => [...prev, errorMessage]);

        // 에러 피드백
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } finally {
        setIsLoading(false);
      }
    },
    [input, isLoading, messages, chatMutation]
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        className="flex-1"
      >
        <View className="flex-1 flex-col">
          {/* 헤더 */}
          <View className="bg-gradient-to-b from-primary/20 to-transparent px-6 py-4 rounded-b-3xl">
            <Text className="text-3xl font-bold text-primary">✨ AI 코치</Text>
            <Text className="text-sm text-muted mt-1">
              자연스럽게 대화하면서 맞춤 메뉴를 추천받으세요
            </Text>
          </View>

          {/* 메시지 목록 */}
          <ScrollView
            ref={scrollRef}
            className="flex-1 px-4 py-4"
            contentContainerStyle={{ paddingBottom: 20 }}
            onContentSizeChange={() =>
              scrollRef.current?.scrollToEnd({ animated: true })
            }
          >
            {messages.map((message) => (
              <View
                key={message.id}
                className={`mb-4 flex-row ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <View
                  className={`max-w-xs rounded-2xl px-4 py-3 ${
                    message.role === "user"
                      ? "bg-primary text-white"
                      : "bg-surface border border-border"
                  }`}
                >
                  <Text
                    className={`text-base leading-relaxed ${
                      message.role === "user"
                        ? "text-white"
                        : "text-foreground"
                    }`}
                  >
                    {message.content}
                  </Text>
                </View>
              </View>
            ))}

            {isLoading && (
              <View className="flex-row items-center justify-start mb-4">
                <View className="bg-surface border border-border rounded-2xl px-4 py-3">
                  <ActivityIndicator color={colors.primary} size="small" />
                </View>
              </View>
            )}
          </ScrollView>

          {/* 입력 영역 */}
          <View className="px-4 py-4 border-t border-border bg-background">
            <View className="flex-row items-end gap-3">
              <TextInput
                className="flex-1 bg-surface border border-border rounded-2xl px-4 py-3 text-foreground"
                placeholder="메뉴 추천을 받고 싶은 상황을 말씀해주세요..."
                placeholderTextColor={colors.muted}
                value={input}
                onChangeText={setInput}
                editable={!isLoading}
                multiline
              />
              <Pressable
                onPress={() => sendMessage()}
                disabled={isLoading || !input.trim()}
                className={`rounded-full p-3 ${
                  isLoading || !input.trim()
                    ? "bg-primary/50"
                    : "bg-primary"
                }`}
              >
                <Text className="text-white text-lg">→</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
