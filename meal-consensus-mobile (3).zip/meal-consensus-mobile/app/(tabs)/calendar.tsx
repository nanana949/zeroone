import { useEffect, useState, useCallback } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  Platform,
} from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  loadMealHistory,
  addMealRecord,
  type MealRecord,
} from "@/lib/store";

// ─── 더미 데이터 생성 ──────────────────────────────────────────────────────────

const SAMPLE_MEALS: MealRecord[] = [
  {
    id: "s1",
    date: new Date(Date.now() - 0 * 86400000).toISOString(),
    menuName: "비빔밥",
    category: "한식",
    withWhom: "solo",
    rating: 4,
    pricePerPerson: 9000,
  },
  {
    id: "s2",
    date: new Date(Date.now() - 1 * 86400000).toISOString(),
    menuName: "라멘",
    category: "일식",
    withWhom: "couple",
    rating: 5,
    pricePerPerson: 12000,
  },
  {
    id: "s3",
    date: new Date(Date.now() - 2 * 86400000).toISOString(),
    menuName: "삼겹살",
    category: "한식",
    withWhom: "team",
    rating: 5,
    pricePerPerson: 16000,
  },
  {
    id: "s4",
    date: new Date(Date.now() - 3 * 86400000).toISOString(),
    menuName: "파스타",
    category: "이탈리안",
    withWhom: "couple",
    rating: 4,
    pricePerPerson: 14000,
  },
  {
    id: "s5",
    date: new Date(Date.now() - 4 * 86400000).toISOString(),
    menuName: "돈가스",
    category: "일식",
    withWhom: "solo",
    rating: 3,
    pricePerPerson: 10000,
  },
  {
    id: "s6",
    date: new Date(Date.now() - 5 * 86400000).toISOString(),
    menuName: "김치찌개",
    category: "한식",
    withWhom: "team",
    rating: 4,
    pricePerPerson: 9000,
  },
  {
    id: "s7",
    date: new Date(Date.now() - 6 * 86400000).toISOString(),
    menuName: "초밥",
    category: "일식",
    withWhom: "couple",
    rating: 5,
    pricePerPerson: 22000,
  },
];

// ─── 유틸리티 ──────────────────────────────────────────────────────────────────

function getRelationshipEmoji(type: string) {
  switch (type) {
    case "solo": return "🍱";
    case "couple": return "💑";
    case "team": return "👥";
    case "family": return "👨‍👩‍👧‍👦";
    default: return "🍽️";
  }
}

function getRelationshipLabel(type: string) {
  switch (type) {
    case "solo": return "혼밥";
    case "couple": return "커플";
    case "team": return "팀";
    case "family": return "가족";
    default: return "기타";
  }
}

function getDayLabel(dateStr: string) {
  const date = new Date(dateStr);
  const today = new Date();
  const diff = Math.floor((today.getTime() - date.getTime()) / 86400000);
  if (diff === 0) return "오늘";
  if (diff === 1) return "어제";
  if (diff < 7) return `${diff}일 전`;
  return date.toLocaleDateString("ko-KR", { month: "short", day: "numeric" });
}

// ─── 통계 계산 ─────────────────────────────────────────────────────────────────

function calculateStats(meals: MealRecord[]) {
  const categoryCount: Record<string, number> = {};
  const totalSpent = meals.reduce((sum, m) => sum + (m.pricePerPerson || 0), 0);
  const avgRating =
    meals.filter((m) => m.rating).reduce((sum, m) => sum + (m.rating || 0), 0) /
    (meals.filter((m) => m.rating).length || 1);

  meals.forEach((m) => {
    categoryCount[m.category] = (categoryCount[m.category] || 0) + 1;
  });

  const topCategory = Object.entries(categoryCount).sort((a, b) => b[1] - a[1])[0];
  const uniqueCategories = Object.keys(categoryCount).length;
  const repeatRatio =
    meals.length > 0
      ? ((meals.length - uniqueCategories) / meals.length) * 100
      : 0;

  return {
    totalMeals: meals.length,
    totalSpent,
    avgRating: avgRating.toFixed(1),
    topCategory: topCategory ? topCategory[0] : "-",
    uniqueCategories,
    repeatRatio: repeatRatio.toFixed(0),
    newMenuRatio: (100 - repeatRatio).toFixed(0),
  };
}

// ─── 메인 화면 ─────────────────────────────────────────────────────────────────

export default function CalendarScreen() {
  const colors = useColors();
  const [meals, setMeals] = useState<MealRecord[]>(SAMPLE_MEALS);
  const [selectedPeriod, setSelectedPeriod] = useState<"week" | "month">("week");

  useEffect(() => {
    loadMealHistory().then((history) => {
      if (history.length > 0) {
        setMeals([...history, ...SAMPLE_MEALS]);
      }
    });
  }, []);

  const filteredMeals = meals.filter((m) => {
    const date = new Date(m.date);
    const now = new Date();
    const diff = (now.getTime() - date.getTime()) / 86400000;
    return selectedPeriod === "week" ? diff <= 7 : diff <= 30;
  });

  const stats = calculateStats(filteredMeals);

  // 최근 먹은 카테고리 (3일 이내)
  const recentCategories = [
    ...new Set(
      meals
        .filter((m) => {
          const diff = (Date.now() - new Date(m.date).getTime()) / 86400000;
          return diff <= 3;
        })
        .map((m) => m.category)
    ),
  ];

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 16 }}>
          <Text
            style={{
              fontSize: 26,
              fontWeight: "800",
              color: colors.foreground,
              letterSpacing: -0.5,
            }}
          >
            📅 메뉴 캘린더
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>
            식사 패턴을 분석해드려요
          </Text>
        </View>

        <View style={{ paddingHorizontal: 20 }}>
          {/* 기간 선택 */}
          <View
            style={{
              flexDirection: "row",
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 4,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            {(["week", "month"] as const).map((period) => (
              <Pressable
                key={period}
                onPress={() => setSelectedPeriod(period)}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 8,
                    borderRadius: 10,
                    alignItems: "center",
                    backgroundColor:
                      selectedPeriod === period ? colors.primary : "transparent",
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "700",
                    color: selectedPeriod === period ? "#FFFFFF" : colors.muted,
                  }}
                >
                  {period === "week" ? "이번 주" : "이번 달"}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* 통계 카드 */}
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              gap: 10,
              marginBottom: 20,
            }}
          >
            {[
              { label: "총 식사", value: `${stats.totalMeals}회`, emoji: "🍽️", color: colors.primary },
              { label: "평균 평점", value: `${stats.avgRating}점`, emoji: "⭐", color: colors.warning },
              { label: "반복 비율", value: `${stats.repeatRatio}%`, emoji: "🔄", color: colors.error },
              { label: "새 메뉴 비율", value: `${stats.newMenuRatio}%`, emoji: "✨", color: colors.success },
            ].map((stat) => (
              <View
                key={stat.label}
                style={{
                  flex: 1,
                  minWidth: "45%",
                  backgroundColor: stat.color + "12",
                  borderRadius: 14,
                  padding: 14,
                  borderWidth: 1.5,
                  borderColor: stat.color + "40",
                }}
              >
                <Text style={{ fontSize: 20, marginBottom: 4 }}>{stat.emoji}</Text>
                <Text
                  style={{
                    fontSize: 20,
                    fontWeight: "800",
                    color: stat.color,
                  }}
                >
                  {stat.value}
                </Text>
                <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>
                  {stat.label}
                </Text>
              </View>
            ))}
          </View>

          {/* 자주 먹은 카테고리 */}
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 16,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <Text
              style={{
                fontSize: 15,
                fontWeight: "700",
                color: colors.foreground,
                marginBottom: 12,
              }}
            >
              가장 많이 먹은 카테고리
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                marginBottom: 8,
              }}
            >
              <Text style={{ fontSize: 24 }}>🏆</Text>
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "800",
                  color: colors.primary,
                }}
              >
                {stats.topCategory}
              </Text>
            </View>
            <Text style={{ fontSize: 13, color: colors.muted }}>
              총 {stats.uniqueCategories}가지 카테고리를 먹었어요
            </Text>
          </View>

          {/* 최근 먹은 메뉴 회피 알림 */}
          {recentCategories.length > 0 && (
            <View
              style={{
                backgroundColor: colors.warning + "15",
                borderRadius: 14,
                padding: 14,
                marginBottom: 20,
                borderWidth: 1.5,
                borderColor: colors.warning + "50",
                flexDirection: "row",
                gap: 10,
                alignItems: "flex-start",
              }}
            >
              <Text style={{ fontSize: 20 }}>⚠️</Text>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "700",
                    color: colors.warning,
                    marginBottom: 4,
                  }}
                >
                  최근 3일 내 먹은 카테고리
                </Text>
                <Text style={{ fontSize: 12, color: colors.foreground }}>
                  {recentCategories.join(", ")} — 다음 추천에서 자동으로 제외돼요
                </Text>
              </View>
            </View>
          )}

          {/* 식사 기록 목록 */}
          <Text
            style={{
              fontSize: 17,
              fontWeight: "700",
              color: colors.foreground,
              marginBottom: 12,
            }}
          >
            식사 기록
          </Text>
          {filteredMeals.length === 0 ? (
            <View
              style={{
                padding: 32,
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 16,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text style={{ fontSize: 32, marginBottom: 8 }}>🍽️</Text>
              <Text
                style={{
                  fontSize: 15,
                  fontWeight: "600",
                  color: colors.muted,
                  textAlign: "center",
                }}
              >
                아직 식사 기록이 없어요
              </Text>
            </View>
          ) : (
            filteredMeals.map((meal) => (
              <View
                key={meal.id}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingVertical: 12,
                  paddingHorizontal: 14,
                  borderRadius: 14,
                  marginBottom: 8,
                  backgroundColor: colors.surface,
                  borderWidth: 1,
                  borderColor: colors.border,
                  gap: 12,
                }}
              >
                <Text style={{ fontSize: 24 }}>
                  {getRelationshipEmoji(meal.withWhom)}
                </Text>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 15,
                      fontWeight: "700",
                      color: colors.foreground,
                    }}
                  >
                    {meal.menuName}
                  </Text>
                  <View style={{ flexDirection: "row", gap: 8, marginTop: 3 }}>
                    <Text style={{ fontSize: 11, color: colors.muted }}>
                      {meal.category}
                    </Text>
                    <Text style={{ fontSize: 11, color: colors.muted }}>·</Text>
                    <Text style={{ fontSize: 11, color: colors.muted }}>
                      {getRelationshipLabel(meal.withWhom)}
                    </Text>
                    {meal.pricePerPerson && (
                      <>
                        <Text style={{ fontSize: 11, color: colors.muted }}>·</Text>
                        <Text style={{ fontSize: 11, color: colors.primary, fontWeight: "600" }}>
                          {meal.pricePerPerson.toLocaleString()}원
                        </Text>
                      </>
                    )}
                  </View>
                </View>
                <View style={{ alignItems: "flex-end", gap: 4 }}>
                  {meal.rating && (
                    <Text style={{ fontSize: 12, color: colors.warning }}>
                      {"★".repeat(meal.rating)}
                    </Text>
                  )}
                  <Text style={{ fontSize: 11, color: colors.muted }}>
                    {getDayLabel(meal.date)}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
