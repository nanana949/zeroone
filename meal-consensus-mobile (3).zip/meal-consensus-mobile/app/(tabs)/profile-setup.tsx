import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { useState } from "react";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";

type UserProfile = {
  gender: "여자" | "남자" | null;
  ageGroup: "20대" | "30대" | "40대" | "50대+" | null;
  situation: string | null;
  allergens?: string[];
};

const ALLERGENS = [
  { id: "seafood", label: "🦐 해산물", color: "#FFD9D0" },
  { id: "peanut", label: "🥜 땅콩", color: "#FFE8D6" },
  { id: "egg", label: "🥚 계란", color: "#FFF4D6" },
  { id: "milk", label: "🥛 우유", color: "#E8D5F2" },
  { id: "wheat", label: "🌾 밀", color: "#D4F1D4" },
  { id: "soy", label: "🫘 콩", color: "#D6E8F7" },
  { id: "nuts", label: "🌰 견과류", color: "#FFE8B6" },
  { id: "spicy", label: "🌶️ 매운맛", color: "#FFD9D0" },
  { id: "garlic", label: "🧄 마늘", color: "#FFE8D6" },
  { id: "onion", label: "🧅 양파", color: "#FFF4D6" },
];

type Restaurant = {
  id: number;
  name: string;
  category: string;
  address: string;
  rating: number;
  deliveryTime: string;
  deliveryFee: number;
  minOrder: number;
};

export default function ProfileSetupScreen() {
  const router = useRouter();
  const colors = useColors();
  const [profile, setProfile] = useState<UserProfile>({
    gender: null,
    ageGroup: null,
    situation: null,
    allergens: [],
  });
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<any>(null);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [showRestaurants, setShowRestaurants] = useState(false);

  // tRPC 쿼리
  const gendersQuery = trpc.menuRecommendations.getGenders.useQuery();
  const ageGroupsQuery = trpc.menuRecommendations.getAgeGroups.useQuery();
  const situationsQuery = trpc.menuRecommendations.getSituations.useQuery();

  const toggleAllergen = (allergenId: string) => {
    setProfile((prev) => ({
      ...prev,
      allergens: prev.allergens?.includes(allergenId)
        ? prev.allergens.filter((id) => id !== allergenId)
        : [...(prev.allergens || []), allergenId],
    }));
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  // 프로필 저장
  const saveProfile = async () => {
    if (profile.gender && profile.ageGroup && profile.situation) {
      try {
        await AsyncStorage.setItem("userProfile", JSON.stringify(profile));
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (error) {
        console.error("프로필 저장 실패:", error);
      }
    }
  };

  // 추천 요청
  const handleGetRecommendation = async () => {
    if (!profile.gender || !profile.ageGroup || !profile.situation) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      // API 호출 (fetch 사용)
      const response = await fetch(
        `/api/trpc/menuRecommendations.getRecommendations?input=${encodeURIComponent(
          JSON.stringify({
            gender: profile.gender,
            ageGroup: profile.ageGroup,
            situation: profile.situation,
          })
        )}`,
        { credentials: "include" }
      );

      const data = await response.json();
      const result = data.result?.data || data;

      if (!result) {
        throw new Error("API 응답 없음");
      }

      setRecommendation(result);
      await saveProfile();
      
      // 추천 메뉴로 식당 검색
      if (result.menus && result.menus.length > 0) {
        try {
          const menuNames = result.menus.map((m: any) => m.name);
          const restaurantResponse = await fetch(
            `/api/trpc/restaurantsSearch.recommendRestaurants?input=${encodeURIComponent(
              JSON.stringify({
                menus: menuNames,
                limit: 10,
              })
            )}`,
            { credentials: "include" }
          );
          const restaurantData = await restaurantResponse.json();
          const restaurantList = restaurantData.result?.data?.restaurants || [];
          setRestaurants(restaurantList);
          setShowRestaurants(true);
        } catch (error) {
          console.error("식당 검색 실패:", error);
        }
      }
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("추천 요청 실패:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  const styles = StyleSheet.create({
    headerCard: {
      backgroundColor: colors.primary,
      borderRadius: 20,
      padding: 20,
      marginBottom: 20,
      gap: 8,
    },
    headerTitle: {
      fontSize: 28,
      fontWeight: "800",
      color: "#fff",
    },
    headerSubtitle: {
      fontSize: 13,
      color: "rgba(255,255,255,0.9)",
    },
    sectionTitle: {
      fontSize: 16,
      fontWeight: "700",
      color: colors.foreground,
      marginBottom: 12,
      marginTop: 16,
    },
    buttonGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 10,
      marginBottom: 16,
    },
    optionButton: {
      flex: 1,
      minWidth: "45%",
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 12,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 2,
      borderColor: colors.border,
      gap: 6,
    },
    optionButtonSelected: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    optionEmoji: {
      fontSize: 24,
    },
    optionText: {
      fontSize: 12,
      fontWeight: "600",
      color: colors.foreground,
      textAlign: "center",
    },
    optionTextSelected: {
      color: "#fff",
    },
    recommendationCard: {
      backgroundColor: colors.surface,
      borderRadius: 20,
      padding: 20,
      gap: 12,
      borderWidth: 2,
      borderColor: colors.primary,
      marginTop: 20,
    },
    recommendationTitle: {
      fontSize: 18,
      fontWeight: "700",
      color: colors.foreground,
    },
    recommendationMessage: {
      fontSize: 12,
      color: colors.muted,
      marginBottom: 12,
    },
    menuItem: {
      backgroundColor: colors.background,
      borderRadius: 12,
      padding: 12,
      marginBottom: 8,
      gap: 4,
    },
    menuName: {
      fontSize: 14,
      fontWeight: "600",
      color: colors.foreground,
    },
    menuReason: {
      fontSize: 12,
      color: colors.muted,
      lineHeight: 18,
    },
    submitButton: {
      backgroundColor: colors.primary,
      borderRadius: 16,
      padding: 16,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 20,
      marginBottom: 20,
      gap: 8,
    },
    submitButtonText: {
      fontSize: 16,
      fontWeight: "700",
      color: "#fff",
    },
    profileBadges: {
      flexDirection: "row",
      gap: 8,
      marginBottom: 16,
      flexWrap: "wrap",
    },
    badge: {
      backgroundColor: colors.primary,
      borderRadius: 8,
      paddingHorizontal: 12,
      paddingVertical: 6,
    },
    badgeText: {
      fontSize: 12,
      fontWeight: "600",
      color: "#fff",
    },
    restaurantItem: {
      backgroundColor: colors.background,
      borderRadius: 12,
      padding: 12,
      marginBottom: 8,
      gap: 4,
      borderLeftWidth: 4,
      borderLeftColor: colors.primary,
    },
    restaurantHeader: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
    },
    restaurantName: {
      fontSize: 14,
      fontWeight: "600",
      color: colors.foreground,
      flex: 1,
    },
    restaurantRating: {
      fontSize: 12,
      fontWeight: "600",
      color: colors.primary,
    },
    restaurantCategory: {
      fontSize: 12,
      color: colors.muted,
    },
    restaurantInfo: {
      fontSize: 11,
      color: colors.muted,
      lineHeight: 16,
    },
    allergenGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 10,
      marginBottom: 16,
    },
    allergenButton: {
      flex: 1,
      minWidth: "30%",
      borderRadius: 12,
      padding: 12,
      alignItems: "center",
      justifyContent: "center",
      gap: 6,
      borderWidth: 2,
      borderColor: "transparent",
    },
    allergenButtonSelected: {
      borderColor: colors.primary,
      borderWidth: 3,
    },
    allergenEmoji: {
      fontSize: 24,
    },
    allergenLabel: {
      fontSize: 11,
      fontWeight: "600",
      color: colors.foreground,
      textAlign: "center",
    },
  });

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="p-4">
        {/* 헤더 */}
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>👤 맞춤 추천 설정</Text>
          <Text style={styles.headerSubtitle}>
            당신의 정보를 입력하면 최적의 메뉴를 추천해드려요!
          </Text>
        </View>

        {/* 성별 선택 */}
        <Text style={styles.sectionTitle}>성별</Text>
        <View style={styles.buttonGrid}>
          {gendersQuery.data?.map((gender) => (
            <Pressable
              key={gender.id}
              style={({ pressed }) => [
                styles.optionButton,
                profile.gender === gender.id && styles.optionButtonSelected,
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setProfile({ ...profile, gender: gender.id as any });
              }}
            >
              <Text style={styles.optionEmoji}>{gender.emoji}</Text>
              <Text
                style={[
                  styles.optionText,
                  profile.gender === gender.id && styles.optionTextSelected,
                ]}
              >
                {gender.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* 나이 선택 */}
        <Text style={styles.sectionTitle}>나이대</Text>
        <View style={styles.buttonGrid}>
          {ageGroupsQuery.data?.map((ageGroup) => (
            <Pressable
              key={ageGroup.id}
              style={({ pressed }) => [
                styles.optionButton,
                profile.ageGroup === ageGroup.id && styles.optionButtonSelected,
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setProfile({ ...profile, ageGroup: ageGroup.id as any });
              }}
            >
              <Text style={styles.optionText}>{ageGroup.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* 상황 선택 */}
        <Text style={styles.sectionTitle}>현재 상황</Text>
        <View style={styles.buttonGrid}>
          {situationsQuery.data?.map((situation) => (
            <Pressable
              key={situation}
              style={({ pressed }) => [
                styles.optionButton,
                profile.situation === situation && styles.optionButtonSelected,
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setProfile({ ...profile, situation });
              }}
            >
              <Text
                style={[
                  styles.optionText,
                  profile.situation === situation && styles.optionTextSelected,
                ]}
              >
                {situation}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* 알레르기/식이제한 선택 */}
        <Text style={styles.sectionTitle}>
          🚫 싫어하는 음식 ({profile.allergens?.length || 0})
        </Text>
        <View style={styles.allergenGrid}>
          {ALLERGENS.map((allergen) => {
            const isSelected = profile.allergens?.includes(allergen.id);
            return (
              <Pressable
                key={allergen.id}
                onPress={() => toggleAllergen(allergen.id)}
                style={({ pressed }) => [
                  styles.allergenButton,
                  { backgroundColor: allergen.color },
                  isSelected && styles.allergenButtonSelected,
                  pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
                ]}
              >
                <Text style={styles.allergenEmoji}>
                  {allergen.label.split(" ")[0]}
                </Text>
                <Text style={styles.allergenLabel}>
                  {allergen.label.split(" ")[1]}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {/* 선택된 프로필 표시 */}
        {profile.gender && profile.ageGroup && profile.situation && (
          <View style={styles.profileBadges}>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>👤 {profile.gender}</Text>
            </View>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>📅 {profile.ageGroup}</Text>
            </View>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>🎯 {profile.situation}</Text>
            </View>
            {profile.allergens && profile.allergens.length > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>🚫 {profile.allergens.length}개 제외</Text>
              </View>
            )}
          </View>
        )}

        {/* 추천 요청 버튼 */}
        <Pressable
          style={({ pressed }) => [
            styles.submitButton,
            pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
          ]}
          onPress={handleGetRecommendation}
          disabled={
            loading ||
            !profile.gender ||
            !profile.ageGroup ||
            !profile.situation
          }
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Text style={styles.submitButtonText}>🍽️ 맞춤 메뉴 추천받기</Text>
            </>
          )}
        </Pressable>

        {/* 추천 결과 */}
        {recommendation && (
          <View style={styles.recommendationCard}>
            <Text style={styles.recommendationTitle}>✨ 추천 메뉴</Text>
            <Text style={styles.recommendationMessage}>
              {recommendation.message}
            </Text>

            {recommendation.menus?.map((menu: any, index: number) => (
              <View key={index} style={styles.menuItem}>
                <Text style={styles.menuName}>{menu.name}</Text>
                <Text style={styles.menuReason}>{menu.reason}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
