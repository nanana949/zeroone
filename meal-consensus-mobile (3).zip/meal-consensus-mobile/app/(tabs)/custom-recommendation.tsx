import { ScrollView, Text, View, Pressable, Platform, useWindowDimensions } from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  type WeatherType,
  type TimeSlot,
  type DayType,
  type CategoryScore,
  WEATHER_OPTIONS,
  TIME_OPTIONS,
  DAY_OPTIONS,
  WEATHER_EMOJI,
  TIME_EMOJI,
  DAY_EMOJI,
  CATEGORY_EMOJI,
  calculateCategoryScores,
} from "@/lib/category-weights";
import {
  type FoodCategory,
  CATEGORY_BUTTON_CONFIG,
  CATEGORY_MENUS,
  filterMenusByTags,
  type TaggedMenu,
} from "@/lib/category-menu-db";

type Step = "weather" | "time" | "day" | "result" | "menu-filter" | "menu-result";

// ─── 공통 버튼 ──────────────────────────────────────────────────────

function SelectButton({
  label,
  emoji,
  isSelected,
  onPress,
}: {
  label: string;
  emoji?: string;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        minWidth: "42%",
        borderRadius: 16,
        paddingVertical: 18,
        paddingHorizontal: 12,
        alignItems: "center" as const,
        justifyContent: "center" as const,
        backgroundColor: isSelected ? colors.primary : colors.surface,
        borderWidth: isSelected ? 0 : 1.5,
        borderColor: isSelected ? "transparent" : colors.border,
        marginHorizontal: 5,
        marginVertical: 5,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: isSelected ? 4 : 2 },
        shadowOpacity: isSelected ? 0.25 : 0.06,
        shadowRadius: isSelected ? 8 : 4,
        elevation: isSelected ? 6 : 2,
        transform: [{ scale: pressed ? 0.96 : 1 }],
        opacity: pressed ? 0.9 : 1,
      })}
    >
      {emoji ? <Text style={{ fontSize: 28, marginBottom: 6 }}>{emoji}</Text> : null}
      <Text
        style={{
          fontSize: 14,
          fontWeight: "700",
          color: isSelected ? "#FFFFFF" : colors.foreground,
          textAlign: "center",
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 필터 칩 ─────────────────────────────────────────────────────────

function FilterChip({
  label,
  isSelected,
  onPress,
}: {
  label: string;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        paddingHorizontal: 14,
        paddingVertical: 8,
        borderRadius: 20,
        marginRight: 8,
        marginBottom: 8,
        backgroundColor: isSelected ? colors.primary : colors.surface,
        borderWidth: isSelected ? 0 : 1.5,
        borderColor: isSelected ? "transparent" : colors.border,
        opacity: pressed ? 0.8 : 1,
        transform: [{ scale: pressed ? 0.95 : 1 }],
      })}
    >
      <Text
        style={{
          fontSize: 13,
          fontWeight: "600",
          color: isSelected ? "#FFFFFF" : colors.foreground,
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 선택된 메뉴 카드 (큰 카드) ───────────────────────────────────────

function SelectedMenuCard({
  menu,
  category,
  onNavigateToRestaurants,
}: {
  menu: TaggedMenu;
  category: FoodCategory;
  onNavigateToRestaurants: (menuName: string) => void;
}) {
  const colors = useColors();
  const tagEntries = Object.entries(menu.tags).filter(([, value]) => value);

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 20,
        padding: 24,
        marginBottom: 20,
        borderWidth: 2,
        borderColor: colors.primary,
        gap: 16,
      }}
    >
      {/* 카테고리 배지 */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
        <Text style={{ fontSize: 32 }}>{CATEGORY_EMOJI[category]}</Text>
        <View>
          <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "600" }}>추천 메뉴</Text>
          <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>
            {menu.name}
          </Text>
        </View>
      </View>

      {/* 태그 */}
      {tagEntries.length > 0 && (
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {tagEntries.map(([key, value]) => (
            <View
              key={key}
              style={{
                backgroundColor: `${colors.primary}15`,
                borderRadius: 10,
                paddingHorizontal: 12,
                paddingVertical: 6,
              }}
            >
              <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>
                {key}: {value}
              </Text>
            </View>
          ))}
        </View>
      )}

      {/* 식당 찾기 버튼 */}
      <Pressable
        onPress={() => onNavigateToRestaurants(menu.name)}
        style={({ pressed }) => ({
          backgroundColor: colors.primary,
          borderRadius: 14,
          paddingVertical: 14,
          alignItems: "center",
          opacity: pressed ? 0.85 : 1,
          transform: [{ scale: pressed ? 0.98 : 1 }],
        })}
      >
        <Text style={{ fontSize: 15, fontWeight: "700", color: "#fff" }}>
          🍽️ 주변 {menu.name} 찾기
        </Text>
      </Pressable>
    </View>
  );
}

// ─── 메인 화면 ─────────────────────────────────────────────────────

export default function CustomRecommendationScreen() {
  const colors = useColors();
  const router = useRouter();
  const { width } = useWindowDimensions();

  const [step, setStep] = useState<Step>("weather");
  const [selectedWeather, setSelectedWeather] = useState<WeatherType | null>(null);
  const [selectedTime, setSelectedTime] = useState<TimeSlot | null>(null);
  const [selectedDay, setSelectedDay] = useState<DayType | null>(null);
  const [results, setResults] = useState<CategoryScore[]>([]);

  // 메뉴 필터 단계
  const [selectedCategory, setSelectedCategory] = useState<FoodCategory | null>(null);
  const [activeFilters, setActiveFilters] = useState<Record<string, string | null>>({});
  const [filteredMenus, setFilteredMenus] = useState<TaggedMenu[]>([]);
  const [currentMenuIndex, setCurrentMenuIndex] = useState(0);

  const haptic = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const goNext = () => {
    haptic();
    if (step === "weather") setStep("time");
    else if (step === "time") setStep("day");
    else if (step === "day") {
      setResults(calculateCategoryScores(selectedWeather, selectedTime, selectedDay));
      setStep("result");
    }
  };

  const goPrev = () => {
    haptic();
    if (step === "time") setStep("weather");
    else if (step === "day") setStep("time");
    else if (step === "result") setStep("day");
    else if (step === "menu-filter") setStep("result");
    else if (step === "menu-result") setStep("menu-filter");
  };

  const reset = () => {
    haptic();
    setStep("weather");
    setSelectedWeather(null);
    setSelectedTime(null);
    setSelectedDay(null);
    setResults([]);
    setSelectedCategory(null);
    setActiveFilters({});
    setFilteredMenus([]);
    setCurrentMenuIndex(0);
  };

  // 카테고리 선택 → 메뉴 필터 단계로
  const handleCategorySelect = (category: FoodCategory) => {
    haptic();
    setSelectedCategory(category);
    const sections = CATEGORY_BUTTON_CONFIG[category];
    const initialFilters: Record<string, string | null> = {};
    sections.forEach((s) => {
      initialFilters[s.sectionName] = null;
    });
    setActiveFilters(initialFilters);
    setStep("menu-filter");
  };

  // 필터 토글
  const toggleFilter = (sectionName: string, value: string) => {
    haptic();
    setActiveFilters((prev) => ({
      ...prev,
      [sectionName]: prev[sectionName] === value ? null : value,
    }));
  };

  // 메뉴 추천 실행
  const showMenuResults = () => {
    haptic();
    if (!selectedCategory) return;
    const menus = filterMenusByTags(selectedCategory, activeFilters);
    setFilteredMenus(menus);
    setCurrentMenuIndex(0);
    setStep("menu-result");
  };

  // 다른 메뉴 추천
  const nextMenu = () => {
    haptic();
    if (currentMenuIndex < filteredMenus.length - 1) {
      setCurrentMenuIndex(currentMenuIndex + 1);
    } else {
      // 마지막 메뉴면 처음으로
      setCurrentMenuIndex(0);
    }
  };

  // 식당탭으로 이동
  const navigateToRestaurants = (menuName: string) => {
    haptic();
    router.push({
      pathname: "/(tabs)/restaurants",
      params: { recommendedMenu: menuName },
    });
  };

  const progress = step === "weather" ? 1 : step === "time" ? 2 : step === "day" ? 3 : 4;

  const stepTitle: Record<Step, string> = {
    weather: "오늘 날씨는 어때요?",
    time: "지금 시간대는?",
    day: "오늘은 무슨 요일?",
    result: "추천 카테고리 순위",
    "menu-filter": `${selectedCategory ?? ""} 메뉴 필터`,
    "menu-result": `${selectedCategory ?? ""} 추천 메뉴`,
  };

  const stepSub: Record<Step, string> = {
    weather: "날씨에 맞는 음식을 추천해드릴게요",
    time: "시간대에 어울리는 메뉴를 찾아볼게요",
    day: "요일에 따라 점수가 달라져요",
    result: "카테고리를 탭하면 메뉴를 볼 수 있어요",
    "menu-filter": "원하는 조건을 선택하세요 (복수 선택 가능)",
    "menu-result": `총 ${filteredMenus.length}개 메뉴 중 ${currentMenuIndex + 1}번째`,
  };

  const currentMenu = filteredMenus[currentMenuIndex];

  return (
    <ScreenContainer className="flex-1">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 }}>
          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground }}>
            🎯 맞춤추천
          </Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>
            조건을 선택하면 최적의 메뉴를 추천해드려요
          </Text>
        </View>

        {/* 진행 바 */}
        {(step === "weather" || step === "time" || step === "day" || step === "result") && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <View
              style={{
                height: 4,
                backgroundColor: `${colors.primary}20`,
                borderRadius: 2,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  height: "100%",
                  width: `${(progress / 4) * 100}%`,
                  backgroundColor: colors.primary,
                  borderRadius: 2,
                }}
              />
            </View>
            <Text style={{ fontSize: 11, color: colors.muted, marginTop: 6 }}>
              {progress}/4 단계
            </Text>
          </View>
        )}

        {/* 타이틀 */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <Text style={{ fontSize: 20, fontWeight: "800", color: colors.foreground }}>
            {stepTitle[step]}
          </Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>
            {stepSub[step]}
          </Text>
        </View>

        {/* ── 날씨 선택 ── */}
        {step === "weather" && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {WEATHER_OPTIONS.map((option) => (
                <SelectButton
                  key={option}
                  emoji={WEATHER_EMOJI[option]}
                  label={option}
                  isSelected={selectedWeather === option}
                  onPress={() => setSelectedWeather(option)}
                />
              ))}
            </View>
          </View>
        )}

        {/* ── 시간 선택 ── */}
        {step === "time" && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {TIME_OPTIONS.map((option) => (
                <SelectButton
                  key={option}
                  emoji={TIME_EMOJI[option]}
                  label={option}
                  isSelected={selectedTime === option}
                  onPress={() => setSelectedTime(option)}
                />
              ))}
            </View>
          </View>
        )}

        {/* ── 요일 선택 ── */}
        {step === "day" && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {DAY_OPTIONS.map((option) => (
                <SelectButton
                  key={option}
                  emoji={DAY_EMOJI[option]}
                  label={option}
                  isSelected={selectedDay === option}
                  onPress={() => setSelectedDay(option)}
                />
              ))}
            </View>
          </View>
        )}

        {/* ── 카테고리 결과 ── */}
        {step === "result" && (
          <View style={{ paddingHorizontal: 20 }}>
            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12, textAlign: "center" }}>
              👇 카테고리를 탭하면 메뉴를 추천해드려요
            </Text>

            {results.map((item, index) => {
              const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}위`;
              return (
                <Pressable
                  key={item.category}
                  onPress={() => handleCategorySelect(item.category)}
                  style={({ pressed }) => ({
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 12,
                    backgroundColor: index < 3 ? `${colors.primary}15` : colors.surface,
                    borderRadius: 16,
                    padding: 14,
                    marginBottom: 10,
                    borderWidth: 1,
                    borderColor: index < 3 ? colors.primary : colors.border,
                    opacity: pressed ? 0.7 : 1,
                    transform: [{ scale: pressed ? 0.98 : 1 }],
                  })}
                >
                  <Text style={{ fontSize: 24 }}>{medal}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>
                      {item.category}
                    </Text>
                    <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
                      점수: {item.score}점
                    </Text>
                  </View>
                  <Text style={{ fontSize: 20 }}>{CATEGORY_EMOJI[item.category]}</Text>
                </Pressable>
              );
            })}
          </View>
        )}

        {/* ── 메뉴 필터 ── */}
        {step === "menu-filter" && selectedCategory && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 카테고리 뱃지 */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                marginBottom: 20,
                backgroundColor: `${colors.primary}12`,
                borderRadius: 12,
                padding: 12,
                borderWidth: 1,
                borderColor: `${colors.primary}25`,
              }}
            >
              <Text style={{ fontSize: 22 }}>{CATEGORY_EMOJI[selectedCategory]}</Text>
              <View>
                <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>
                  {selectedCategory}
                </Text>
                <Text style={{ fontSize: 12, color: colors.muted }}>
                  총 {CATEGORY_MENUS[selectedCategory]?.length ?? 0}개 메뉴
                </Text>
              </View>
            </View>

            {/* 섹션별 필터 */}
            {CATEGORY_BUTTON_CONFIG[selectedCategory].map((section) => (
              <View key={section.sectionName} style={{ marginBottom: 20 }}>
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: "700",
                    color: colors.foreground,
                    marginBottom: 10,
                  }}
                >
                  {section.sectionName}
                </Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                  {/* 상관없음 칩 */}
                  <FilterChip
                    label="상관없음"
                    isSelected={activeFilters[section.sectionName] === null}
                    onPress={() =>
                      toggleFilter(section.sectionName, activeFilters[section.sectionName] ?? "")
                    }
                  />
                  {section.buttons.map((btn) => (
                    <FilterChip
                      key={btn}
                      label={btn}
                      isSelected={activeFilters[section.sectionName] === btn}
                      onPress={() => toggleFilter(section.sectionName, btn)}
                    />
                  ))}
                </View>
              </View>
            ))}

            {/* 예상 결과 수 */}
            <View
              style={{
                backgroundColor: `${colors.primary}08`,
                borderRadius: 10,
                padding: 12,
                marginBottom: 4,
                alignItems: "center",
              }}
            >
              <Text style={{ fontSize: 14, color: colors.primary, fontWeight: "600" }}>
                예상 결과: {filterMenusByTags(selectedCategory, activeFilters).length}개 메뉴
              </Text>
            </View>
          </View>
        )}

        {/* ── 메뉴 결과 (단일 메뉴 표시) ── */}
        {step === "menu-result" && selectedCategory && currentMenu && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 적용된 필터 요약 */}
            <View
              style={{
                backgroundColor: `${colors.primary}08`,
                borderRadius: 12,
                padding: 12,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: `${colors.primary}20`,
              }}
            >
              <Text style={{ fontSize: 12, fontWeight: "600", color: colors.muted, marginBottom: 6 }}>
                적용된 필터
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {Object.entries(activeFilters).map(([key, val]) =>
                  val ? (
                    <View
                      key={key}
                      style={{
                        backgroundColor: `${colors.primary}20`,
                        borderRadius: 8,
                        paddingHorizontal: 8,
                        paddingVertical: 3,
                      }}
                    >
                      <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>
                        {key}: {val}
                      </Text>
                    </View>
                  ) : null
                )}
                {Object.values(activeFilters).every((v) => !v) && (
                  <Text style={{ fontSize: 13, color: colors.muted }}>필터 없음 (전체)</Text>
                )}
              </View>
            </View>

            {/* 선택된 메뉴 카드 */}
            <SelectedMenuCard
              menu={currentMenu}
              category={selectedCategory}
              onNavigateToRestaurants={navigateToRestaurants}
            />

            {/* 다른 메뉴 추천 버튼 */}
            <Pressable
              onPress={nextMenu}
              style={({ pressed }) => ({
                backgroundColor: `${colors.primary}15`,
                borderWidth: 2,
                borderColor: colors.primary,
                borderRadius: 14,
                paddingVertical: 14,
                alignItems: "center",
                marginBottom: 12,
                opacity: pressed ? 0.7 : 1,
                transform: [{ scale: pressed ? 0.98 : 1 }],
              })}
            >
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.primary }}>
                🔄 다른 메뉴 추천받기
              </Text>
            </Pressable>

            {/* 진행 상황 표시 */}
            <Text style={{ fontSize: 12, color: colors.muted, textAlign: "center", marginBottom: 12 }}>
              {currentMenuIndex + 1} / {filteredMenus.length}
            </Text>
          </View>
        )}

        {step === "menu-result" && filteredMenus.length === 0 && (
          <View style={{ paddingHorizontal: 20, alignItems: "center", paddingVertical: 40 }}>
            <Text style={{ fontSize: 40, marginBottom: 12 }}>😅</Text>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 6 }}>
              조건에 맞는 메뉴가 없어요
            </Text>
            <Text style={{ fontSize: 14, color: colors.muted, textAlign: "center" }}>
              필터를 조정해보세요
            </Text>
          </View>
        )}
      </ScrollView>

      {/* ── 하단 버튼 ── */}
      <View style={{ paddingHorizontal: 20, paddingBottom: 20, gap: 10 }}>
        {step !== "weather" && (
          <Pressable
            onPress={goPrev}
            style={({ pressed }) => ({
              backgroundColor: colors.surface,
              borderWidth: 1.5,
              borderColor: colors.border,
              borderRadius: 12,
              paddingVertical: 12,
              alignItems: "center",
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>
              ← 이전
            </Text>
          </Pressable>
        )}

        {step !== "menu-result" && step !== "menu-filter" && (
          <Pressable
            onPress={goNext}
            disabled={
              (step === "weather" && !selectedWeather) ||
              (step === "time" && !selectedTime) ||
              (step === "day" && !selectedDay)
            }
            style={({ pressed }) => ({
              backgroundColor:
                (step === "weather" && !selectedWeather) ||
                (step === "time" && !selectedTime) ||
                (step === "day" && !selectedDay)
                  ? colors.border
                  : colors.primary,
              borderRadius: 12,
              paddingVertical: 12,
              alignItems: "center",
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <Text
              style={{
                fontSize: 14,
                fontWeight: "700",
                color:
                  (step === "weather" && !selectedWeather) ||
                  (step === "time" && !selectedTime) ||
                  (step === "day" && !selectedDay)
                    ? colors.muted
                    : "#fff",
              }}
            >
              다음 →
            </Text>
          </Pressable>
        )}

        {step === "menu-filter" && (
          <Pressable
            onPress={showMenuResults}
            style={({ pressed }) => ({
              backgroundColor: colors.primary,
              borderRadius: 12,
              paddingVertical: 12,
              alignItems: "center",
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <Text style={{ fontSize: 14, fontWeight: "700", color: "#fff" }}>
              메뉴 추천받기 →
            </Text>
          </Pressable>
        )}

        <Pressable
          onPress={reset}
          style={({ pressed }) => ({
            backgroundColor: `${colors.primary}08`,
            borderWidth: 1,
            borderColor: `${colors.primary}20`,
            borderRadius: 12,
            paddingVertical: 12,
            alignItems: "center",
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.primary }}>
            🔄 처음부터 다시
          </Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
