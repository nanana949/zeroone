import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import {
  WORLDCUP_CATEGORIES,
  buildTournamentMenus,
  type WorldcupMenu,
} from '@/lib/worldcup-db';

// ─── 타입 ────────────────────────────────────────────────────────────────────

type Step = 'category' | 'size' | 'tournament' | 'result';

interface Match {
  id: string;
  menu1: WorldcupMenu;
  menu2: WorldcupMenu;
  winner?: WorldcupMenu;
}

interface Round {
  name: string;
  matches: Match[];
}

// ─── 유틸 ────────────────────────────────────────────────────────────────────

function getRoundName(count: number): string {
  if (count === 2) return '결승';
  if (count === 4) return '4강';
  if (count === 8) return '8강';
  if (count === 16) return '16강';
  if (count === 32) return '32강';
  return `${count}강`;
}

function buildFirstRound(menus: WorldcupMenu[]): Round {
  const matches: Match[] = [];
  for (let i = 0; i < menus.length; i += 2) {
    matches.push({
      id: `r-${i}`,
      menu1: menus[i],
      menu2: menus[i + 1],
    });
  }
  return { name: getRoundName(menus.length), matches };
}

// ─── 메인 컴포넌트 ───────────────────────────────────────────────────────────

export default function FoodWorldcupScreen() {
  const router = useRouter();
  const colors = useColors();

  const [step, setStep] = useState<Step>('category');
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([]);
  const [tournamentSize, setTournamentSize] = useState<16 | 32>(16);
  const [rounds, setRounds] = useState<Round[]>([]);
  const [currentRoundIndex, setCurrentRoundIndex] = useState(0);
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);
  const [champion, setChampion] = useState<WorldcupMenu | null>(null);

  // ── 카테고리 토글 ──────────────────────────────────────────────────────────

  const toggleCategory = useCallback((id: string) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setSelectedCategoryIds(prev =>
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  }, []);

  // ── 토너먼트 시작 ──────────────────────────────────────────────────────────

  const startTournament = useCallback(() => {
    const menus = buildTournamentMenus(selectedCategoryIds, tournamentSize);
    if (menus.length < tournamentSize) return;

    const firstRound = buildFirstRound(menus);
    setRounds([firstRound]);
    setCurrentRoundIndex(0);
    setCurrentMatchIndex(0);
    setChampion(null);
    setStep('tournament');
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }, [selectedCategoryIds, tournamentSize]);

  // ── 승자 선택 ──────────────────────────────────────────────────────────────

  const selectWinner = useCallback(
    (winner: WorldcupMenu) => {
      if (Platform.OS !== 'web') {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }

      const updatedRounds = rounds.map(r => ({ ...r, matches: r.matches.map(m => ({ ...m })) }));
      updatedRounds[currentRoundIndex].matches[currentMatchIndex].winner = winner;

      const currentRoundMatches = updatedRounds[currentRoundIndex].matches;
      const isLastMatchInRound = currentMatchIndex === currentRoundMatches.length - 1;

      if (isLastMatchInRound) {
        const winners = currentRoundMatches.map(m =>
          m.id === updatedRounds[currentRoundIndex].matches[currentMatchIndex].id
            ? winner
            : m.winner!
        );

        if (winners.length === 1) {
          // 우승자 결정
          setRounds(updatedRounds);
          setChampion(winners[0]);
          setStep('result');
          if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          }
        } else {
          // 다음 라운드 생성
          const nextRound = buildFirstRound(winners);
          updatedRounds.push(nextRound);
          setRounds(updatedRounds);
          setCurrentRoundIndex(currentRoundIndex + 1);
          setCurrentMatchIndex(0);
        }
      } else {
        setRounds(updatedRounds);
        setCurrentMatchIndex(currentMatchIndex + 1);
      }
    },
    [rounds, currentRoundIndex, currentMatchIndex]
  );

  // ── 다시 시작 ──────────────────────────────────────────────────────────────

  const restart = useCallback(() => {
    setStep('category');
    setSelectedCategoryIds([]);
    setTournamentSize(16);
    setRounds([]);
    setCurrentRoundIndex(0);
    setCurrentMatchIndex(0);
    setChampion(null);
  }, []);

  // ─── 렌더: 카테고리 선택 ──────────────────────────────────────────────────

  if (step === 'category') {
    const canProceed = selectedCategoryIds.length > 0;

    return (
      <ScreenContainer>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* 헤더 */}
          <View style={styles.header}>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>
              🏆 음식 월드컵
            </Text>
            <Text style={[styles.headerSub, { color: colors.muted }]}>
              좋아하는 카테고리를 선택하세요
            </Text>
            <Text style={[styles.headerHint, { color: colors.muted }]}>
              여러 개 선택 가능 · {selectedCategoryIds.length}개 선택됨
            </Text>
          </View>

          {/* 카테고리 그리드 */}
          <View style={styles.categoryGrid}>
            {WORLDCUP_CATEGORIES.map(cat => {
              const isSelected = selectedCategoryIds.includes(cat.id);
              return (
                <Pressable
                  key={cat.id}
                  onPress={() => toggleCategory(cat.id)}
                  style={({ pressed }) => [
                    styles.categoryCard,
                    {
                      backgroundColor: isSelected ? colors.primary : colors.surface,
                      borderColor: isSelected ? colors.primary : colors.border,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text style={styles.categoryEmoji}>{cat.emoji}</Text>
                  <Text
                    style={[
                      styles.categoryName,
                      { color: isSelected ? '#ffffff' : colors.foreground },
                    ]}
                    numberOfLines={2}
                  >
                    {cat.name}
                  </Text>
                  <Text
                    style={[
                      styles.categoryCount,
                      { color: isSelected ? 'rgba(255,255,255,0.8)' : colors.muted },
                    ]}
                  >
                    {cat.menus.length}개
                  </Text>
                  {isSelected && (
                    <View style={styles.checkBadge}>
                      <Text style={styles.checkText}>✓</Text>
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* 다음 버튼 */}
          <View style={styles.bottomSection}>
            <Pressable
              onPress={() => canProceed && setStep('size')}
              style={({ pressed }) => [
                styles.primaryButton,
                {
                  backgroundColor: canProceed ? colors.primary : colors.border,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text style={[styles.primaryButtonText, { color: canProceed ? '#ffffff' : colors.muted }]}>
                다음 단계 →
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ─── 렌더: 16강/32강 선택 ────────────────────────────────────────────────

  if (step === 'size') {
    // 선택한 카테고리의 총 메뉴 수
    const totalMenus = WORLDCUP_CATEGORIES
      .filter(c => selectedCategoryIds.includes(c.id))
      .reduce((sum, c) => sum + c.menus.length, 0);
    const can32 = totalMenus >= 32;

    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* 헤더 */}
          <View style={styles.header}>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>
              🏆 음식 월드컵
            </Text>
            <Text style={[styles.headerSub, { color: colors.muted }]}>
              몇 강으로 진행할까요?
            </Text>
          </View>

          {/* 선택한 카테고리 표시 */}
          <View style={[styles.selectedCatsBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.selectedCatsLabel, { color: colors.muted }]}>선택한 카테고리</Text>
            <View style={styles.selectedCatsTags}>
              {WORLDCUP_CATEGORIES.filter(c => selectedCategoryIds.includes(c.id)).map(c => (
                <View key={c.id} style={[styles.catTag, { backgroundColor: colors.primary + '20', borderColor: colors.primary + '40' }]}>
                  <Text style={[styles.catTagText, { color: colors.primary }]}>
                    {c.emoji} {c.name}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* 16강 / 32강 카드 */}
          <View style={styles.sizeCards}>
            {([16, 32] as const).map(size => {
              const isDisabled = size === 32 && !can32;
              const isSelected = tournamentSize === size;
              return (
                <Pressable
                  key={size}
                  onPress={() => {
                    if (!isDisabled) {
                      setTournamentSize(size);
                      if (Platform.OS !== 'web') {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      }
                    }
                  }}
                  style={({ pressed }) => [
                    styles.sizeCard,
                    {
                      backgroundColor: isSelected ? colors.primary : colors.surface,
                      borderColor: isSelected ? colors.primary : colors.border,
                      opacity: isDisabled ? 0.4 : pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text style={[styles.sizeNumber, { color: isSelected ? '#ffffff' : colors.foreground }]}>
                    {size}강
                  </Text>
                  <Text style={[styles.sizeDesc, { color: isSelected ? 'rgba(255,255,255,0.85)' : colors.muted }]}>
                    {size === 16 ? '16개 메뉴 대결' : '32개 메뉴 대결'}
                  </Text>
                  <Text style={[styles.sizeMatchCount, { color: isSelected ? 'rgba(255,255,255,0.7)' : colors.muted }]}>
                    {size === 16 ? '총 15번 선택' : '총 31번 선택'}
                  </Text>
                  {isDisabled && (
                    <Text style={[styles.sizeDisabled, { color: colors.muted }]}>
                      메뉴 수 부족
                    </Text>
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* 버튼 */}
          <View style={styles.bottomSection}>
            <Pressable
              onPress={startTournament}
              style={({ pressed }) => [
                styles.primaryButton,
                { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 },
              ]}
            >
              <Text style={styles.primaryButtonText}>🏆 월드컵 시작!</Text>
            </Pressable>
            <Pressable
              onPress={() => setStep('category')}
              style={({ pressed }) => [
                styles.secondaryButton,
                { borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Text style={[styles.secondaryButtonText, { color: colors.muted }]}>← 카테고리 다시 선택</Text>
            </Pressable>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ─── 렌더: 토너먼트 진행 ─────────────────────────────────────────────────

  if (step === 'tournament' && rounds.length > 0) {
    const currentRound = rounds[currentRoundIndex];
    const currentMatch = currentRound?.matches[currentMatchIndex];
    if (!currentMatch) return null;

    const totalMatchesInRound = currentRound.matches.length;
    const progress = (currentMatchIndex + 1) / totalMatchesInRound;

    // 전체 진행률 계산
    const totalMatches = tournamentSize - 1;
    const completedMatches = rounds
      .slice(0, currentRoundIndex)
      .reduce((sum, r) => sum + r.matches.length, 0) + currentMatchIndex;
    const totalProgress = completedMatches / totalMatches;

    return (
      <ScreenContainer className="p-4">
        <View style={styles.tournamentContainer}>
          {/* 상단 진행 정보 */}
          <View style={styles.progressSection}>
            <View style={styles.progressRow}>
              <Text style={[styles.roundBadge, { backgroundColor: colors.primary + '20', color: colors.primary }]}>
                {currentRound.name}
              </Text>
              <Text style={[styles.matchCount, { color: colors.muted }]}>
                {currentMatchIndex + 1} / {totalMatchesInRound}
              </Text>
            </View>

            {/* 라운드 진행바 */}
            <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
              <View
                style={[
                  styles.progressFill,
                  { backgroundColor: colors.primary, width: `${progress * 100}%` as any },
                ]}
              />
            </View>

            {/* 전체 진행률 */}
            <Text style={[styles.totalProgress, { color: colors.muted }]}>
              전체 {Math.round(totalProgress * 100)}% 완료
            </Text>
          </View>

          {/* 대결 안내 */}
          <Text style={[styles.vsGuide, { color: colors.muted }]}>
            더 먹고 싶은 음식을 선택하세요!
          </Text>

          {/* 대결 카드 */}
          <View style={styles.matchSection}>
            {/* 메뉴 1 */}
            <Pressable
              onPress={() => selectWinner(currentMatch.menu1)}
              style={({ pressed }) => [
                styles.menuCard,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                },
              ]}
            >
              <Text style={styles.menuCardEmoji}>🍽️</Text>
              <Text style={[styles.menuCardName, { color: colors.foreground }]}>
                {currentMatch.menu1.name}
              </Text>
              <Text style={[styles.menuCardDesc, { color: colors.muted }]} numberOfLines={2}>
                {currentMatch.menu1.desc}
              </Text>
              <View style={[styles.selectButton, { backgroundColor: colors.primary }]}>
                <Text style={styles.selectButtonText}>선택!</Text>
              </View>
            </Pressable>

            {/* VS */}
            <View style={[styles.vsCircle, { backgroundColor: colors.primary }]}>
              <Text style={styles.vsText}>VS</Text>
            </View>

            {/* 메뉴 2 */}
            <Pressable
              onPress={() => selectWinner(currentMatch.menu2)}
              style={({ pressed }) => [
                styles.menuCard,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                },
              ]}
            >
              <Text style={styles.menuCardEmoji}>🍽️</Text>
              <Text style={[styles.menuCardName, { color: colors.foreground }]}>
                {currentMatch.menu2.name}
              </Text>
              <Text style={[styles.menuCardDesc, { color: colors.muted }]} numberOfLines={2}>
                {currentMatch.menu2.desc}
              </Text>
              <View style={[styles.selectButton, { backgroundColor: colors.primary }]}>
                <Text style={styles.selectButtonText}>선택!</Text>
              </View>
            </Pressable>
          </View>
        </View>
      </ScreenContainer>
    );
  }

  // ─── 렌더: 결과 ──────────────────────────────────────────────────────────

  if (step === 'result' && champion) {
    const selectedCatNames = WORLDCUP_CATEGORIES
      .filter(c => selectedCategoryIds.includes(c.id))
      .map(c => c.name)
      .join(', ');

    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.resultContainer}>
            {/* 우승 트로피 */}
            <View style={styles.trophySection}>
              <Text style={styles.trophyEmoji}>🏆</Text>
              <Text style={[styles.resultTitle, { color: colors.foreground }]}>
                최종 우승!
              </Text>
              <Text style={[styles.resultSubtitle, { color: colors.muted }]}>
                {tournamentSize}강 · {selectedCatNames}
              </Text>
            </View>

            {/* 우승 메뉴 카드 */}
            <View style={[styles.championCard, { backgroundColor: colors.surface, borderColor: colors.primary }]}>
              <Text style={styles.championEmoji}>🥇</Text>
              <Text style={[styles.championName, { color: colors.foreground }]}>
                {champion.name}
              </Text>
              <Text style={[styles.championDesc, { color: colors.muted }]}>
                {champion.desc}
              </Text>
            </View>

            {/* 버튼 */}
            <View style={styles.resultButtons}>
              <Pressable
                onPress={() =>
                  router.push({
                    pathname: '/(tabs)/restaurants',
                    params: { recommendedMenu: champion.name },
                  })
                }
                style={({ pressed }) => [
                  styles.primaryButton,
                  { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 },
                ]}
              >
                <Text style={styles.primaryButtonText}>
                  이 음식 제공하는 식당 찾기 🍽️
                </Text>
              </Pressable>

              <Pressable
                onPress={restart}
                style={({ pressed }) => [
                  styles.secondaryButton,
                  { borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>
                  다시 시작하기
                </Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  return null;
}

// ─── 스타일 ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  header: {
    alignItems: 'center',
    paddingTop: 16,
    paddingBottom: 20,
    gap: 6,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '800',
  },
  headerSub: {
    fontSize: 15,
    textAlign: 'center',
  },
  headerHint: {
    fontSize: 13,
    textAlign: 'center',
  },
  // 카테고리 그리드
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    justifyContent: 'space-between',
  },
  categoryCard: {
    width: '47%',
    borderRadius: 14,
    borderWidth: 1.5,
    padding: 14,
    alignItems: 'center',
    gap: 4,
    position: 'relative',
  },
  categoryEmoji: {
    fontSize: 28,
  },
  categoryName: {
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
  categoryCount: {
    fontSize: 12,
  },
  checkBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '700',
  },
  // 선택 카테고리 박스
  selectedCatsBox: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 16,
    gap: 8,
  },
  selectedCatsLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  selectedCatsTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  catTag: {
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  catTagText: {
    fontSize: 13,
    fontWeight: '600',
  },
  // 강 선택 카드
  sizeCards: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  sizeCard: {
    flex: 1,
    borderRadius: 16,
    borderWidth: 2,
    padding: 20,
    alignItems: 'center',
    gap: 6,
  },
  sizeNumber: {
    fontSize: 28,
    fontWeight: '800',
  },
  sizeDesc: {
    fontSize: 13,
    fontWeight: '600',
  },
  sizeMatchCount: {
    fontSize: 12,
  },
  sizeDisabled: {
    fontSize: 11,
    marginTop: 4,
  },
  // 버튼
  bottomSection: {
    gap: 10,
    paddingTop: 8,
  },
  primaryButton: {
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  secondaryButton: {
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  secondaryButtonText: {
    fontSize: 15,
    fontWeight: '600',
  },
  // 토너먼트
  tournamentContainer: {
    flex: 1,
    gap: 12,
    paddingTop: 8,
  },
  progressSection: {
    gap: 6,
  },
  progressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  roundBadge: {
    fontSize: 14,
    fontWeight: '700',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  matchCount: {
    fontSize: 14,
    fontWeight: '600',
  },
  progressBar: {
    height: 6,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  totalProgress: {
    fontSize: 12,
    textAlign: 'right',
  },
  vsGuide: {
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '500',
  },
  matchSection: {
    flex: 1,
    gap: 0,
    alignItems: 'center',
  },
  menuCard: {
    width: '100%',
    borderRadius: 18,
    borderWidth: 1.5,
    padding: 20,
    alignItems: 'center',
    gap: 8,
  },
  menuCardEmoji: {
    fontSize: 36,
  },
  menuCardName: {
    fontSize: 22,
    fontWeight: '800',
    textAlign: 'center',
  },
  menuCardDesc: {
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
  },
  selectButton: {
    marginTop: 4,
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 8,
  },
  selectButtonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '700',
  },
  vsCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
  },
  vsText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '800',
  },
  // 결과
  resultContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 20,
    paddingTop: 20,
  },
  trophySection: {
    alignItems: 'center',
    gap: 6,
  },
  trophyEmoji: {
    fontSize: 56,
  },
  resultTitle: {
    fontSize: 28,
    fontWeight: '800',
  },
  resultSubtitle: {
    fontSize: 13,
    textAlign: 'center',
  },
  championCard: {
    width: '100%',
    borderRadius: 20,
    borderWidth: 2,
    padding: 24,
    alignItems: 'center',
    gap: 10,
  },
  championEmoji: {
    fontSize: 40,
  },
  championName: {
    fontSize: 26,
    fontWeight: '800',
    textAlign: 'center',
  },
  championDesc: {
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  resultButtons: {
    width: '100%',
    gap: 10,
  },
});
