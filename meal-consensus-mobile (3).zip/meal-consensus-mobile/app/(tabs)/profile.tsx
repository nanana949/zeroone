import { useEffect, useState, useCallback } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  Platform,
} from "react-native";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  loadTasteDNA,
  loadRelationshipProfiles,
  DEFAULT_TASTE_DNA,
  DEFAULT_RELATIONSHIP_PROFILES,
  type TasteDNA,
  type RelationshipProfile,
  type RelationshipType,
} from "@/lib/store";

// 알레르기/식이제한 목록
const ALLERGENS = [
  { id: "seafood", label: "🦐 해산물", color: "#FFD9D0" },
  { id: "peanut", label: "🥜 땅콩", color: "#FFE8D6" },
  { id: "egg", label: "🥚 계란", color: "#FFF4D6" },
  { id: "milk", label: "🥛 우유", color: "#E8D5F2" },
  { id: "wheat", label: "🌾 밀", color: "#D4F1D4" },
  { id: "soy", label: "🫘 콩", color: "#D6E8F7" },
  { id: "nuts", label: "🌰 견과류", color: "#FFE8B6" },
  { id: "spicy", label: "🌶️ 매운맛", color: "#FFD9D0" },
  { id: "garlic", label: "🧄 마늘", color: "#FFE8D6" },
  { id: "onion", label: "🧅 양파", color: "#FFF4D6" },
];

// ─── 취향 DNA 시각화 ───────────────────────────────────────────────────────────

function DNABar({
  label,
  value,
  maxValue = 5,
  leftLabel,
  rightLabel,
  color,
}: {
  label: string;
  value: number;
  maxValue?: number;
  leftLabel: string;
  rightLabel: string;
  color: string;
}) {
  const colors = useColors();
  const percentage = (value / maxValue) * 100;

  return (
    <View style={{ marginBottom: 14 }}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginBottom: 6,
        }}
      >
        <Text style={{ fontSize: 13, fontWeight: "600", color: colors.foreground }}>
          {label}
        </Text>
        <Text style={{ fontSize: 12, color: color, fontWeight: "700" }}>
          {value}/{maxValue}
        </Text>
      </View>
      <View
        style={{
          height: 8,
          borderRadius: 4,
          backgroundColor: colors.border,
          overflow: "hidden",
        }}
      >
        <View
          style={{
            height: "100%",
            width: `${percentage}%`,
            borderRadius: 4,
            backgroundColor: color,
          }}
        />
      </View>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginTop: 4,
        }}
      >
        <Text style={{ fontSize: 10, color: colors.muted }}>{leftLabel}</Text>
        <Text style={{ fontSize: 10, color: colors.muted }}>{rightLabel}</Text>
      </View>
    </View>
  );
}

// ─── 관계 프로필 카드 ──────────────────────────────────────────────────────────

function RelationshipCard({
  profile,
  isSelected,
  onSelect,
}: {
  profile: RelationshipProfile;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const colors = useColors();

  return (
    <Pressable
      onPress={onSelect}
      style={({ pressed }) => [
        {
          borderRadius: 16,
          padding: 16,
          marginBottom: 10,
          backgroundColor: isSelected ? colors.primary + "12" : colors.surface,
          borderWidth: isSelected ? 2 : 1,
          borderColor: isSelected ? colors.primary : colors.border,
        },
        pressed && { opacity: 0.85 },
      ]}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 10 }}>
        <Text style={{ fontSize: 28 }}>{profile.emoji}</Text>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 16,
              fontWeight: "700",
              color: colors.foreground,
            }}
          >
            {profile.label}
          </Text>
          <Text style={{ fontSize: 12, color: colors.muted }}>
            예산 {profile.budgetPerPerson.toLocaleString()}원/인
          </Text>
        </View>
        {isSelected && (
          <View
            style={{
              width: 24,
              height: 24,
              borderRadius: 12,
              backgroundColor: colors.primary,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 12, fontWeight: "700" }}>✓</Text>
          </View>
        )}
      </View>

      {profile.favoriteCategories.length > 0 && (
        <View>
          <Text style={{ fontSize: 11, color: colors.muted, marginBottom: 6 }}>
            선호 카테고리
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
            {profile.favoriteCategories.map((cat) => (
              <View
                key={cat}
                style={{
                  paddingHorizontal: 8,
                  paddingVertical: 3,
                  borderRadius: 8,
                  backgroundColor: colors.primary + "20",
                }}
              >
                <Text style={{ fontSize: 11, color: colors.primary, fontWeight: "600" }}>
                  {cat}
                </Text>
              </View>
            ))}
          </View>
        </View>
      )}
    </Pressable>
  );
}

// ─── 메인 화면 ─────────────────────────────────────────────────────────────────

export default function ProfileScreen() {
  const colors = useColors();
  const router = useRouter();
  const [tasteDNA, setTasteDNA] = useState<TasteDNA>(DEFAULT_TASTE_DNA);
  const [profiles, setProfiles] = useState<RelationshipProfile[]>(DEFAULT_RELATIONSHIP_PROFILES);
  const [selectedProfile, setSelectedProfile] = useState<RelationshipType>("solo");
  const [allergens, setAllergens] = useState<string[]>([]);

  useEffect(() => {
    loadTasteDNA().then((dna) => {
      if (dna) setTasteDNA(dna);
    });
    loadRelationshipProfiles().then(setProfiles);
    // 저장된 알레르기 로드
    AsyncStorage.getItem("userAllergens").then((data) => {
      if (data) setAllergens(JSON.parse(data));
    });
  }, []);

  const handleProfileSelect = useCallback(
    (type: RelationshipType) => {
      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
      setSelectedProfile(type);
    },
    []
  );

  const toggleAllergen = async (allergenId: string) => {
    const updated = allergens.includes(allergenId)
      ? allergens.filter((id) => id !== allergenId)
      : [...allergens, allergenId];
    setAllergens(updated);
    await AsyncStorage.setItem("userAllergens", JSON.stringify(updated));
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // 취향 성향 요약 텍스트
  const getDNASummary = () => {
    const traits: string[] = [];
    if (tasteDNA.spicyTolerance >= 4) traits.push("매운 음식 선호");
    else if (tasteDNA.spicyTolerance <= 2) traits.push("순한 음식 선호");
    if (tasteDNA.adventurousness >= 4) traits.push("도전적인 식성");
    else if (tasteDNA.adventurousness <= 2) traits.push("익숙한 음식 선호");
    if (tasteDNA.healthFirst) traits.push("건강 식단 중시");
    if (tasteDNA.fullnessFirst) traits.push("포만감 우선");
    if (tasteDNA.priceSensitivity <= 2) traits.push("가성비 중시");
    return traits.length > 0 ? traits.join(" · ") : "취향 분석 중";
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 16 }}>
          <Text
            style={{
              fontSize: 26,
              fontWeight: "800",
              color: colors.foreground,
              letterSpacing: -0.5,
            }}
          >
            👤 나의 프로필
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>
            취향 DNA와 관계별 기억을 관리해요
          </Text>
        </View>

        <View style={{ paddingHorizontal: 20 }}>
          {/* 취향 DNA 카드 */}
          <View
            style={{
              backgroundColor: colors.primary + "10",
              borderRadius: 20,
              padding: 18,
              marginBottom: 20,
              borderWidth: 1.5,
              borderColor: colors.primary + "30",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                marginBottom: 16,
              }}
            >
              <View
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 22,
                  backgroundColor: colors.primary,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={{ fontSize: 22 }}>🧬</Text>
              </View>
              <View>
                <Text
                  style={{
                    fontSize: 17,
                    fontWeight: "800",
                    color: colors.foreground,
                  }}
                >
                  나의 취향 DNA
                </Text>
                <Text style={{ fontSize: 12, color: colors.muted }}>
                  {getDNASummary()}
                </Text>
              </View>
            </View>

            <DNABar
              label="맵기 민감도"
              value={tasteDNA.spicyTolerance}
              leftLabel="매우 민감"
              rightLabel="매운 거 좋아함"
              color="#FF6B35"
            />
            <DNABar
              label="느끼함 허용도"
              value={tasteDNA.oilyTolerance}
              leftLabel="기름진 거 싫음"
              rightLabel="느끼해도 OK"
              color="#FF9800"
            />
            <DNABar
              label="도전 성향"
              value={tasteDNA.adventurousness}
              leftLabel="익숙한 게 좋아"
              rightLabel="새로운 거 좋아"
              color="#9C27B0"
            />
            <DNABar
              label="가격 민감도"
              value={tasteDNA.priceSensitivity}
              leftLabel="가성비 중시"
              rightLabel="가격 상관없음"
              color="#2196F3"
            />

            <View style={{ flexDirection: "row", gap: 10, marginTop: 8 }}>
              <View
                style={{
                  flex: 1,
                  padding: 10,
                  borderRadius: 10,
                  backgroundColor: tasteDNA.fullnessFirst
                    ? colors.primary + "20"
                    : colors.surface,
                  borderWidth: 1,
                  borderColor: tasteDNA.fullnessFirst ? colors.primary : colors.border,
                  alignItems: "center",
                }}
              >
                <Text style={{ fontSize: 14, marginBottom: 2 }}>💪</Text>
                <Text
                  style={{
                    fontSize: 11,
                    fontWeight: "700",
                    color: tasteDNA.fullnessFirst ? colors.primary : colors.muted,
                    textAlign: "center",
                  }}
                >
                  {tasteDNA.fullnessFirst ? "포만감 우선" : "분위기 우선"}
                </Text>
              </View>
              <View
                style={{
                  flex: 1,
                  padding: 10,
                  borderRadius: 10,
                  backgroundColor: tasteDNA.healthFirst
                    ? colors.success + "20"
                    : colors.surface,
                  borderWidth: 1,
                  borderColor: tasteDNA.healthFirst ? colors.success : colors.border,
                  alignItems: "center",
                }}
              >
                <Text style={{ fontSize: 14, marginBottom: 2 }}>🥗</Text>
                <Text
                  style={{
                    fontSize: 11,
                    fontWeight: "700",
                    color: tasteDNA.healthFirst ? colors.success : colors.muted,
                    textAlign: "center",
                  }}
                >
                  {tasteDNA.healthFirst ? "건강 우선" : "맛 우선"}
                </Text>
              </View>
            </View>

            <Pressable
              onPress={() => router.push("/onboarding" as any)}
              style={({ pressed }) => [
                {
                  marginTop: 14,
                  paddingVertical: 10,
                  borderRadius: 10,
                  backgroundColor: colors.primary,
                  alignItems: "center",
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              <Text style={{ fontSize: 13, fontWeight: "700", color: "#FFFFFF" }}>
                ✏️ 취향 DNA 수정하기
              </Text>
            </Pressable>
          </View>

          {/* 관계별 프로필 */}
          <Text
            style={{
              fontSize: 17,
              fontWeight: "700",
              color: colors.foreground,
              marginBottom: 12,
            }}
          >
            관계별 기억
          </Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 14 }}>
            상황에 따라 다른 취향을 기억해요
          </Text>
          {profiles.map((profile) => (
            <RelationshipCard
              key={profile.type}
              profile={profile}
              isSelected={selectedProfile === profile.type}
              onSelect={() => handleProfileSelect(profile.type)}
            />
          ))}

          {/* 알레르기/식이제한 섹션 */}
          <Text
            style={{
              fontSize: 17,
              fontWeight: "700",
              color: colors.foreground,
              marginTop: 24,
              marginBottom: 12,
            }}
          >
            🚫 싫어하는 음식 ({allergens.length})
          </Text>
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              gap: 10,
              marginBottom: 20,
            }}
          >
            {ALLERGENS.map((allergen) => {
              const isSelected = allergens.includes(allergen.id);
              return (
                <Pressable
                  key={allergen.id}
                  onPress={() => toggleAllergen(allergen.id)}
                  style={({ pressed }) => [
                    {
                      flex: 1,
                      minWidth: "30%",
                      borderRadius: 12,
                      padding: 12,
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 6,
                      backgroundColor: allergen.color,
                      borderWidth: isSelected ? 3 : 2,
                      borderColor: isSelected ? colors.primary : "transparent",
                    },
                    pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
                  ]}
                >
                  <Text style={{ fontSize: 24 }}>
                    {allergen.label.split(" ")[0]}
                  </Text>
                  <Text
                    style={{
                      fontSize: 11,
                      fontWeight: "600",
                      color: colors.foreground,
                      textAlign: "center",
                    }}
                  >
                    {allergen.label.split(" ")[1]}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* 취향 궁합 섹션 */}
          <View
            style={{
              backgroundColor: colors.secondary + "10",
              borderRadius: 16,
              padding: 16,
              marginTop: 8,
              borderWidth: 1,
              borderColor: colors.secondary + "30",
            }}
          >
            <Text
              style={{
                fontSize: 15,
                fontWeight: "700",
                color: colors.foreground,
                marginBottom: 8,
              }}
            >
              💞 취향 궁합
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, lineHeight: 18 }}>
              친구나 팀원과 취향 궁합을 확인해보세요. 공통 안전지대와 자주 충돌하는 메뉴를 분석해드려요.
            </Text>
            <Pressable
              onPress={() => router.push("/consensus" as any)}
              style={({ pressed }) => [
                {
                  marginTop: 12,
                  paddingVertical: 10,
                  borderRadius: 10,
                  backgroundColor: colors.secondary,
                  alignItems: "center",
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              <Text style={{ fontSize: 13, fontWeight: "700", color: "#FFFFFF" }}>
                🤝 합의 엔진으로 궁합 확인
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
