import { ScrollView, Text, View, TouchableOpacity, Pressable, Image } from "react-native";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { cn } from "@/lib/utils";
import * as Haptics from "expo-haptics";

interface Post {
  id: string;
  author: string;
  avatar: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  timestamp: string;
  liked: boolean;
}

interface Vote {
  id: string;
  title: string;
  options: { text: string; votes: number }[];
  totalVotes: number;
  createdBy: string;
  expiresIn: string;
}

const MOCK_POSTS: Post[] = [
  {
    id: "1",
    author: "김민준",
    avatar: "👨",
    content: "오늘 명동 칼국수 먹었는데 정말 맛있었어요! 강추합니다 🍜",
    likes: 24,
    comments: 5,
    timestamp: "2시간 전",
    liked: false,
  },
  {
    id: "2",
    author: "이수진",
    avatar: "👩",
    content: "건강한 샐러드 레시피 공유합니다! 재료: 양상추, 방울토마토, 치킨...",
    likes: 18,
    comments: 3,
    timestamp: "4시간 전",
    liked: false,
  },
];

const MOCK_VOTES: Vote[] = [
  {
    id: "1",
    title: "점심 뭐 먹을까?",
    options: [
      { text: "한식", votes: 12 },
      { text: "중식", votes: 8 },
      { text: "일식", votes: 15 },
      { text: "양식", votes: 5 },
    ],
    totalVotes: 40,
    createdBy: "박준호",
    expiresIn: "1시간",
  },
];

export default function CommunityScreen() {
  const [activeTab, setActiveTab] = useState<"buddy" | "feed" | "vote" | "ranking">("buddy");
  const [posts, setPosts] = useState(MOCK_POSTS);
  const [votes] = useState(MOCK_VOTES);

  const handleLike = (postId: string) => {
    setPosts(
      posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              liked: !post.liked,
              likes: post.liked ? post.likes - 1 : post.likes + 1,
            }
          : post
      )
    );
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="p-6 gap-6">
          {/* 헤더 */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">
              👥 커뮤니티
            </Text>
            <Text className="text-base text-muted">
              친구들과 맛집, 레시피를 공유하세요
            </Text>
          </View>

          {/* 탭 선택 */}
          <View className="flex-row gap-2 bg-surface rounded-lg p-1">
            {["buddy", "feed", "vote", "ranking"].map((tab) => (
              <Pressable
                key={tab}
                onPress={() => {
                  setActiveTab(tab as any);
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View
                  className={cn(
                    "flex-1 py-2 px-3 rounded-md items-center",
                    activeTab === tab ? "bg-primary" : ""
                  )}
                >
                  <Text
                    className={cn(
                      "text-sm font-semibold",
                      activeTab === tab ? "text-background" : "text-foreground"
                    )}
                  >
                    {tab === "buddy"
                      ? "밥친구"
                      : tab === "feed"
                      ? "피드"
                      : tab === "vote"
                      ? "투표"
                      : "랭킹"}
                  </Text>
                </View>
              </Pressable>
            ))}
          </View>

          {/* 밥친구 탭 */}
          {activeTab === "buddy" && (
            <View className="gap-4">
              <TouchableOpacity className="bg-primary rounded-lg py-3 items-center">
                <Text className="text-base font-semibold text-background">
                  🍚 밥친구 찾기
                </Text>
              </TouchableOpacity>

              {[
                { id: 1, name: "김밥친구", age: 26, location: "서울 강남구", interests: ["한식", "카페"], avatar: "👩" },
                { id: 2, name: "이밥친구", age: 28, location: "서울 강남구", interests: ["일식", "양식"], avatar: "👨" },
                { id: 3, name: "박밥친구", age: 25, location: "서울 강남구", interests: ["중식", "한식"], avatar: "👩" },
              ].map((buddy) => (
                <View key={buddy.id} className="bg-surface rounded-2xl p-4 gap-3 border border-border">
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row items-center gap-3">
                      <View className="w-12 h-12 rounded-full bg-primary/20 items-center justify-center">
                        <Text className="text-2xl">{buddy.avatar}</Text>
                      </View>
                      <View>
                        <Text className="text-sm font-semibold text-foreground">{buddy.name}</Text>
                        <Text className="text-xs text-muted">{buddy.age}세 • {buddy.location}</Text>
                      </View>
                    </View>
                    <View className="bg-green-500 px-2 py-1 rounded-full">
                      <Text className="text-xs font-semibold text-white">활동중</Text>
                    </View>
                  </View>
                  <View className="flex-row gap-2">
                    {buddy.interests.map((interest, idx) => (
                      <View key={idx} className="bg-primary/20 px-3 py-1 rounded-full">
                        <Text className="text-xs font-semibold text-primary">{interest}</Text>
                      </View>
                    ))}
                  </View>
                  <TouchableOpacity className="bg-primary rounded-lg py-2 items-center">
                    <Text className="text-sm font-semibold text-background">연결하기 • 함께 밥 먹기</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}

          {/* 피드 탭 */}
          {activeTab === "feed" && (
            <View className="gap-4">
              {/* 글 작성 버튼 */}
              <TouchableOpacity className="bg-primary rounded-lg py-3 items-center">
                <Text className="text-base font-semibold text-background">
                  ✍️ 글 작성하기
                </Text>
              </TouchableOpacity>

              {/* 포스트 목록 */}
              {posts.map((post) => (
                <View
                  key={post.id}
                  className="bg-surface rounded-2xl p-4 gap-3 border border-border"
                >
                  {/* 작성자 정보 */}
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row items-center gap-2">
                      <Text className="text-2xl">{post.avatar}</Text>
                      <View>
                        <Text className="text-sm font-semibold text-foreground">
                          {post.author}
                        </Text>
                        <Text className="text-xs text-muted">
                          {post.timestamp}
                        </Text>
                      </View>
                    </View>
                    <TouchableOpacity>
                      <Text className="text-lg">⋯</Text>
                    </TouchableOpacity>
                  </View>

                  {/* 내용 */}
                  <Text className="text-base text-foreground leading-relaxed">
                    {post.content}
                  </Text>

                  {/* 상호작용 */}
                  <View className="flex-row justify-between pt-2 border-t border-border">
                    <Pressable
                      onPress={() => handleLike(post.id)}
                      style={({ pressed }) => [
                        { opacity: pressed ? 0.7 : 1 },
                      ]}
                    >
                      <View className="flex-row items-center gap-1">
                        <Text className={post.liked ? "text-lg" : "text-lg"}>
                          {post.liked ? "❤️" : "🤍"}
                        </Text>
                        <Text className="text-sm text-muted">
                          {post.likes}
                        </Text>
                      </View>
                    </Pressable>
                    <View className="flex-row items-center gap-1">
                      <Text className="text-lg">💬</Text>
                      <Text className="text-sm text-muted">
                        {post.comments}
                      </Text>
                    </View>
                    <TouchableOpacity>
                      <View className="flex-row items-center gap-1">
                        <Text className="text-lg">📤</Text>
                        <Text className="text-sm text-muted">공유</Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          )}

          {/* 투표 탭 */}
          {activeTab === "vote" && (
            <View className="gap-4">
              {/* 투표 생성 버튼 */}
              <TouchableOpacity className="bg-primary rounded-lg py-3 items-center">
                <Text className="text-base font-semibold text-background">
                  🗳️ 투표 만들기
                </Text>
              </TouchableOpacity>

              {/* 투표 목록 */}
              {votes.map((vote) => (
                <View
                  key={vote.id}
                  className="bg-surface rounded-2xl p-4 gap-3 border border-border"
                >
                  <View className="flex-row justify-between items-start">
                    <View className="flex-1">
                      <Text className="text-base font-bold text-foreground">
                        {vote.title}
                      </Text>
                      <Text className="text-xs text-muted mt-1">
                        {vote.createdBy} • {vote.expiresIn} 남음
                      </Text>
                    </View>
                  </View>

                  {/* 투표 옵션 */}
                  <View className="gap-2">
                    {vote.options.map((option, index) => {
                      const percentage = (option.votes / vote.totalVotes) * 100;
                      return (
                        <Pressable
                          key={index}
                          style={({ pressed }) => [
                            { opacity: pressed ? 0.7 : 1 },
                          ]}
                        >
                          <View className="gap-1">
                            <View className="flex-row justify-between">
                              <Text className="text-sm font-semibold text-foreground">
                                {option.text}
                              </Text>
                              <Text className="text-xs text-muted">
                                {option.votes}표 ({Math.round(percentage)}%)
                              </Text>
                            </View>
                            <View className="h-2 bg-background rounded-full overflow-hidden">
                              <View
                                className="h-full bg-primary rounded-full"
                                style={{ width: `${percentage}%` }}
                              />
                            </View>
                          </View>
                        </Pressable>
                      );
                    })}
                  </View>

                  <Text className="text-xs text-muted text-center">
                    총 {vote.totalVotes}명 참여
                  </Text>
                </View>
              ))}
            </View>
          )}

          {/* 랭킹 탭 */}
          {activeTab === "ranking" && (
            <View className="gap-4">
              <View className="bg-surface rounded-2xl p-4 gap-3 border border-border">
                <Text className="text-base font-bold text-foreground mb-2">
                  🏆 이주의 인기 맛집
                </Text>

                {[
                  { rank: 1, name: "명동 칼국수", score: 4.8, votes: 245 },
                  { rank: 2, name: "도쿄 라멘", score: 4.6, votes: 189 },
                  { rank: 3, name: "피자 파스타 하우스", score: 4.5, votes: 156 },
                ].map((item) => (
                  <Pressable
                    key={item.rank}
                    style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                  >
                    <View className="flex-row items-center gap-3 pb-3 border-b border-border last:border-b-0">
                      <Text className="text-2xl font-bold text-primary">
                        #{item.rank}
                      </Text>
                      <View className="flex-1">
                        <Text className="text-sm font-semibold text-foreground">
                          {item.name}
                        </Text>
                        <Text className="text-xs text-muted">
                          ⭐ {item.score} ({item.votes}명)
                        </Text>
                      </View>
                      <TouchableOpacity className="px-3 py-1 rounded-full bg-primary">
                        <Text className="text-xs font-semibold text-background">
                          보기
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </Pressable>
                ))}
              </View>

              <View className="bg-surface rounded-2xl p-4 gap-3 border border-border">
                <Text className="text-base font-bold text-foreground mb-2">
                  👨‍🍳 이주의 인기 레시피
                </Text>
                <View className="gap-2">
                  {["집밥 파스타", "간단한 김밥", "두부 스테이크"].map(
                    (recipe, index) => (
                      <Pressable
                        key={index}
                        style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                      >
                        <View className="flex-row items-center justify-between py-2 border-b border-border last:border-b-0">
                          <Text className="text-sm font-semibold text-foreground">
                            {recipe}
                          </Text>
                          <Text className="text-sm text-muted">👍 {120 + index * 30}</Text>
                        </View>
                      </Pressable>
                    )
                  )}
                </View>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
