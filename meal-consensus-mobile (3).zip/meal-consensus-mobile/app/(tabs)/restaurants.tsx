import React, { useState, useEffect, useCallback } from "react";
import {
  ScrollView,
  Text,
  View,
  TextInput,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Linking,
  Platform,
} from "react-native";
import { useLocalSearchParams } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

// ─── 타입 ────────────────────────────────────────────────────────────────────

interface KakaoPlace {
  id: string;
  placeName: string;
  categoryName: string;
  categoryGroupName: string;
  phone: string;
  addressName: string;
  roadAddressName: string;
  x: string;
  y: string;
  placeUrl: string;
  distance: number | null; // 미터
}

type LocationStatus = "idle" | "loading" | "granted" | "denied";

// ─── 거리 포맷 ────────────────────────────────────────────────────────────────

function formatDistance(meters: number | null): string {
  if (meters === null) return "";
  if (meters < 1000) return `${Math.round(meters)}m`;
  return `${(meters / 1000).toFixed(1)}km`;
}

// ─── 메인 컴포넌트 ───────────────────────────────────────────────────────────

export default function RestaurantsScreen() {
  const colors = useColors();
  const params = useLocalSearchParams<{ recommendedMenu?: string; searchMenu?: string }>();

  const [searchQuery, setSearchQuery] = useState(params?.searchMenu ?? params?.recommendedMenu ?? "");
  const [submittedQuery, setSubmittedQuery] = useState(params?.searchMenu ?? params?.recommendedMenu ?? "");
  const [locationStatus, setLocationStatus] = useState<LocationStatus>("idle");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locationLabel, setLocationLabel] = useState<string>("위치 확인 중...");

  // 추천 메뉴에서 진입한 경우 배너 표시
  const fromRecommendation = !!params?.recommendedMenu;

  // ── GPS 위치 획득 (웹/네이티브 공통) ─────────────────────────────────────

  const requestLocation = useCallback(async () => {
    setLocationStatus("loading");

    // 웹: navigator.geolocation 사용
    if (Platform.OS === "web" || typeof navigator !== "undefined") {
      if (!navigator.geolocation) {
        setLocationStatus("denied");
        setLocationLabel("위치 지원 안됨");
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          setLocationStatus("granted");
          // 카카오 좌표→주소 변환 (서버 경유)
          setLocationLabel("현재 위치");
        },
        () => {
          setLocationStatus("denied");
          setLocationLabel("위치 권한 없음");
        },
        { enableHighAccuracy: false, timeout: 10000 }
      );
      return;
    }

    // 네이티브: expo-location 동적 import
    try {
      const Location = await import("expo-location");
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setLocationStatus("denied");
        setLocationLabel("위치 권한 없음");
        return;
      }
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      setCoords({ lat: loc.coords.latitude, lng: loc.coords.longitude });
      setLocationStatus("granted");
      try {
        const [address] = await Location.reverseGeocodeAsync({
          latitude: loc.coords.latitude,
          longitude: loc.coords.longitude,
        });
        if (address) {
          const parts = [address.district, address.street].filter(Boolean);
          setLocationLabel(parts.join(" ") || address.city || "현재 위치");
        }
      } catch {
        setLocationLabel("현재 위치");
      }
    } catch {
      setLocationStatus("denied");
      setLocationLabel("위치 가져오기 실패");
    }
  }, []);

  useEffect(() => {
    requestLocation();
  }, [requestLocation]);

  // 추천 메뉴 파라미터 반영
  useEffect(() => {
    if (params?.recommendedMenu) {
      setSearchQuery(params.recommendedMenu);
      setSubmittedQuery(params.recommendedMenu);
    }
  }, [params?.recommendedMenu]);

  // ── tRPC 카카오 검색 ───────────────────────────────────────────────────────

  const searchQuery_enabled =
    submittedQuery.trim().length > 0 && coords !== null;

  const kakaoSearch = trpc.kakaoLocal.searchNearby.useQuery(
    {
      query: submittedQuery.trim(),
      latitude: coords?.lat ?? 37.5665,
      longitude: coords?.lng ?? 126.978,
      radius: 2000,
    },
    {
      enabled: searchQuery_enabled,
      staleTime: 1000 * 60 * 3, // 3분 캐시
    }
  );

  // ── 검색 실행 ──────────────────────────────────────────────────────────────

  const handleSearch = useCallback(() => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setSubmittedQuery(searchQuery.trim());
  }, [searchQuery]);

  // ── 가게 선택 → 카카오맵 열기 ─────────────────────────────────────────────

  const handlePlacePress = useCallback(async (place: KakaoPlace) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    if (place.placeUrl) {
      await Linking.openURL(place.placeUrl);
    }
  }, []);

  const styles = createStyles(colors);

  // ─── 렌더 ──────────────────────────────────────────────────────────────────

  const places: KakaoPlace[] = (kakaoSearch.data?.places ?? []) as KakaoPlace[];
  const isSearching = kakaoSearch.isFetching;
  const hasSearched = submittedQuery.trim().length > 0;

  return (
    <ScreenContainer>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.container}>
          {/* 헤더 */}
          <View style={styles.headerCard}>
            <Text style={styles.headerTitle}>🍽️ 주변 맛집</Text>
            <Text style={styles.headerSubtitle}>카카오 로컬 기반 음식점 검색</Text>
          </View>

          {/* 위치 상태 */}
          <Pressable
            onPress={locationStatus === "denied" ? requestLocation : undefined}
            style={({ pressed }) => [
              styles.locationBar,
              { backgroundColor: colors.surface, borderColor: colors.border },
              pressed && locationStatus === "denied" && { opacity: 0.7 },
            ]}
          >
            <Text style={styles.locationIcon}>
              {locationStatus === "loading" ? "⏳" : locationStatus === "granted" ? "📍" : "⚠️"}
            </Text>
            <View style={{ flex: 1 }}>
              <Text style={[styles.locationLabel, { color: colors.foreground }]}>
                {locationLabel}
              </Text>
              {locationStatus === "denied" && (
                <Text style={[styles.locationHint, { color: colors.primary }]}>
                  탭하여 위치 권한 재요청
                </Text>
              )}
            </View>
            {locationStatus === "loading" && (
              <ActivityIndicator size="small" color={colors.primary} />
            )}
          </Pressable>

          {/* AI 추천 배너 */}
          {fromRecommendation && submittedQuery.length > 0 && (
            <View style={[styles.recommendBanner, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "40" }]}>
              <Text style={styles.recommendBannerEmoji}>🤖</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.recommendBannerLabel, { color: colors.muted }]}>
                  AI가 추천한 메뉴
                </Text>
                <Text style={[styles.recommendBannerMenu, { color: colors.primary }]}>
                  "{submittedQuery}"
                </Text>
              </View>
            </View>
          )}

          {/* 검색 바 */}
          <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={styles.searchIcon}>🔍</Text>
            <TextInput
              style={[styles.searchInput, { color: colors.foreground }]}
              placeholder="음식 이름으로 검색 (예: 제육볶음)"
              placeholderTextColor={colors.muted}
              value={searchQuery}
              onChangeText={setSearchQuery}
              onSubmitEditing={handleSearch}
              returnKeyType="search"
            />
            {searchQuery.length > 0 && (
              <Pressable
                onPress={() => { setSearchQuery(""); setSubmittedQuery(""); }}
                style={({ pressed }) => ({ opacity: pressed ? 0.5 : 1 })}
              >
                <Text style={{ fontSize: 16, color: colors.muted }}>✕</Text>
              </Pressable>
            )}
          </View>

          {/* 검색 버튼 */}
          <Pressable
            onPress={handleSearch}
            style={({ pressed }) => [
              styles.searchButton,
              { backgroundColor: locationStatus === "granted" ? colors.primary : colors.border },
              pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
            ]}
          >
            {isSearching ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={[styles.searchButtonText, { color: locationStatus === "granted" ? "#fff" : colors.muted }]}>
                {locationStatus === "granted" ? "주변 검색" : "위치 확인 후 검색 가능"}
              </Text>
            )}
          </Pressable>

          {/* 검색 결과 */}
          {isSearching && (
            <View style={styles.loadingState}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[styles.loadingText, { color: colors.muted }]}>
                "{submittedQuery}" 주변 음식점 검색 중...
              </Text>
            </View>
          )}

          {!isSearching && hasSearched && places.length === 0 && !kakaoSearch.isError && (
            <View style={styles.emptyState}>
              <Text style={styles.emptyEmoji}>🔍</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                검색 결과가 없어요
              </Text>
              <Text style={[styles.emptyDesc, { color: colors.muted }]}>
                다른 메뉴 이름으로 검색해 보세요
              </Text>
            </View>
          )}

          {kakaoSearch.isError && (
            <View style={styles.emptyState}>
              <Text style={styles.emptyEmoji}>⚠️</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                검색 중 오류가 발생했어요
              </Text>
              <Text style={[styles.emptyDesc, { color: colors.muted }]}>
                잠시 후 다시 시도해 주세요
              </Text>
            </View>
          )}

          {!isSearching && places.length > 0 && (
            <View style={styles.resultSection}>
              {/* 결과 헤더 */}
              <View style={styles.resultHeader}>
                <Text style={[styles.resultTitle, { color: colors.foreground }]}>
                  검색 결과
                </Text>
                <View style={[styles.resultCountBadge, { backgroundColor: colors.primary + "20" }]}>
                  <Text style={[styles.resultCount, { color: colors.primary }]}>
                    {kakaoSearch.data?.totalCount ?? places.length}개
                  </Text>
                </View>
              </View>

              {/* 검색 반경 안내 */}
              <Text style={[styles.radiusHint, { color: colors.muted }]}>
                📍 {locationLabel} 기준 · 거리순 정렬
              </Text>

              {/* 식당 카드 목록 */}
              <View style={styles.placeList}>
                {places.map((place, index) => (
                  <Pressable
                    key={place.id}
                    onPress={() => handlePlacePress(place)}
                    style={({ pressed }) => [
                      styles.placeCard,
                      {
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        transform: [{ scale: pressed ? 0.98 : 1 }],
                        opacity: pressed ? 0.85 : 1,
                      },
                    ]}
                  >
                    {/* 순위 + 이름 */}
                    <View style={styles.placeHeader}>
                      <View style={[styles.rankBadge, { backgroundColor: index < 3 ? colors.primary : colors.border }]}>
                        <Text style={[styles.rankText, { color: index < 3 ? "#fff" : colors.muted }]}>
                          {index + 1}
                        </Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={[styles.placeName, { color: colors.foreground }]} numberOfLines={1}>
                          {place.placeName}
                        </Text>
                        {place.categoryGroupName && (
                          <Text style={[styles.placeCategory, { color: colors.muted }]} numberOfLines={1}>
                            {place.categoryGroupName}
                          </Text>
                        )}
                      </View>
                      {place.distance !== null && (
                        <View style={[styles.distanceBadge, { backgroundColor: colors.primary + "15" }]}>
                          <Text style={[styles.distanceText, { color: colors.primary }]}>
                            {formatDistance(place.distance)}
                          </Text>
                        </View>
                      )}
                    </View>

                    {/* 주소 */}
                    <View style={styles.addressRow}>
                      <Text style={{ fontSize: 12, color: colors.muted }}>🏠</Text>
                      <Text style={[styles.addressText, { color: colors.muted }]} numberOfLines={1}>
                        {place.roadAddressName || place.addressName || "주소 정보 없음"}
                      </Text>
                    </View>

                    {/* 전화번호 */}
                    {place.phone ? (
                      <View style={styles.phoneRow}>
                        <Text style={{ fontSize: 12, color: colors.muted }}>📞</Text>
                        <Text style={[styles.phoneText, { color: colors.muted }]}>
                          {place.phone}
                        </Text>
                      </View>
                    ) : null}

                    {/* 카카오맵 열기 버튼 */}
                    <View style={[styles.openMapButton, { backgroundColor: colors.primary + "12", borderColor: colors.primary + "30" }]}>
                      <Text style={[styles.openMapText, { color: colors.primary }]}>
                        카카오맵에서 보기 →
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {/* 초기 상태 (검색 전) */}
          {!hasSearched && !isSearching && (
            <View style={styles.initialState}>
              <Text style={styles.initialEmoji}>🗺️</Text>
              <Text style={[styles.initialTitle, { color: colors.foreground }]}>
                음식 이름으로 검색하세요
              </Text>
              <Text style={[styles.initialDesc, { color: colors.muted }]}>
                현재 위치 기준 2km 이내 음식점을{"\n"}카카오 로컬 API로 검색합니다
              </Text>
              <View style={styles.exampleChips}>
                {["제육볶음", "삼겹살", "초밥", "치킨", "파스타"].map((ex) => (
                  <Pressable
                    key={ex}
                    onPress={() => { setSearchQuery(ex); setSubmittedQuery(ex); }}
                    style={({ pressed }) => [
                      styles.exampleChip,
                      { backgroundColor: colors.surface, borderColor: colors.border },
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <Text style={[styles.exampleChipText, { color: colors.foreground }]}>{ex}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

// ─── 스타일 ──────────────────────────────────────────────────────────────────

function createStyles(colors: ReturnType<typeof import("@/hooks/use-colors").useColors>) {
  return StyleSheet.create({
    container: {
      paddingHorizontal: 16,
      paddingTop: 16,
      gap: 12,
    },
    // 헤더
    headerCard: {
      backgroundColor: colors.primary,
      borderRadius: 20,
      padding: 20,
      gap: 4,
    },
    headerTitle: {
      fontSize: 26,
      fontWeight: "800",
      color: "#fff",
    },
    headerSubtitle: {
      fontSize: 13,
      color: "rgba(255,255,255,0.85)",
    },
    // 위치 바
    locationBar: {
      flexDirection: "row",
      alignItems: "center",
      borderRadius: 12,
      borderWidth: 1,
      paddingHorizontal: 14,
      paddingVertical: 10,
      gap: 10,
    },
    locationIcon: {
      fontSize: 16,
    },
    locationLabel: {
      fontSize: 13,
      fontWeight: "600",
    },
    locationHint: {
      fontSize: 11,
      marginTop: 2,
    },
    // 추천 배너
    recommendBanner: {
      flexDirection: "row",
      alignItems: "center",
      borderRadius: 12,
      borderWidth: 1,
      padding: 12,
      gap: 10,
    },
    recommendBannerEmoji: {
      fontSize: 22,
    },
    recommendBannerLabel: {
      fontSize: 11,
      fontWeight: "600",
    },
    recommendBannerMenu: {
      fontSize: 15,
      fontWeight: "700",
      marginTop: 2,
    },
    // 검색 바
    searchBar: {
      flexDirection: "row",
      alignItems: "center",
      borderRadius: 12,
      borderWidth: 1,
      paddingHorizontal: 12,
      paddingVertical: 10,
      gap: 8,
    },
    searchIcon: {
      fontSize: 16,
    },
    searchInput: {
      flex: 1,
      fontSize: 14,
      paddingVertical: 0,
    },
    // 검색 버튼
    searchButton: {
      borderRadius: 12,
      paddingVertical: 14,
      alignItems: "center",
      justifyContent: "center",
    },
    searchButtonText: {
      fontSize: 15,
      fontWeight: "700",
    },
    // 로딩
    loadingState: {
      alignItems: "center",
      paddingVertical: 40,
      gap: 12,
    },
    loadingText: {
      fontSize: 14,
    },
    // 빈 상태
    emptyState: {
      alignItems: "center",
      paddingVertical: 40,
      gap: 8,
    },
    emptyEmoji: {
      fontSize: 48,
    },
    emptyTitle: {
      fontSize: 16,
      fontWeight: "700",
    },
    emptyDesc: {
      fontSize: 13,
      textAlign: "center",
    },
    // 결과 섹션
    resultSection: {
      gap: 8,
    },
    resultHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
    },
    resultTitle: {
      fontSize: 16,
      fontWeight: "800",
    },
    resultCountBadge: {
      borderRadius: 20,
      paddingHorizontal: 10,
      paddingVertical: 3,
    },
    resultCount: {
      fontSize: 13,
      fontWeight: "700",
    },
    radiusHint: {
      fontSize: 12,
      marginBottom: 4,
    },
    // 식당 카드
    placeList: {
      gap: 10,
    },
    placeCard: {
      borderRadius: 16,
      borderWidth: 1,
      padding: 14,
      gap: 8,
    },
    placeHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },
    rankBadge: {
      width: 26,
      height: 26,
      borderRadius: 13,
      alignItems: "center",
      justifyContent: "center",
    },
    rankText: {
      fontSize: 12,
      fontWeight: "800",
    },
    placeName: {
      fontSize: 15,
      fontWeight: "700",
    },
    placeCategory: {
      fontSize: 11,
      marginTop: 1,
    },
    distanceBadge: {
      borderRadius: 8,
      paddingHorizontal: 8,
      paddingVertical: 4,
    },
    distanceText: {
      fontSize: 12,
      fontWeight: "700",
    },
    addressRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
    },
    addressText: {
      fontSize: 12,
      flex: 1,
    },
    phoneRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
    },
    phoneText: {
      fontSize: 12,
    },
    openMapButton: {
      borderRadius: 8,
      borderWidth: 1,
      paddingVertical: 8,
      alignItems: "center",
      marginTop: 2,
    },
    openMapText: {
      fontSize: 13,
      fontWeight: "600",
    },
    // 초기 상태
    initialState: {
      alignItems: "center",
      paddingVertical: 32,
      gap: 10,
    },
    initialEmoji: {
      fontSize: 52,
    },
    initialTitle: {
      fontSize: 17,
      fontWeight: "700",
    },
    initialDesc: {
      fontSize: 13,
      textAlign: "center",
      lineHeight: 20,
    },
    exampleChips: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 8,
      justifyContent: "center",
      marginTop: 8,
    },
    exampleChip: {
      borderRadius: 20,
      borderWidth: 1,
      paddingHorizontal: 14,
      paddingVertical: 6,
    },
    exampleChipText: {
      fontSize: 13,
      fontWeight: "600",
    },
  });
}
