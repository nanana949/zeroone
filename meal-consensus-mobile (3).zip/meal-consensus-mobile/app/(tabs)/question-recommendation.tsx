import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { useState } from "react";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

// ─── 질문 데이터 ────────────────────────────────────────────────────────────

const QUESTIONS = [
  {
    id: 1,
    question: "🍽️ 어떤 종류의 음식을 원하세요?",
    options: [
      { label: "한식", value: "korean" },
      { label: "중식", value: "chinese" },
      { label: "일식", value: "japanese" },
      { label: "양식", value: "western" },
      { label: "아무거나", value: "any" },
    ],
  },
  {
    id: 2,
    question: "🍚 얼마나 배고프세요?",
    options: [
      { label: "조금", value: "light" },
      { label: "중간", value: "medium" },
      { label: "많이", value: "heavy" },
    ],
  },
  {
    id: 3,
    question: "⏱️ 시간이 얼마나 있으세요?",
    options: [
      { label: "빠르게 (15분)", value: "quick" },
      { label: "보통 (30분)", value: "normal" },
      { label: "여유 (1시간+)", value: "leisurely" },
    ],
  },
  {
    id: 4,
    question: "💰 예산은 어느 정도인가요?",
    options: [
      { label: "저가 (~5천)", value: "budget" },
      { label: "중간 (5~1만)", value: "mid" },
      { label: "고가 (1만+)", value: "premium" },
    ],
  },
  {
    id: 5,
    question: "🌶️ 맵기는 어느 정도?",
    options: [
      { label: "순한맛", value: "mild" },
      { label: "중간", value: "medium" },
      { label: "매운맛", value: "spicy" },
      { label: "상관없음", value: "any" },
    ],
  },
];

// ─── 추천 메뉴 데이터 ────────────────────────────────────────────────────────────

const MENU_RECOMMENDATIONS: Record<string, string> = {
  korean_light_quick_budget_mild: "🍜 김밥",
  korean_light_quick_budget_medium: "🍜 김밥",
  korean_light_quick_budget_spicy: "🌶️ 떡볶이",
  korean_medium_quick_budget_mild: "🍲 국밥",
  korean_medium_quick_budget_spicy: "🌶️ 라면",
  korean_heavy_normal_mid_mild: "🍖 삼겹살",
  korean_heavy_normal_mid_spicy: "🌶️ 불고기",
  chinese_light_quick_budget_mild: "🥡 짜장면",
  chinese_medium_quick_budget_mild: "🥡 짬뽕",
  chinese_heavy_normal_mid_mild: "🥡 마라탕",
  japanese_light_quick_mid_mild: "🍱 초밥",
  japanese_medium_normal_mid_mild: "🍱 우동",
  japanese_heavy_leisurely_premium_mild: "🍱 가이세키",
  western_light_quick_budget_mild: "🍔 햄버거",
  western_medium_quick_mid_mild: "🍕 피자",
  western_heavy_leisurely_premium_mild: "🥩 스테이크",
  any_light_quick_budget_any: "🍜 라면",
  any_medium_normal_mid_any: "🍲 찌개",
  any_heavy_leisurely_premium_any: "🍖 고기구이",
};

export default function QuestionRecommendationScreen() {
  const colors = useColors();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnswer = (value: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const newAnswers = { ...answers, [QUESTIONS[currentQuestion].id]: value };
    setAnswers(newAnswers);

    // 마지막 질문이면 추천 생성
    if (currentQuestion === QUESTIONS.length - 1) {
      generateRecommendation(newAnswers);
    } else {
      // 다음 질문으로
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const generateRecommendation = (finalAnswers: Record<number, string>) => {
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    setTimeout(() => {
      // 답변을 조합하여 추천 메뉴 생성
      const key = Object.values(finalAnswers).join("_");
      const menu =
        MENU_RECOMMENDATIONS[key] ||
        MENU_RECOMMENDATIONS[
          Object.values(finalAnswers).slice(0, 2).join("_") + "_any_any_any"
        ] ||
        "🍜 따뜻한 국수";

      setRecommendation(menu);
      setLoading(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }, 800);
  };

  const handleReset = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setCurrentQuestion(0);
    setAnswers({});
    setRecommendation(null);
  };

  const progress = ((currentQuestion + 1) / QUESTIONS.length) * 100;

  const styles = StyleSheet.create({
    headerCard: {
      backgroundColor: colors.primary,
      borderRadius: 20,
      padding: 20,
      marginBottom: 24,
      gap: 8,
    },
    headerTitle: {
      fontSize: 28,
      fontWeight: "800",
      color: "#fff",
    },
    headerSubtitle: {
      fontSize: 13,
      color: "rgba(255,255,255,0.9)",
    },
    progressBar: {
      height: 8,
      backgroundColor: "rgba(255,255,255,0.3)",
      borderRadius: 4,
      overflow: "hidden",
      marginTop: 12,
    },
    progressFill: {
      height: "100%",
      backgroundColor: "#fff",
      borderRadius: 4,
    },
    questionCard: {
      backgroundColor: colors.surface,
      borderRadius: 20,
      padding: 20,
      marginBottom: 24,
      borderWidth: 2,
      borderColor: colors.border,
    },
    questionText: {
      fontSize: 18,
      fontWeight: "700",
      color: colors.foreground,
      marginBottom: 16,
      lineHeight: 26,
    },
    optionsGrid: {
      gap: 10,
    },
    optionButton: {
      backgroundColor: colors.primary,
      borderRadius: 12,
      padding: 14,
      alignItems: "center",
      justifyContent: "center",
    },
    optionText: {
      fontSize: 14,
      fontWeight: "600",
      color: "#fff",
    },
    recommendationCard: {
      backgroundColor: colors.surface,
      borderRadius: 20,
      padding: 24,
      gap: 16,
      borderWidth: 2,
      borderColor: colors.primary,
      alignItems: "center",
    },
    recommendationEmoji: {
      fontSize: 56,
    },
    recommendationText: {
      fontSize: 24,
      fontWeight: "700",
      color: colors.foreground,
      textAlign: "center",
    },
    resetButton: {
      backgroundColor: colors.success,
      borderRadius: 12,
      padding: 14,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 12,
    },
    resetButtonText: {
      fontSize: 14,
      fontWeight: "600",
      color: "#fff",
    },
  });

  if (recommendation) {
    return (
      <ScreenContainer className="p-4">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <View style={styles.headerCard}>
            <Text style={styles.headerTitle}>🎉 추천 완료!</Text>
            <Text style={styles.headerSubtitle}>
              당신의 취향에 맞는 메뉴입니다
            </Text>
          </View>

          <View style={styles.recommendationCard}>
            <Text style={styles.recommendationEmoji}>
              {recommendation.split(" ")[0]}
            </Text>
            <Text style={styles.recommendationText}>{recommendation}</Text>

            <Pressable
              style={({ pressed }) => [
                styles.resetButton,
                pressed && { opacity: 0.8 },
              ]}
              onPress={handleReset}
            >
              <Text style={styles.resetButtonText}>다시 추천받기</Text>
            </Pressable>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>❓ 질문으로 추천</Text>
          <Text style={styles.headerSubtitle}>
            {currentQuestion + 1} / {QUESTIONS.length}
          </Text>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                { width: `${progress}%` },
              ]}
            />
          </View>
        </View>

        {loading ? (
          <View
            style={{
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
              marginVertical: 40,
            }}
          >
            <ActivityIndicator size="large" color={colors.primary} />
            <Text
              style={{
                marginTop: 12,
                fontSize: 14,
                color: colors.muted,
              }}
            >
              최적의 메뉴를 찾고 있어요...
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.questionCard}>
              <Text style={styles.questionText}>
                {QUESTIONS[currentQuestion].question}
              </Text>

              <View style={styles.optionsGrid}>
                {QUESTIONS[currentQuestion].options.map((option) => (
                  <Pressable
                    key={option.value}
                    style={({ pressed }) => [
                      styles.optionButton,
                      pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
                    ]}
                    onPress={() => handleAnswer(option.value)}
                  >
                    <Text style={styles.optionText}>{option.label}</Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {currentQuestion > 0 && (
              <Pressable
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.muted,
                    borderRadius: 12,
                    padding: 12,
                    alignItems: "center",
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setCurrentQuestion(currentQuestion - 1);
                }}
              >
                <Text style={{ fontSize: 14, fontWeight: "600", color: "#fff" }}>
                  ← 이전
                </Text>
              </Pressable>
            )}
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
