import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const DEMO_ITEMS = [
  { id: 1, name: "계란", quantity: "10개", price: "3,000원", checked: false },
  { id: 2, name: "우유", quantity: "1L", price: "2,500원", checked: false },
  { id: 3, name: "치즈", quantity: "200g", price: "5,000원", checked: false },
  { id: 4, name: "버터", quantity: "100g", price: "4,000원", checked: false },
];

export default function ShoppingListScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    itemRow: {
      flexDirection: "row",
      alignItems: "center",
      paddingVertical: 12,
      paddingHorizontal: 16,
      backgroundColor: colors.surface,
      borderRadius: 12,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            🛒 쇼핑 리스트
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            레시피에 필요한 재료들을 한번에 확인하세요
          </Text>

          {DEMO_ITEMS.map((item) => (
            <Pressable key={item.id} style={styles.itemRow}>
              <View
                style={{
                  width: 24,
                  height: 24,
                  borderRadius: 6,
                  borderWidth: 2,
                  borderColor: colors.border,
                  marginRight: 12,
                }}
              />
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground }}>
                  {item.name}
                </Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
                  {item.quantity}
                </Text>
              </View>
              <Text style={{ fontSize: 13, fontWeight: "600", color: colors.primary }}>
                {item.price}
              </Text>
            </Pressable>
          ))}

          <View
            style={{
              marginTop: 20,
              paddingHorizontal: 16,
              paddingVertical: 12,
              backgroundColor: colors.primary + "20",
              borderRadius: 12,
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground }}>
              총액: 14,500원
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
