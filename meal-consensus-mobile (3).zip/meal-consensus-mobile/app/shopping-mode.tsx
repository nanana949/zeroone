import { useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Platform,
  Modal,
} from "react-native";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  HomeCookingCategory,
  HOME_COOKING_CATEGORIES,
  HOME_COOKING_CATEGORY_EMOJI,
  HomeCookingMenu,
  HOME_COOKING_MENUS,
  WeatherType,
  TimeSlot,
  DayType,
  HomeCookingScore,
  calculateHomeCookingScores,
  BASIC_SEASONINGS,
  groupIngredientForShopping,
  ShoppingGroup,
} from "@/lib/home-cooking-db";

const haptic = () => {
  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
};

type Step =
  | "weather"
  | "time"
  | "day"
  | "category-result"
  | "difficulty-filter"
  | "menu-select"
  | "servings"
  | "shopping-list";

// ─── 레시피 모달 ───
function RecipeModal({
  menu,
  visible,
  onClose,
}: {
  menu: HomeCookingMenu | null;
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const [recipeServings, setRecipeServings] = useState<"1인분" | "2인분" | "3인분">("2인분");
  if (!menu) return null;
  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 60 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <Text style={{ fontSize: 22, fontWeight: "800", color: colors.foreground, flex: 1 }}>{menu.name}</Text>
            <Pressable onPress={onClose} style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1, padding: 8 })}>
              <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>닫기</Text>
            </Pressable>
          </View>
          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
            {[`⏱ ${menu.cookingTime}분`, `📊 ${menu.difficulty}`, `🌶 ${menu.spicy}`].map((tag) => (
              <View key={tag} style={{ backgroundColor: `${colors.primary}15`, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 }}>
                <Text style={{ fontSize: 13, color: colors.primary, fontWeight: "600" }}>{tag}</Text>
              </View>
            ))}
          </View>
          <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 10 }}>인분 선택</Text>
          <View style={{ flexDirection: "row", gap: 8, marginBottom: 20 }}>
            {(["1인분", "2인분", "3인분"] as const).map((s) => (
              <Pressable
                key={s}
                onPress={() => setRecipeServings(s)}
                style={({ pressed }) => ({
                  flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: "center" as const,
                  backgroundColor: recipeServings === s ? `${colors.primary}15` : colors.surface,
                  borderWidth: 2, borderColor: recipeServings === s ? colors.primary : colors.border,
                  transform: [{ scale: pressed ? 0.96 : 1 }],
                })}
              >
                <Text style={{ fontSize: 14, fontWeight: "700", color: recipeServings === s ? colors.primary : colors.foreground }}>{s}</Text>
              </Pressable>
            ))}
          </View>
          <View style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: colors.border }}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>🥬 재료 ({recipeServings})</Text>
            {menu.ingredients[recipeServings].split(", ").map((ing, i) => (
              <View key={i} style={{ flexDirection: "row", alignItems: "center", paddingVertical: 6, borderBottomWidth: i < menu.ingredients[recipeServings].split(", ").length - 1 ? 0.5 : 0, borderBottomColor: colors.border }}>
                <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: colors.primary, marginRight: 10 }} />
                <Text style={{ fontSize: 14, color: colors.foreground }}>{ing.trim()}</Text>
              </View>
            ))}
          </View>
          <View style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 16, borderWidth: 1, borderColor: colors.border }}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>👨‍🍳 조리 방법</Text>
            {menu.recipe.split("\n").filter(Boolean).map((step, i) => (
              <View key={i} style={{ flexDirection: "row", marginBottom: 12 }}>
                <View style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", marginRight: 10, marginTop: 1, flexShrink: 0 }}>
                  <Text style={{ fontSize: 12, color: "#FFFFFF", fontWeight: "700" }}>{i + 1}</Text>
                </View>
                <Text style={{ fontSize: 14, color: colors.foreground, flex: 1, lineHeight: 22 }}>{step.replace(/^\d+\.\s*/, "")}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

type Difficulty = "초급" | "중급" | "고급";
type Servings = "1인분" | "2인분" | "3인분";

// ─── 선택 버튼 (맞춤추천과 동일) ───
function SelectButton({
  label,
  emoji,
  isSelected,
  onPress,
}: {
  label: string;
  emoji: string;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        margin: 6,
        paddingVertical: 14,
        paddingHorizontal: 18,
        borderRadius: 16,
        borderWidth: 2,
        borderColor: isSelected ? colors.primary : colors.border,
        backgroundColor: isSelected ? `${colors.primary}15` : colors.surface,
        minWidth: 100,
        alignItems: "center" as const,
        shadowColor: isSelected ? colors.primary : "transparent",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: isSelected ? 0.2 : 0,
        shadowRadius: 4,
        elevation: isSelected ? 3 : 0,
        transform: [{ scale: pressed ? 0.96 : 1 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <Text style={{ fontSize: 22, marginBottom: 4 }}>{emoji}</Text>
      <Text style={{ fontSize: 13, fontWeight: isSelected ? "700" : "500", color: isSelected ? colors.primary : colors.foreground, textAlign: "center" }}>
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 카테고리 결과 카드 ───
function CategoryResultCard({
  rank,
  item,
  onSelect,
}: {
  rank: number;
  item: HomeCookingScore;
  onSelect: (cat: HomeCookingCategory) => void;
}) {
  const colors = useColors();
  const emoji = HOME_COOKING_CATEGORY_EMOJI[item.category];
  const rankEmoji = rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `${rank}.`;
  return (
    <Pressable
      onPress={() => onSelect(item.category)}
      style={({ pressed }) => ({
        flexDirection: "row" as const,
        alignItems: "center" as const,
        backgroundColor: rank === 1 ? `${colors.primary}12` : colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 10,
        borderWidth: rank === 1 ? 2 : 1,
        borderColor: rank === 1 ? colors.primary : colors.border,
        transform: [{ scale: pressed ? 0.97 : 1 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <Text style={{ fontSize: 24, marginRight: 12 }}>{rankEmoji}</Text>
      <Text style={{ fontSize: 24, marginRight: 10 }}>{emoji}</Text>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>{item.category}</Text>
        <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>점수: {item.score}점 · 탭하여 선택</Text>
      </View>
      <Text style={{ fontSize: 18, color: colors.primary }}>→</Text>
    </Pressable>
  );
}

// ─── 메뉴 카드 ───
function MenuCard({
  menu,
  isSelected,
  onPress,
}: {
  menu: HomeCookingMenu;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: isSelected ? `${colors.primary}12` : colors.surface,
        borderRadius: 16,
        padding: 18,
        marginBottom: 12,
        borderWidth: isSelected ? 2 : 1,
        borderColor: isSelected ? colors.primary : colors.border,
        transform: [{ scale: pressed ? 0.97 : 1 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>{menu.name}</Text>
        {isSelected && <Text style={{ fontSize: 18 }}>✅</Text>}
      </View>
      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
        <View style={{ backgroundColor: `${colors.primary}12`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>⏱ {menu.cookingTime}분</Text>
        </View>
        <View style={{ backgroundColor: `${colors.primary}12`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>📊 {menu.difficulty}</Text>
        </View>
        <View style={{ backgroundColor: `${colors.primary}12`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>🌶 {menu.spicy}</Text>
        </View>
      </View>
    </Pressable>
  );
}

// ─── 장보기 리스트 아이템 ───
function ShoppingItem({
  name,
  isBasic,
  isChecked,
  onToggle,
}: {
  name: string;
  isBasic: boolean;
  isChecked: boolean;
  onToggle: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onToggle}
      style={({ pressed }) => ({
        flexDirection: "row" as const,
        alignItems: "center" as const,
        paddingVertical: 12,
        paddingHorizontal: 4,
        borderBottomWidth: 0.5,
        borderBottomColor: colors.border,
        opacity: pressed ? 0.7 : 1,
      })}
    >
      <View style={{
        width: 24,
        height: 24,
        borderRadius: 6,
        borderWidth: 2,
        borderColor: isChecked ? colors.primary : colors.border,
        backgroundColor: isChecked ? colors.primary : "transparent",
        marginRight: 12,
        alignItems: "center" as const,
        justifyContent: "center" as const,
      }}>
        {isChecked && <Text style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "700" }}>✓</Text>}
      </View>
      <Text style={{
        fontSize: 15,
        color: isChecked ? colors.muted : colors.foreground,
        textDecorationLine: isChecked ? "line-through" : "none",
        flex: 1,
        fontWeight: isBasic ? "400" : "500",
      }}>
        {name}
      </Text>
      {isBasic && (
        <View style={{ backgroundColor: `${colors.muted}20`, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
          <Text style={{ fontSize: 10, color: colors.muted }}>기본양념</Text>
        </View>
      )}
    </Pressable>
  );
}

// ─── 메인 화면 ───
export default function ShoppingModeScreen() {
  const colors = useColors();
  const router = useRouter();

  const [step, setStep] = useState<Step>("weather");
  const [selectedWeather, setSelectedWeather] = useState<WeatherType | null>(null);
  const [selectedTime, setSelectedTime] = useState<TimeSlot | null>(null);
  const [selectedDay, setSelectedDay] = useState<DayType | null>(null);
  const [categoryScores, setCategoryScores] = useState<HomeCookingScore[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<HomeCookingCategory | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | null>(null);
  const [filteredMenus, setFilteredMenus] = useState<HomeCookingMenu[]>([]);
  const [selectedMenu, setSelectedMenu] = useState<HomeCookingMenu | null>(null);
  const [selectedServings, setSelectedServings] = useState<Servings>("2인분");
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());
  const [savedMsg, setSavedMsg] = useState(false);
  const [showRecipe, setShowRecipe] = useState(false);

  const goNext = () => {
    haptic();
    if (step === "weather") setStep("time");
    else if (step === "time") setStep("day");
    else if (step === "day") {
      setCategoryScores(calculateHomeCookingScores(selectedWeather, selectedTime, selectedDay));
      setStep("category-result");
    }
  };

  const goPrev = () => {
    haptic();
    if (step === "time") setStep("weather");
    else if (step === "day") setStep("time");
    else if (step === "category-result") setStep("day");
    else if (step === "difficulty-filter") setStep("category-result");
    else if (step === "menu-select") setStep("difficulty-filter");
    else if (step === "servings") setStep("menu-select");
    else if (step === "shopping-list") setStep("servings");
  };

  const reset = () => {
    haptic();
    setStep("weather");
    setSelectedWeather(null);
    setSelectedTime(null);
    setSelectedDay(null);
    setCategoryScores([]);
    setSelectedCategory(null);
    setSelectedDifficulty(null);
    setFilteredMenus([]);
    setSelectedMenu(null);
    setSelectedServings("2인분");
    setCheckedItems(new Set());
    setSavedMsg(false);
  };

  const handleCategorySelect = (cat: HomeCookingCategory) => {
    haptic();
    setSelectedCategory(cat);
    setStep("difficulty-filter");
  };

  const handleDifficultyConfirm = () => {
    haptic();
    const menus = HOME_COOKING_MENUS.filter((m) => {
      if (m.category !== selectedCategory) return false;
      if (selectedDifficulty && m.difficulty !== selectedDifficulty) return false;
      return true;
    });
    setFilteredMenus(menus);
    setStep("menu-select");
  };

  const handleMenuSelect = (menu: HomeCookingMenu) => {
    haptic();
    setSelectedMenu(menu);
  };

  const handleMenuConfirm = () => {
    if (!selectedMenu) return;
    haptic();
    setStep("servings");
  };

  const handleServingsConfirm = () => {
    haptic();
    setCheckedItems(new Set());
    setStep("shopping-list");
  };

  const toggleItem = (name: string) => {
    haptic();
    setCheckedItems((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const saveToStorage = async () => {
    if (!selectedMenu) return;
    haptic();
    const key = `shopping_list_${Date.now()}`;
    const data = {
      menuName: selectedMenu.name,
      servings: selectedServings,
      ingredients: selectedMenu.ingredients[selectedServings],
      savedAt: new Date().toISOString(),
    };
    await AsyncStorage.setItem(key, JSON.stringify(data));
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2000);
  };

  // 장보기 리스트 생성
  const buildShoppingList = useCallback(() => {
    if (!selectedMenu) return { main: [] as string[], basic: [] as string[] };
    const ingText = selectedMenu.ingredients[selectedServings];
    const items = ingText.split(", ").map((s) => s.trim());
    const main: string[] = [];
    const basic: string[] = [];
    items.forEach((item) => {
      const name = item.replace(/\s+[\d\/]+[\w가-힣]*.*$/, "").trim();
      if (BASIC_SEASONINGS.some((b) => name.includes(b))) {
        basic.push(item);
      } else {
        main.push(item);
      }
    });
    return { main, basic };
  }, [selectedMenu, selectedServings]);

  // 그룹별 정렬
  const groupOrder: ShoppingGroup[] = ["정육·수산", "채소·과일", "냉장·유제품", "조미료·소스", "기본양념"];
  const groupEmoji: Record<ShoppingGroup, string> = {
    "정육·수산": "🥩",
    "채소·과일": "🥬",
    "냉장·유제품": "🥚",
    "조미료·소스": "🫙",
    "기본양념": "🧂",
  };

  const buildGroupedList = useCallback(() => {
    if (!selectedMenu) return {} as Record<ShoppingGroup, string[]>;
    const ingText = selectedMenu.ingredients[selectedServings];
    const items = ingText.split(", ").map((s) => s.trim());
    const groups: Record<ShoppingGroup, string[]> = {
      "정육·수산": [], "채소·과일": [], "냉장·유제품": [], "조미료·소스": [], "기본양념": [],
    };
    items.forEach((item) => {
      const name = item.replace(/\s+[\d\/]+[\w가-힣]*.*$/, "").trim();
      const group = groupIngredientForShopping(name);
      groups[group].push(item);
    });
    return groups;
  }, [selectedMenu, selectedServings]);

  // 진행 바
  const stepOrder: Step[] = ["weather", "time", "day", "category-result", "difficulty-filter", "menu-select", "servings", "shopping-list"];
  const stepIndex = stepOrder.indexOf(step);
  const totalSteps = stepOrder.length;

  const stepTitle: Record<Step, string> = {
    weather: "오늘 날씨는 어때요?",
    time: "지금 시간대는?",
    day: "오늘은 무슨 요일?",
    "category-result": "추천 카테고리 순위",
    "difficulty-filter": "난이도 선택",
    "menu-select": "메뉴를 골라보세요",
    servings: "몇 인분 만들까요?",
    "shopping-list": "장보기 리스트",
  };

  const stepSub: Record<Step, string> = {
    weather: "날씨에 맞는 집밥 카테고리를 추천해드릴게요",
    time: "식사 시간대를 알려주세요",
    day: "평일과 주말 분위기가 달라요",
    "category-result": "카테고리를 탭하여 선택하세요",
    "difficulty-filter": "원하는 난이도를 선택하세요 (건너뛰기 가능)",
    "menu-select": "만들고 싶은 메뉴를 선택해주세요",
    servings: "인분수에 맞게 재료 수량이 계산돼요",
    "shopping-list": "마트 동선에 맞게 정렬했어요",
  };

  const weatherOptions: { value: WeatherType; emoji: string }[] = [
    { value: "비/흐림", emoji: "🌧" },
    { value: "추움", emoji: "🥶" },
    { value: "더움/맑음", emoji: "☀️" },
  ];
  const timeOptions: { value: TimeSlot; emoji: string }[] = [
    { value: "아침", emoji: "🌅" },
    { value: "점심(평일)", emoji: "☀️" },
    { value: "저녁", emoji: "🌙" },
  ];
  const dayOptions: { value: DayType; emoji: string }[] = [
    { value: "평일", emoji: "💼" },
    { value: "주말", emoji: "🎉" },
  ];
  const difficultyOptions: { value: Difficulty; emoji: string; desc: string }[] = [
    { value: "초급", emoji: "😊", desc: "10~20분, 간단한 재료" },
    { value: "중급", emoji: "👨‍🍳", desc: "20~30분, 양념 필요" },
    { value: "고급", emoji: "🏆", desc: "30분+, 숙련 필요" },
  ];
  const servingsOptions: Servings[] = ["1인분", "2인분", "3인분"];

  const grouped = step === "shopping-list" ? buildGroupedList() : null;

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>

        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 }}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({
              flexDirection: "row" as const,
              alignItems: "center" as const,
              marginBottom: 12,
              opacity: pressed ? 0.6 : 1,
              alignSelf: "flex-start" as const,
            })}
          >
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>
          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground }}>🛒 장보기 모드</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>
            메뉴를 정하면 장보기 리스트를 자동으로 만들어드려요
          </Text>
        </View>

        {/* 진행 바 */}
        {step !== "shopping-list" && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <View style={{ height: 4, backgroundColor: `${colors.primary}20`, borderRadius: 2, overflow: "hidden" }}>
              <View style={{ height: "100%", width: `${((stepIndex + 1) / (totalSteps - 1)) * 100}%`, backgroundColor: colors.primary, borderRadius: 2 }} />
            </View>
            <Text style={{ fontSize: 11, color: colors.muted, marginTop: 4, textAlign: "right" }}>{stepIndex + 1} / {totalSteps - 1}</Text>
          </View>
        )}

        {/* 스텝 제목 */}
        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground }}>{stepTitle[step]}</Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>{stepSub[step]}</Text>
        </View>

        {/* ── 날씨 ── */}
        {step === "weather" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {weatherOptions.map((w) => (
                <SelectButton key={w.value} label={w.value} emoji={w.emoji} isSelected={selectedWeather === w.value} onPress={() => { haptic(); setSelectedWeather(selectedWeather === w.value ? null : w.value); }} />
              ))}
            </View>
            <Pressable onPress={() => { haptic(); setSelectedWeather(null); }} style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedWeather === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 시간대 ── */}
        {step === "time" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {timeOptions.map((t) => (
                <SelectButton key={t.value} label={t.value} emoji={t.emoji} isSelected={selectedTime === t.value} onPress={() => { haptic(); setSelectedTime(selectedTime === t.value ? null : t.value); }} />
              ))}
            </View>
            <Pressable onPress={() => { haptic(); setSelectedTime(null); }} style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedTime === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 요일 ── */}
        {step === "day" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {dayOptions.map((d) => (
                <SelectButton key={d.value} label={d.value} emoji={d.emoji} isSelected={selectedDay === d.value} onPress={() => { haptic(); setSelectedDay(selectedDay === d.value ? null : d.value); }} />
              ))}
            </View>
            <Pressable onPress={() => { haptic(); setSelectedDay(null); }} style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedDay === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 카테고리 결과 ── */}
        {step === "category-result" && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 12, fontWeight: "600", color: colors.muted, marginBottom: 6 }}>선택한 조건</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                <Text style={{ fontSize: 13, color: colors.foreground }}>{selectedWeather ? `${weatherOptions.find(w => w.value === selectedWeather)?.emoji} ${selectedWeather}` : "날씨 미선택"}</Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>·</Text>
                <Text style={{ fontSize: 13, color: colors.foreground }}>{selectedTime ? `${timeOptions.find(t => t.value === selectedTime)?.emoji} ${selectedTime}` : "시간 미선택"}</Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>·</Text>
                <Text style={{ fontSize: 13, color: colors.foreground }}>{selectedDay ? `${dayOptions.find(d => d.value === selectedDay)?.emoji} ${selectedDay}` : "요일 미선택"}</Text>
              </View>
            </View>
            {categoryScores.map((item, index) => (
              <CategoryResultCard key={item.category} rank={index + 1} item={item} onSelect={handleCategorySelect} />
            ))}
            {/* 직접 선택 */}
            <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center", marginTop: 8, marginBottom: 8 }}>또는 직접 선택</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
              {HOME_COOKING_CATEGORIES.map((cat) => (
                <Pressable
                  key={cat}
                  onPress={() => handleCategorySelect(cat)}
                  style={({ pressed }) => ({
                    paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20,
                    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 13, color: colors.foreground }}>{HOME_COOKING_CATEGORY_EMOJI[cat]} {cat}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}

        {/* ── 난이도 필터 ── */}
        {step === "difficulty-filter" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {difficultyOptions.map((d) => (
                <Pressable
                  key={d.value}
                  onPress={() => { haptic(); setSelectedDifficulty(selectedDifficulty === d.value ? null : d.value); }}
                  style={({ pressed }) => ({
                    margin: 6, paddingVertical: 16, paddingHorizontal: 20, borderRadius: 16,
                    borderWidth: 2,
                    borderColor: selectedDifficulty === d.value ? colors.primary : colors.border,
                    backgroundColor: selectedDifficulty === d.value ? `${colors.primary}15` : colors.surface,
                    minWidth: 100, alignItems: "center" as const,
                    transform: [{ scale: pressed ? 0.96 : 1 }],
                    opacity: pressed ? 0.85 : 1,
                  })}
                >
                  <Text style={{ fontSize: 28, marginBottom: 6 }}>{d.emoji}</Text>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: selectedDifficulty === d.value ? colors.primary : colors.foreground }}>{d.value}</Text>
                  <Text style={{ fontSize: 11, color: colors.muted, marginTop: 4, textAlign: "center" }}>{d.desc}</Text>
                </Pressable>
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedDifficulty(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedDifficulty === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (모두 보기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 메뉴 선택 ── */}
        {step === "menu-select" && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 13, color: colors.primary, fontWeight: "700" }}>
                {selectedCategory} {selectedDifficulty ? `· ${selectedDifficulty}` : "· 전체 난이도"} · {filteredMenus.length}개 메뉴
              </Text>
            </View>
            {filteredMenus.length === 0 ? (
              <View style={{ backgroundColor: `${colors.warning}15`, borderRadius: 12, padding: 20, alignItems: "center", borderWidth: 1, borderColor: `${colors.warning}30` }}>
                <Text style={{ fontSize: 32, marginBottom: 8 }}>😅</Text>
                <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 6 }}>해당 난이도의 메뉴가 없어요</Text>
                <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center" }}>다른 난이도를 선택하거나 전체 보기를 눌러주세요</Text>
              </View>
            ) : (
              filteredMenus.map((menu) => (
                <MenuCard
                  key={menu.name}
                  menu={menu}
                  isSelected={selectedMenu?.name === menu.name}
                  onPress={() => handleMenuSelect(menu)}
                />
              ))
            )}
          </View>
        )}

        {/* ── 인분 선택 ── */}
        {step === "servings" && selectedMenu && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>{selectedMenu.name}</Text>
              <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>⏱ {selectedMenu.cookingTime}분 · {selectedMenu.difficulty}</Text>
            </View>
            <View style={{ flexDirection: "row", gap: 12 }}>
              {servingsOptions.map((s) => (
                <Pressable
                  key={s}
                  onPress={() => { haptic(); setSelectedServings(s); }}
                  style={({ pressed }) => ({
                    flex: 1, paddingVertical: 20, borderRadius: 16, alignItems: "center" as const,
                    backgroundColor: selectedServings === s ? `${colors.primary}15` : colors.surface,
                    borderWidth: 2, borderColor: selectedServings === s ? colors.primary : colors.border,
                    transform: [{ scale: pressed ? 0.96 : 1 }],
                    opacity: pressed ? 0.85 : 1,
                  })}
                >
                  <Text style={{ fontSize: 28, marginBottom: 6 }}>{s === "1인분" ? "🙋" : s === "2인분" ? "👫" : "👨‍👩‍👦"}</Text>
                  <Text style={{ fontSize: 16, fontWeight: "700", color: selectedServings === s ? colors.primary : colors.foreground }}>{s}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}

        {/* ── 장보기 리스트 ── */}
        {step === "shopping-list" && selectedMenu && grouped && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 메뉴 요약 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground }}>{selectedMenu.name}</Text>
              <Text style={{ fontSize: 13, color: colors.muted, marginTop: 2 }}>{selectedServings} 기준</Text>
            </View>

            {savedMsg && (
              <View style={{ backgroundColor: `${colors.success}15`, borderRadius: 10, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: `${colors.success}30` }}>
                <Text style={{ fontSize: 14, color: colors.success, fontWeight: "700", textAlign: "center" }}>✅ 저장되었어요!</Text>
              </View>
            )}
            {/* 레시피 바로가기 배너 */}
            <Pressable
              onPress={() => setShowRecipe(true)}
              style={({ pressed }) => ({
                backgroundColor: `${colors.primary}12`,
                borderRadius: 12,
                padding: 14,
                marginBottom: 16,
                borderWidth: 1.5,
                borderColor: `${colors.primary}40`,
                flexDirection: "row" as const,
                alignItems: "center" as const,
                transform: [{ scale: pressed ? 0.97 : 1 }],
                opacity: pressed ? 0.85 : 1,
              })}
            >
              <Text style={{ fontSize: 22, marginRight: 10 }}>👨‍🍳</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.primary }}>레시피 보기</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>재료를 다 새다면 조리 방법을 확인하세요</Text>
              </View>
              <Text style={{ fontSize: 16, color: colors.primary }}>→</Text>
            </Pressable>

            {/* 그룹별 리스트 */}
            {groupOrder.map((group) => {
              const items = grouped[group];
              if (!items || items.length === 0) return null;
              const isBasicGroup = group === "기본양념";
              return (
                <View key={group} style={{ marginBottom: 20 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
                    <Text style={{ fontSize: 16 }}>{groupEmoji[group]}</Text>
                    <Text style={{ fontSize: 15, fontWeight: "700", color: isBasicGroup ? colors.muted : colors.foreground, marginLeft: 8 }}>
                      {group}
                    </Text>
                    {isBasicGroup && (
                      <View style={{ backgroundColor: `${colors.muted}20`, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2, marginLeft: 8 }}>
                        <Text style={{ fontSize: 10, color: colors.muted }}>집에 있을 수 있어요</Text>
                      </View>
                    )}
                  </View>
                  <View style={{ backgroundColor: colors.surface, borderRadius: 12, paddingHorizontal: 16, borderWidth: 1, borderColor: colors.border }}>
                    {items.map((item) => (
                      <ShoppingItem
                        key={item}
                        name={item}
                        isBasic={isBasicGroup}
                        isChecked={checkedItems.has(item)}
                        onToggle={() => toggleItem(item)}
                      />
                    ))}
                  </View>
                </View>
              );
            })}

            {/* 진행 상황 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 14, color: colors.primary, fontWeight: "700", textAlign: "center" }}>
                🛒 {checkedItems.size}개 담음 / 전체 {Object.values(grouped).flat().length}개
              </Text>
            </View>
          </View>
        )}

        {/* ── 하단 버튼 ── */}
        <View style={{ paddingHorizontal: 20, marginTop: 28, gap: 10 }}>
          {/* 날씨/시간/요일 */}
          {(step === "weather" || step === "time" || step === "day") && (
            <>
              <Pressable
                onPress={goNext}
                style={({ pressed }) => ({ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center" as const, shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4, transform: [{ scale: pressed ? 0.97 : 1 }], opacity: pressed ? 0.9 : 1 })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>{step === "day" ? "카테고리 추천받기 →" : "다음 →"}</Text>
              </Pressable>
              {step !== "weather" && (
                <Pressable onPress={goPrev} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                  <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 이전</Text>
                </Pressable>
              )}
            </>
          )}

          {/* 카테고리 결과 */}
          {step === "category-result" && (
            <>
              <Pressable onPress={reset} style={({ pressed }) => ({ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center" as const, shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4, transform: [{ scale: pressed ? 0.97 : 1 }], opacity: pressed ? 0.9 : 1 })}>
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>🔄 다시 추천받기</Text>
              </Pressable>
              <Pressable onPress={goPrev} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 조건 수정</Text>
              </Pressable>
            </>
          )}

          {/* 난이도 필터 */}
          {step === "difficulty-filter" && (
            <>
              <Pressable onPress={handleDifficultyConfirm} style={({ pressed }) => ({ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center" as const, shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4, transform: [{ scale: pressed ? 0.97 : 1 }], opacity: pressed ? 0.9 : 1 })}>
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>메뉴 보기 →</Text>
              </Pressable>
              <Pressable onPress={goPrev} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 카테고리 다시 선택</Text>
              </Pressable>
            </>
          )}

          {/* 메뉴 선택 */}
          {step === "menu-select" && (
            <>
              <Pressable
                onPress={handleMenuConfirm}
                disabled={!selectedMenu}
                style={({ pressed }) => ({ backgroundColor: selectedMenu ? colors.primary : colors.border, borderRadius: 14, paddingVertical: 16, alignItems: "center" as const, shadowColor: selectedMenu ? colors.primary : "transparent", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: selectedMenu ? 4 : 0, transform: [{ scale: pressed && !!selectedMenu ? 0.97 : 1 }], opacity: pressed ? 0.9 : 1 })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>{selectedMenu ? `${selectedMenu.name} 선택 →` : "메뉴를 선택해주세요"}</Text>
              </Pressable>
              <Pressable onPress={goPrev} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 난이도 다시 선택</Text>
              </Pressable>
            </>
          )}

          {/* 인분 선택 */}
          {step === "servings" && (
            <>
              <Pressable onPress={handleServingsConfirm} style={({ pressed }) => ({ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center" as const, shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4, transform: [{ scale: pressed ? 0.97 : 1 }], opacity: pressed ? 0.9 : 1 })}>
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>장보기 리스트 만들기 →</Text>
              </Pressable>
              <Pressable onPress={goPrev} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 메뉴 다시 선택</Text>
              </Pressable>
            </>
          )}

          {/* 장보기 리스트 */}
          {step === "shopping-list" && (
            <>
              <Pressable
                onPress={() => setShowRecipe(true)}
                style={({ pressed }) => ({ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center" as const, shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4, transform: [{ scale: pressed ? 0.97 : 1 }], opacity: pressed ? 0.9 : 1 })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>👨‍🍳 레시피 보기</Text>
              </Pressable>
              <Pressable onPress={saveToStorage} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.primary, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.primary }}>💾 장바구니 저장</Text>
              </Pressable>
              <Pressable onPress={goPrev} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 인분 다시 선택</Text>
              </Pressable>
              <Pressable onPress={reset} style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>🔄 처음부터 다시</Text>
              </Pressable>
            </>
          )}
        </View>
      </ScrollView>
      <RecipeModal menu={selectedMenu} visible={showRecipe} onClose={() => setShowRecipe(false)} />
    </ScreenContainer>
  );
}
