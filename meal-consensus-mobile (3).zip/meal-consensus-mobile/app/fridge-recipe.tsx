import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const DEMO_RECIPES = [
  {
    id: 1,
    name: "계란 덮밥",
    ingredients: ["계란", "밥", "간장"],
    time: "5분",
    difficulty: "쉬움",
    emoji: "🍚",
  },
  {
    id: 2,
    name: "스파게티",
    ingredients: ["파스타", "토마토", "마늘"],
    time: "15분",
    difficulty: "중간",
    emoji: "🍝",
  },
  {
    id: 3,
    name: "계란 볶음밥",
    ingredients: ["계란", "밥", "야채"],
    time: "10분",
    difficulty: "쉬움",
    emoji: "🍚",
  },
];

export default function FridgeRecipeScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    recipeCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            🧊 냉장고 레시피
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            보유한 재료로 만들 수 있는 요리들입니다
          </Text>

          {DEMO_RECIPES.map((recipe) => (
            <Pressable key={recipe.id} style={styles.recipeCard}>
              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
                <Text style={{ fontSize: 32, marginRight: 12 }}>{recipe.emoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>
                    {recipe.name}
                  </Text>
                  <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>
                    ⏱️ {recipe.time} • 난이도: {recipe.difficulty}
                  </Text>
                </View>
              </View>
              <Text style={{ fontSize: 12, color: colors.muted }}>
                필요한 재료: {recipe.ingredients.join(", ")}
              </Text>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
