"use client";
import { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Platform,
} from "react-native";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  HomeCookingCategory,
  HOME_COOKING_CATEGORIES,
  HOME_COOKING_CATEGORY_EMOJI,
  WeatherType,
  TimeSlot,
  DayType,
  HomeCookingScore,
  calculateHomeCookingScores,
  MAIN_INGREDIENTS,
  SAUCE_INGREDIENTS,
  HOME_COOKING_MENUS,
  HomeCookingMenu,
  calculateIngredientMatch,
} from "@/lib/home-cooking-db";

interface MatchResult { menu: HomeCookingMenu; matchRate: number; missingIngredients: string[]; }

type Step =
  | "weather"
  | "time"
  | "day"
  | "category-result"
  | "ingredient-select"
  | "menu-result";

const haptic = () => {
  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
};

// ─── 맞춤추천과 동일한 선택 버튼 ───
function SelectButton({
  label,
  emoji,
  isSelected,
  onPress,
}: {
  label: string;
  emoji?: string;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        minWidth: "42%",
        borderRadius: 16,
        paddingVertical: 18,
        paddingHorizontal: 12,
        alignItems: "center" as const,
        justifyContent: "center" as const,
        backgroundColor: isSelected ? colors.primary : colors.surface,
        borderWidth: isSelected ? 0 : 1.5,
        borderColor: isSelected ? "transparent" : colors.border,
        marginHorizontal: 5,
        marginVertical: 5,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: isSelected ? 4 : 2 },
        shadowOpacity: isSelected ? 0.25 : 0.06,
        shadowRadius: isSelected ? 8 : 4,
        elevation: isSelected ? 6 : 2,
        transform: [{ scale: pressed ? 0.96 : 1 }],
        opacity: pressed ? 0.9 : 1,
      })}
    >
      {emoji ? <Text style={{ fontSize: 28, marginBottom: 6 }}>{emoji}</Text> : null}
      <Text
        style={{
          fontSize: 14,
          fontWeight: "700",
          color: isSelected ? "#FFFFFF" : colors.foreground,
          textAlign: "center",
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 재료 칩 ───
function IngredientChip({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: selected ? colors.primary : colors.surface,
        borderRadius: 20,
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderWidth: 1.5,
        borderColor: selected ? "transparent" : colors.border,
        transform: [{ scale: pressed ? 0.95 : 1 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <Text style={{ fontSize: 13, fontWeight: "600", color: selected ? "#FFFFFF" : colors.foreground }}>
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 카테고리 결과 카드 (맞춤추천과 동일 스타일) ───
function CategoryResultCard({
  rank,
  item,
  onSelect,
}: {
  rank: number;
  item: HomeCookingScore;
  onSelect: (cat: HomeCookingCategory) => void;
}) {
  const colors = useColors();
  const isTop = rank <= 3;
  const medal = rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `${rank}위`;

  return (
    <Pressable
      onPress={() => onSelect(item.category)}
      style={({ pressed }) => ({
        backgroundColor: rank === 1 ? colors.primary : colors.surface,
        borderRadius: 18,
        padding: 18,
        marginBottom: 10,
        borderWidth: rank === 1 ? 0 : 1.5,
        borderColor: isTop ? `${colors.primary}40` : colors.border,
        flexDirection: "row" as const,
        alignItems: "center" as const,
        justifyContent: "space-between" as const,
        shadowColor: rank === 1 ? colors.primary : "#000",
        shadowOffset: { width: 0, height: rank === 1 ? 6 : 2 },
        shadowOpacity: rank === 1 ? 0.25 : 0.05,
        shadowRadius: rank === 1 ? 12 : 4,
        elevation: rank === 1 ? 6 : 1,
        transform: [{ scale: pressed ? 0.97 : 1 }],
        opacity: pressed ? 0.9 : 1,
      })}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
        <Text style={{ fontSize: 26 }}>{HOME_COOKING_CATEGORY_EMOJI[item.category]}</Text>
        <View>
          <Text style={{ fontSize: 13, color: rank === 1 ? "rgba(255,255,255,0.8)" : colors.muted, fontWeight: "600", marginBottom: 2 }}>
            {medal}
          </Text>
          <Text style={{ fontSize: 17, fontWeight: "800", color: rank === 1 ? "#FFFFFF" : colors.foreground }}>
            {item.category}
          </Text>
          <Text style={{ fontSize: 12, color: rank === 1 ? "rgba(255,255,255,0.7)" : colors.muted, marginTop: 2 }}>
            탭하면 재료 선택으로 이동 →
          </Text>
        </View>
      </View>
      <View style={{
        backgroundColor: rank === 1 ? "rgba(255,255,255,0.25)" : `${colors.primary}15`,
        borderRadius: 12,
        paddingHorizontal: 12,
        paddingVertical: 6,
      }}>
        <Text style={{ fontSize: 16, fontWeight: "900", color: rank === 1 ? "#FFFFFF" : colors.primary }}>
          {item.score}점
        </Text>
      </View>
    </Pressable>
  );
}

// ─── 매칭 결과 카드 ───
function MatchCard({
  result,
  rank,
  onFindRestaurant,
  onShowRecipe,
}: {
  result: MatchResult;
  rank: number;
  onFindRestaurant: (name: string) => void;
  onShowRecipe: (result: MatchResult) => void;
}) {
  const colors = useColors();
  const pct = Math.round(result.matchRate * 100);
  const isHigh = pct >= 80;
  const isMid = pct >= 50 && pct < 80;
  const barColor = isHigh ? colors.success : isMid ? colors.warning : colors.error;

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 18,
        padding: 20,
        marginBottom: 12,
        borderWidth: rank === 1 ? 2 : 1,
        borderColor: rank === 1 ? colors.primary : colors.border,
        shadowColor: rank === 1 ? colors.primary : "#000",
        shadowOffset: { width: 0, height: rank === 1 ? 6 : 2 },
        shadowOpacity: rank === 1 ? 0.15 : 0.05,
        shadowRadius: rank === 1 ? 12 : 4,
        elevation: rank === 1 ? 5 : 1,
      }}
    >
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          {rank === 1 && <Text style={{ fontSize: 18 }}>🏆</Text>}
          <Text style={{ fontSize: 20, fontWeight: "900", color: colors.foreground }}>{result.menu.name}</Text>
        </View>
        <View style={{ backgroundColor: `${barColor}20`, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4 }}>
          <Text style={{ fontSize: 14, fontWeight: "800", color: barColor }}>{pct}%</Text>
        </View>
      </View>

      <View style={{ height: 6, backgroundColor: `${barColor}20`, borderRadius: 3, marginBottom: 12, overflow: "hidden" }}>
        <View style={{ height: 6, width: `${pct}%`, backgroundColor: barColor, borderRadius: 3 }} />
      </View>

      <View style={{ flexDirection: "row", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
        <View style={{ backgroundColor: `${colors.primary}12`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>⏱ {result.menu.cookingTime}분</Text>
        </View>
        <View style={{ backgroundColor: `${colors.primary}12`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>🍳 집밥</Text>
        </View>
        <View style={{ backgroundColor: `${colors.primary}12`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>📊 {result.menu.difficulty}</Text>
        </View>
      </View>

      {result.missingIngredients.length > 0 && (
        <View style={{ backgroundColor: `${colors.warning}10`, borderRadius: 10, padding: 10, marginBottom: 12, borderWidth: 1, borderColor: `${colors.warning}25` }}>
          <Text style={{ fontSize: 12, fontWeight: "700", color: colors.warning, marginBottom: 4 }}>
            🛒 재료 {result.missingIngredients.length}개만 더 있으면 만들 수 있어요!
          </Text>
          <Text style={{ fontSize: 12, color: colors.muted, lineHeight: 18 }}>
            {result.missingIngredients.join(", ")}
          </Text>
        </View>
      )}

      <Pressable
        onPress={() => onShowRecipe(result)}
        style={({ pressed }) => ({
          backgroundColor: colors.primary,
          borderRadius: 10,
          paddingVertical: 10,
          alignItems: "center" as const,
          borderWidth: 0,
          transform: [{ scale: pressed ? 0.97 : 1 }],
          opacity: pressed ? 0.85 : 1,
        })}
      >
        <Text style={{ fontSize: 13, color: "#FFFFFF", fontWeight: "700" }}>📖 레시피 보기</Text>
      </Pressable>
    </View>
  );
}

// ─── 레시피 모달 ───
function RecipeModal({ result, onClose }: { result: MatchResult; onClose: () => void }) {
  const colors = useColors();
  const [servings, setServings] = useState<"1인분" | "2인분" | "3인분">("2인분");
  const servingOptions: ("1인분" | "2인분" | "3인분")[] = ["1인분", "2인분", "3인분"];
  return (
    <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end", zIndex: 100 }}>
      <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "85%" }}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={{ fontSize: 22, fontWeight: "900", color: colors.foreground, marginBottom: 4 }}>{result.menu.name}</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 16 }}>⏱ {result.menu.cookingTime}분 · {result.menu.difficulty}</Text>

          {/* 인분 선택 */}
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>👥 인분 선택</Text>
          <View style={{ flexDirection: "row", gap: 8, marginBottom: 16 }}>
            {servingOptions.map((s) => (
              <Pressable
                key={s}
                onPress={() => setServings(s)}
                style={({ pressed }) => ({
                  flex: 1,
                  paddingVertical: 10,
                  borderRadius: 10,
                  alignItems: "center" as const,
                  backgroundColor: servings === s ? colors.primary : colors.surface,
                  borderWidth: 1,
                  borderColor: servings === s ? colors.primary : colors.border,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <Text style={{ fontSize: 14, fontWeight: "700", color: servings === s ? "#FFFFFF" : colors.foreground }}>{s}</Text>
              </Pressable>
            ))}
          </View>

          {/* 인분별 재료 */}
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>🛒 재료 ({servings})</Text>
          <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
            {result.menu.ingredients[servings] ? (
              result.menu.ingredients[servings].split(", ").map((ing, i) => (
                <Text key={i} style={{ fontSize: 13, color: colors.foreground, lineHeight: 22 }}>• {ing}</Text>
              ))
            ) : (
              <Text style={{ fontSize: 13, color: colors.muted }}>재료 정보 없음</Text>
            )}
          </View>

          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>📋 레시피</Text>
          <Text style={{ fontSize: 14, color: colors.foreground, lineHeight: 24 }}>
            {result.menu.recipe || "레시피 정보 없음"}
          </Text>
        </ScrollView>
        <Pressable
          onPress={onClose}
          style={({ pressed }) => ({
            backgroundColor: colors.primary,
            borderRadius: 14,
            paddingVertical: 14,
            alignItems: "center" as const,
            marginTop: 16,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>닫기</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ─── 메인 화면 ───
export default function FridgeModeScreen() {
  const colors = useColors();
  const router = useRouter();

  const [step, setStep] = useState<Step>("ingredient-select");
  const [selectedWeather, setSelectedWeather] = useState<WeatherType | null>(null);
  const [selectedTime, setSelectedTime] = useState<TimeSlot | null>(null);
  const [selectedDay, setSelectedDay] = useState<DayType | null>(null);
  const [categoryScores, setCategoryScores] = useState<HomeCookingScore[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<HomeCookingCategory | null>(null);
  const [selectedIngredients, setSelectedIngredients] = useState<Set<string>>(new Set());
  const [matchResults, setMatchResults] = useState<MatchResult[]>([]);
  const [recipeTarget, setRecipeTarget] = useState<MatchResult | null>(null);

  const goNext = () => {
    haptic();
    if (step === "ingredient-select") setStep("weather");
    else if (step === "weather") setStep("time");
    else if (step === "time") setStep("day");
    else if (step === "day") {
      setCategoryScores(calculateHomeCookingScores(selectedWeather, selectedTime, selectedDay));
      setStep("category-result");
    }
  };

  const goPrev = () => {
    haptic();
    if (step === "weather") setStep("ingredient-select");
    else if (step === "time") setStep("weather");
    else if (step === "day") setStep("time");
    else if (step === "category-result") setStep("day");
    else if (step === "menu-result") setStep("category-result");
  };

  const reset = () => {
    haptic();
    setStep("ingredient-select");
    setSelectedWeather(null);
    setSelectedTime(null);
    setSelectedDay(null);
    setCategoryScores([]);
    setSelectedCategory(null);
    setSelectedIngredients(new Set());
    setMatchResults([]);
    setRecipeTarget(null);
  };

  const handleCategorySelect = (cat: HomeCookingCategory) => {
    haptic();
    setSelectedCategory(cat);
    const userIngs = Array.from(selectedIngredients);
    const results: MatchResult[] = HOME_COOKING_MENUS
      .filter((m) => m.category === cat)
      .map((m) => {
        const { matchRate, missing } = calculateIngredientMatch(m, userIngs);
        return { menu: m, matchRate, missingIngredients: missing };
      })
      .sort((a, b) => b.matchRate - a.matchRate);
    setMatchResults(results);
    setStep("menu-result");
  };

  const toggleIngredient = (name: string) => {
    haptic();
    setSelectedIngredients((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const showResults = () => {
    haptic();
    // 재료 선택 완료 후 날씨 단계로 이동
    setStep("weather");
  };

  const goToRestaurant = (menuName: string) => {
    haptic();
    router.push({ pathname: "/(tabs)/restaurants", params: { recommendedMenu: menuName } } as any);
  };

  // 진행 바: ingredient-select=1, weather=2, time=3, day=4, category-result=5, menu-result=6
  const stepIndex = ["ingredient-select", "weather", "time", "day", "category-result", "menu-result"].indexOf(step);
  const progress = stepIndex + 1;
  const totalSteps = 6;

  const stepTitle: Record<Step, string> = {
    "ingredient-select": "냉장고 재료를 선택해주세요",
    weather: "오늘 날씨는 어때요?",
    time: "지금 시간대는?",
    day: "오늘은 무슨 요일?",
    "category-result": "추천 카테고리 순위",
    "menu-result": "매칭 메뉴 추천",
  };

  const stepSub: Record<Step, string> = {
    "ingredient-select": "있는 재료를 선택하면 만들 수 있는 메뉴를 찾아드려요",
    weather: "날씨에 맞는 집밥 카테고리를 추천해드릴게요",
    time: "식사 시간대를 알려주세요",
    day: "평일과 주말 분위기가 달라요",
    "category-result": "카테고리를 탭하면 바로 메뉴를 추천해드려요",
    "menu-result": "보유 재료 매칭률 순으로 정렬했어요",
  };

  const weatherOptions: { value: WeatherType; emoji: string }[] = [
    { value: "비/흐림", emoji: "🌧" },
    { value: "추움", emoji: "🥶" },
    { value: "더움/맑음", emoji: "☀️" },
  ];

  const timeOptions: { value: TimeSlot; emoji: string }[] = [
    { value: "아침", emoji: "🌅" },
    { value: "점심(평일)", emoji: "☀️" },
    { value: "저녁", emoji: "🌙" },
  ];

  const dayOptions: { value: DayType; emoji: string }[] = [
    { value: "평일", emoji: "💼" },
    { value: "주말", emoji: "🎉" },
  ];

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>

        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 }}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({
              flexDirection: "row" as const,
              alignItems: "center" as const,
              marginBottom: 12,
              opacity: pressed ? 0.6 : 1,
              alignSelf: "flex-start" as const,
            })}
          >
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>
          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground }}>🍳 냉장고 모드</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>
            재료를 선택하면 만들 수 있는 집밥을 추천해드려요
          </Text>
        </View>

        {/* 진행 바 (카테고리 선택 단계까지만) */}
        {(step === "ingredient-select" || step === "weather" || step === "time" || step === "day" || step === "category-result") && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <View style={{ height: 4, backgroundColor: `${colors.primary}20`, borderRadius: 2, overflow: "hidden" }}>
              <View style={{ height: "100%", width: `${(Math.min(progress, 5) / 5) * 100}%`, backgroundColor: colors.primary, borderRadius: 2 }} />
            </View>
            <Text style={{ fontSize: 11, color: colors.muted, marginTop: 4, textAlign: "right" }}>{Math.min(progress, 5)} / 5</Text>
          </View>
        )}

        {/* 스텝 제목 */}
        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground }}>{stepTitle[step]}</Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>{stepSub[step]}</Text>
        </View>

        {/* ── 날씨 선택 ── */}
        {step === "weather" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {weatherOptions.map((w) => (
                <SelectButton
                  key={w.value}
                  label={w.value}
                  emoji={w.emoji}
                  isSelected={selectedWeather === w.value}
                  onPress={() => { haptic(); setSelectedWeather(selectedWeather === w.value ? null : w.value); }}
                />
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedWeather(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedWeather === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 시간대 선택 ── */}
        {step === "time" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {timeOptions.map((t) => (
                <SelectButton
                  key={t.value}
                  label={t.value}
                  emoji={t.emoji}
                  isSelected={selectedTime === t.value}
                  onPress={() => { haptic(); setSelectedTime(selectedTime === t.value ? null : t.value); }}
                />
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedTime(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedTime === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 요일 선택 ── */}
        {step === "day" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {dayOptions.map((d) => (
                <SelectButton
                  key={d.value}
                  label={d.value}
                  emoji={d.emoji}
                  isSelected={selectedDay === d.value}
                  onPress={() => { haptic(); setSelectedDay(selectedDay === d.value ? null : d.value); }}
                />
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedDay(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedDay === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 카테고리 결과 ── */}
        {step === "category-result" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 선택 조건 요약 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 12, fontWeight: "600", color: colors.muted, marginBottom: 6 }}>선택한 조건</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                <Text style={{ fontSize: 13, color: colors.foreground }}>
                  {selectedWeather ? `${weatherOptions.find(w => w.value === selectedWeather)?.emoji} ${selectedWeather}` : "날씨 미선택"}
                </Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>·</Text>
                <Text style={{ fontSize: 13, color: colors.foreground }}>
                  {selectedTime ? `${timeOptions.find(t => t.value === selectedTime)?.emoji} ${selectedTime}` : "시간 미선택"}
                </Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>·</Text>
                <Text style={{ fontSize: 13, color: colors.foreground }}>
                  {selectedDay ? `${dayOptions.find(d => d.value === selectedDay)?.emoji} ${selectedDay}` : "요일 미선택"}
                </Text>
              </View>
            </View>

            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12, textAlign: "center" }}>
              👇 카테고리를 탭하면 바로 메뉴를 추천해드려요
            </Text>

            {categoryScores.map((item, index) => (
              <CategoryResultCard
                key={item.category}
                rank={index + 1}
                item={item}
                onSelect={handleCategorySelect}
              />
            ))}
          </View>
        )}

        {/* ── 재료 선택 ── */}
        {step === "ingredient-select" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 선택 요약 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 13, color: colors.primary, fontWeight: "700" }}>
                선택한 재료: {selectedIngredients.size}개
              </Text>
            </View>

            {/* 메인 재료 */}
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginBottom: 12 }}>🥩 메인 재료</Text>
            {MAIN_INGREDIENTS.map((group) => (
              <View key={group.groupName} style={{ marginBottom: 16 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.muted, marginBottom: 8 }}>
                  {group.emoji} {group.groupName}
                </Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {group.items.map((item) => (
                    <IngredientChip
                      key={item}
                      label={item}
                      selected={selectedIngredients.has(item)}
                      onPress={() => toggleIngredient(item)}
                    />
                  ))}
                </View>
              </View>
            ))}

            {/* 소스·양념 */}
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginBottom: 12, marginTop: 8 }}>🫙 소스·양념</Text>
            {SAUCE_INGREDIENTS.map((group) => (
              <View key={group.groupName} style={{ marginBottom: 16 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.muted, marginBottom: 8 }}>
                  {group.emoji} {group.groupName}
                </Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {group.items.map((item) => (
                    <IngredientChip
                      key={item}
                      label={item}
                      selected={selectedIngredients.has(item)}
                      onPress={() => toggleIngredient(item)}
                    />
                  ))}
                </View>
              </View>
            ))}
          </View>
        )}

        {/* ── 메뉴 결과 ── */}
        {step === "menu-result" && (
          <View style={{ paddingHorizontal: 20 }}>
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 13, color: colors.primary, fontWeight: "700" }}>
                {selectedCategory} · 보유 재료 {selectedIngredients.size}개 기준
              </Text>
            </View>
            {matchResults.slice(0, 5).map((result, idx) => (
              <MatchCard
                key={result.menu.name}
                result={result}
                rank={idx + 1}
                onFindRestaurant={goToRestaurant}
                onShowRecipe={setRecipeTarget}
              />
            ))}

          </View>
        )}

        {/* ── 하단 버튼 ── */}
        <View style={{ paddingHorizontal: 20, marginTop: 28, gap: 10 }}>
          {/* 재료 선택 단계 */}
          {step === "ingredient-select" && (
            <>
              <Pressable
                onPress={showResults}
                style={({ pressed }) => ({
                  backgroundColor: colors.primary,
                  borderRadius: 14,
                  paddingVertical: 16,
                  alignItems: "center" as const,
                  shadowColor: colors.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 4,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                  opacity: pressed ? 0.9 : 1,
                })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>
                  다음 → ({selectedIngredients.size}개 선택)
                </Text>
              </Pressable>
            </>
          )}

          {/* 날씨/시간/요일 단계 */}
          {(step === "weather" || step === "time" || step === "day") && (
            <>
              <Pressable
                onPress={goNext}
                style={({ pressed }) => ({
                  backgroundColor: colors.primary,
                  borderRadius: 14,
                  paddingVertical: 16,
                  alignItems: "center" as const,
                  shadowColor: colors.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 4,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                  opacity: pressed ? 0.9 : 1,
                })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>
                  {step === "day" ? "카테고리 추천받기 →" : "다음 →"}
                </Text>
              </Pressable>
              <Pressable
                onPress={goPrev}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 이전</Text>
              </Pressable>
            </>
          )}

          {/* 카테고리 결과 단계 */}
          {step === "category-result" && (
            <>
              <Pressable
                onPress={reset}
                style={({ pressed }) => ({
                  backgroundColor: colors.primary,
                  borderRadius: 14,
                  paddingVertical: 16,
                  alignItems: "center" as const,
                  shadowColor: colors.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 4,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                  opacity: pressed ? 0.9 : 1,
                })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>🔄 다시 추천받기</Text>
              </Pressable>
              <Pressable
                onPress={goPrev}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 조건 수정</Text>
              </Pressable>
            </>
          )}



          {/* 메뉴 결과 단계 */}
          {step === "menu-result" && (
            <>
              <Pressable
                onPress={goPrev}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 카테고리 다시 선택</Text>
              </Pressable>
              <Pressable
                onPress={reset}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>🔄 처음부터 다시</Text>
              </Pressable>
            </>
          )}
        </View>
      </ScrollView>

      {/* 레시피 모달 */}
      {recipeTarget && (
        <RecipeModal result={recipeTarget} onClose={() => setRecipeTarget(null)} />
      )}
    </ScreenContainer>
  );
}
