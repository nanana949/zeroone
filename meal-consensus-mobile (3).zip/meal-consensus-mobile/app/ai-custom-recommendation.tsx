import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { useState, useEffect } from "react";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

// ─── 추천 메뉴 데이터 ────────────────────────────────────────────────────────────

const QUICK_RECOMMENDATIONS = [
  { id: 1, emoji: "🍕", name: "피자", description: "맛있고 푸짐한 피자" },
  { id: 2, emoji: "🍜", name: "국수", description: "따뜻하고 편한 국수" },
  { id: 3, emoji: "🍱", name: "일식", description: "정갈하고 신선한 일식" },
  { id: 4, emoji: "🍔", name: "버거", description: "든든한 버거" },
  { id: 5, emoji: "🥗", name: "샐러드", description: "건강한 샐러드" },
  { id: 6, emoji: "🍲", name: "찌개", description: "따뜻한 찌개" },
  { id: 7, emoji: "🍝", name: "파스타", description: "부드러운 파스타" },
  { id: 8, emoji: "🥡", name: "중식", description: "푸짐한 중식" },
];

export default function AICustomRecommendationScreen() {
  const colors = useColors();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<any>(null);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedWeather, setSelectedWeather] = useState<string | null>(null);

  // tRPC 쿼리 - 기분, 날씨, 시간대 옵션 조회
  const moodsQuery = trpc.aiRecommendations.moods.useQuery();
  const weathersQuery = trpc.aiRecommendations.weathers.useQuery();
  const timeOfDayQuery = trpc.aiRecommendations.currentTimeOfDay.useQuery();

  // tRPC 쿼리 - 추천 요청 (별도 함수로 처리)

  // 빠른 추천 버튼 클릭
  const handleQuickRecommend = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setLoading(true);

    try {
      // 랜덤 기분, 날씨 선택
      const moods = moodsQuery.data || [];
      const weathers = weathersQuery.data || [];
      const randomMood = moods[Math.floor(Math.random() * moods.length)];
      const randomWeather = weathers[Math.floor(Math.random() * weathers.length)];
      const timeOfDay = timeOfDayQuery.data || "오후";

      if (randomMood && randomWeather) {
        setSelectedMood(randomMood.id);
        setSelectedWeather(randomWeather.id);

        // tRPC 추천 요청
        try {
          const result = await (trpc.aiRecommendations.recommend as any).query({
            mood: randomMood.id,
            weather: randomWeather.id,
            timeOfDay: timeOfDay,
          });

          setRecommendation({
            mood: randomMood,
            weather: randomWeather,
            timeOfDay,
            menu: result.menu,
            reason: result.reason,
          });
        } catch (err) {
          console.error('API 오류:', err);
          // 폴백: 로컬 추천
          const randomMenu = QUICK_RECOMMENDATIONS[
            Math.floor(Math.random() * QUICK_RECOMMENDATIONS.length)
          ];
          setRecommendation({
            mood: randomMood,
            weather: randomWeather,
            timeOfDay,
            menu: `${randomMenu.emoji} ${randomMenu.name}`,
            reason: randomMenu.description,
          });
        }

        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      console.error("추천 실패:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  // 랜덤 메뉴 추천
  const handleRandomRecommend = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setLoading(true);

    setTimeout(() => {
      const randomMenu = QUICK_RECOMMENDATIONS[
        Math.floor(Math.random() * QUICK_RECOMMENDATIONS.length)
      ];

      setRecommendation({
        menu: `${randomMenu.emoji} ${randomMenu.name}`,
        reason: randomMenu.description,
        isRandom: true,
      });

      setLoading(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }, 800);
  };

  const styles = StyleSheet.create({
    headerCard: {
      backgroundColor: colors.primary,
      borderRadius: 20,
      padding: 20,
      marginBottom: 20,
      gap: 8,
    },
    headerTitle: {
      fontSize: 28,
      fontWeight: "800",
      color: "#fff",
    },
    headerSubtitle: {
      fontSize: 13,
      color: "rgba(255,255,255,0.9)",
    },
    buttonContainer: {
      gap: 12,
      marginBottom: 24,
    },
    button: {
      backgroundColor: colors.primary,
      borderRadius: 16,
      padding: 16,
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
    },
    buttonText: {
      fontSize: 16,
      fontWeight: "700",
      color: "#fff",
    },
    buttonSubtext: {
      fontSize: 12,
      color: "rgba(255,255,255,0.8)",
    },
    recommendationCard: {
      backgroundColor: colors.surface,
      borderRadius: 20,
      padding: 20,
      gap: 12,
      borderWidth: 2,
      borderColor: colors.primary,
    },
    recommendationEmoji: {
      fontSize: 48,
      textAlign: "center",
    },
    recommendationMenu: {
      fontSize: 24,
      fontWeight: "700",
      color: colors.foreground,
      textAlign: "center",
    },
    recommendationReason: {
      fontSize: 14,
      color: colors.muted,
      textAlign: "center",
      lineHeight: 20,
    },
    moodWeatherInfo: {
      flexDirection: "row",
      gap: 8,
      justifyContent: "center",
      marginTop: 8,
      flexWrap: "wrap",
    },
    badge: {
      backgroundColor: colors.primary,
      borderRadius: 8,
      paddingHorizontal: 12,
      paddingVertical: 6,
    },
    badgeText: {
      fontSize: 12,
      fontWeight: "600",
      color: "#fff",
    },
    quickMenuGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 10,
      marginBottom: 24,
    },
    quickMenuButton: {
      width: "48%",
      backgroundColor: colors.surface,
      borderRadius: 16,
      padding: 16,
      alignItems: "center",
      gap: 8,
      borderWidth: 2,
      borderColor: colors.border,
    },
    quickMenuEmoji: {
      fontSize: 32,
    },
    quickMenuName: {
      fontSize: 14,
      fontWeight: "600",
      color: colors.foreground,
    },
    loadingContainer: {
      alignItems: "center",
      gap: 12,
    },
    loadingText: {
      fontSize: 14,
      color: colors.muted,
    },
  });

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="p-4">
        {/* 헤더 */}
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>🤖 AI 맞춤 추천</Text>
          <Text style={styles.headerSubtitle}>
            버튼만 누르면 맞춤 메뉴를 추천해드려요!
          </Text>
        </View>

        {/* 추천 결과 */}
        {recommendation ? (
          <View style={styles.recommendationCard}>
            <Text style={styles.recommendationEmoji}>
              {recommendation.menu?.split(" ")[0] || "🍽️"}
            </Text>
            <Text style={styles.recommendationMenu}>
              {recommendation.menu || "추천 메뉴"}
            </Text>
            <Text style={styles.recommendationReason}>
              {recommendation.reason}
            </Text>

            {/* 기분, 날씨 정보 */}
            {recommendation.mood && recommendation.weather && (
              <View style={styles.moodWeatherInfo}>
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>
                    {recommendation.mood.emoji} {recommendation.mood.label}
                  </Text>
                </View>
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>
                    {recommendation.weather.emoji} {recommendation.weather.label}
                  </Text>
                </View>
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>⏰ {recommendation.timeOfDay}</Text>
                </View>
              </View>
            )}
          </View>
        ) : null}

        {/* 추천 버튼들 */}
        <View style={styles.buttonContainer}>
          <Pressable
            style={({ pressed }) => [
              styles.button,
              pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
            ]}
            onPress={handleQuickRecommend}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Text style={styles.buttonText}>🎲 기분으로 추천받기</Text>
                <Text style={styles.buttonSubtext}>
                  기분과 날씨를 반영한 추천
                </Text>
              </>
            )}
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: colors.success },
              pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
            ]}
            onPress={handleRandomRecommend}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Text style={styles.buttonText}>✨ 랜덤 추천받기</Text>
                <Text style={styles.buttonSubtext}>
                  무작위로 메뉴를 추천해드려요
                </Text>
              </>
            )}
          </Pressable>
        </View>

        {/* 빠른 메뉴 선택 */}
        <Text
          style={{
            fontSize: 16,
            fontWeight: "700",
            marginBottom: 12,
            color: colors.foreground,
          }}
        >
          💡 인기 메뉴
        </Text>
        <View style={styles.quickMenuGrid}>
          {QUICK_RECOMMENDATIONS.map((menu) => (
            <Pressable
              key={menu.id}
              style={({ pressed }) => [
                styles.quickMenuButton,
                pressed && { opacity: 0.7, backgroundColor: colors.primary },
              ]}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setRecommendation({
                  menu: `${menu.emoji} ${menu.name}`,
                  reason: menu.description,
                });
              }}
            >
              <Text style={styles.quickMenuEmoji}>{menu.emoji}</Text>
              <Text style={styles.quickMenuName}>{menu.name}</Text>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
