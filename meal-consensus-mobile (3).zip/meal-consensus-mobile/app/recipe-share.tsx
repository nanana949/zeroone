import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const SHARED_RECIPES = [
  {
    id: 1,
    author: "김철수",
    recipe: "계란 덮밥",
    description: "5분 안에 만드는 간단한 아침 식사!",
    likes: 234,
    emoji: "🍚",
  },
  {
    id: 2,
    author: "이영희",
    recipe: "스파게티",
    description: "집에서 만드는 이탈리안 파스타",
    likes: 567,
    emoji: "🍝",
  },
  {
    id: 3,
    author: "박민수",
    recipe: "김밥",
    description: "소풍 가기 전 필수 요리!",
    likes: 345,
    emoji: "🍙",
  },
];

export default function RecipeShareScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    recipeCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            👨‍🍳 레시피 공유
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            친구들이 공유한 맛있는 레시피들
          </Text>

          {SHARED_RECIPES.map((recipe) => (
            <View key={recipe.id} style={styles.recipeCard}>
              <View style={{ flexDirection: "row", alignItems: "flex-start", marginBottom: 10 }}>
                <Text style={{ fontSize: 32, marginRight: 12 }}>{recipe.emoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>
                    {recipe.recipe}
                  </Text>
                  <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
                    by {recipe.author}
                  </Text>
                </View>
              </View>
              <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 10, lineHeight: 18 }}>
                {recipe.description}
              </Text>
              <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Pressable
                  style={{
                    flex: 1,
                    paddingVertical: 8,
                    paddingHorizontal: 12,
                    backgroundColor: colors.primary + "20",
                    borderRadius: 8,
                    marginRight: 8,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontSize: 12, fontWeight: "600", color: colors.primary }}>
                    ❤️ {recipe.likes}
                  </Text>
                </Pressable>
                <Pressable
                  style={{
                    flex: 1,
                    paddingVertical: 8,
                    paddingHorizontal: 12,
                    backgroundColor: colors.primary,
                    borderRadius: 8,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontSize: 12, fontWeight: "600", color: "#fff" }}>
                    저장하기
                  </Text>
                </Pressable>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
