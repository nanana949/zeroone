import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const BUDGET_OPTIONS = [
  { id: 1, label: "5,000원 이하", emoji: "💰", selected: false },
  { id: 2, label: "5,000 ~ 10,000원", emoji: "💵", selected: true },
  { id: 3, label: "10,000 ~ 15,000원", emoji: "💴", selected: false },
  { id: 4, label: "15,000원 이상", emoji: "💶", selected: false },
];

const RECOMMENDATIONS = [
  { name: "김밥", price: "5,000원", emoji: "🍙" },
  { name: "라면", price: "6,000원", emoji: "🍜" },
  { name: "돈까스", price: "9,000원", emoji: "🍖" },
];

export default function BudgetRecommendScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    budgetButton: {
      width: "48%",
      paddingVertical: 12,
      paddingHorizontal: 12,
      borderRadius: 12,
      marginHorizontal: "1%",
      marginBottom: 12,
      alignItems: "center",
      borderWidth: 2,
    },
    recommendCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
      flexDirection: "row",
      alignItems: "center",
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            💰 예산 추천
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            오늘 식비 예산을 선택하세요
          </Text>

          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
            예산 선택
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
            {BUDGET_OPTIONS.map((budget) => (
              <Pressable
                key={budget.id}
                style={[
                  styles.budgetButton,
                  {
                    backgroundColor: budget.selected ? colors.primary + "30" : colors.surface,
                    borderColor: budget.selected ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text style={{ fontSize: 20, marginBottom: 4 }}>{budget.emoji}</Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "600",
                    color: colors.foreground,
                    textAlign: "center",
                  }}
                >
                  {budget.label}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginTop: 24, marginBottom: 12 }}>
            추천 메뉴
          </Text>
          {RECOMMENDATIONS.map((rec, idx) => (
            <View key={idx} style={styles.recommendCard}>
              <Text style={{ fontSize: 28, marginRight: 12 }}>{rec.emoji}</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>
                  {rec.name}
                </Text>
              </View>
              <Text style={{ fontSize: 13, fontWeight: "700", color: colors.primary }}>
                {rec.price}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
