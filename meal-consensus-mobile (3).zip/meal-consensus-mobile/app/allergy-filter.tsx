import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useState } from "react";

const ALLERGIES = [
  { id: 1, name: "계란", emoji: "🥚", selected: false },
  { id: 2, name: "우유", emoji: "🥛", selected: false },
  { id: 3, name: "견과류", emoji: "🥜", selected: false },
  { id: 4, name: "해산물", emoji: "🦐", selected: false },
  { id: 5, name: "글루텐", emoji: "🌾", selected: false },
  { id: 6, name: "콩", emoji: "🫘", selected: false },
];

export default function AllergyFilterScreen() {
  const colors = useColors();
  const router = useRouter();
  const [selected, setSelected] = useState<number[]>([]);

  const toggleAllergy = (id: number) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const styles = StyleSheet.create({
    allergyButton: {
      width: "48%",
      aspectRatio: 1,
      borderRadius: 12,
      padding: 12,
      marginHorizontal: "1%",
      marginBottom: 12,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 2,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            🚫 알레르기 필터
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            알레르기가 있는 음식을 선택하세요
          </Text>

          <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
            {ALLERGIES.map((allergy) => (
              <Pressable
                key={allergy.id}
                onPress={() => toggleAllergy(allergy.id)}
                style={[
                  styles.allergyButton,
                  {
                    backgroundColor: selected.includes(allergy.id)
                      ? colors.primary + "30"
                      : colors.surface,
                    borderColor: selected.includes(allergy.id)
                      ? colors.primary
                      : colors.border,
                  },
                ]}
              >
                <Text style={{ fontSize: 32, marginBottom: 8 }}>{allergy.emoji}</Text>
                <Text
                  style={{
                    fontSize: 13,
                    fontWeight: "600",
                    color: colors.foreground,
                    textAlign: "center",
                  }}
                >
                  {allergy.name}
                </Text>
              </Pressable>
            ))}
          </View>

          {selected.length > 0 && (
            <View
              style={{
                marginTop: 24,
                paddingHorizontal: 16,
                paddingVertical: 12,
                backgroundColor: colors.success + "20",
                borderRadius: 12,
              }}
            >
              <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground }}>
                선택된 알레르기: {selected.length}개
              </Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>
                이 음식들이 포함된 메뉴는 추천되지 않습니다
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
