import { View, Text, Pressable, ScrollView, TextInput, Modal, FlatList } from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";
import { useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  TasteProfile,
  FoodCategory,
  CATEGORIES,
  CATEGORY_EMOJIS,
  CONSENSUS_MENUS,
  calculateGroupMatch,
  MatchResult,
} from "@/lib/consensus-db";

const haptic = () => {
  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
};

type Step = "setup" | "taste" | "avoid" | "result";

const DEFAULT_PROFILE = (): TasteProfile => ({
  name: "",
  spicy: "보통",
  meat: "상관없음",
  categories: [],
  budget: "상관없음",
  avoid: [],
});

export default function ConsensusModeScreen() {
  const colors = useColors();
  const router = useRouter();

  const [step, setStep] = useState<Step>("setup");
  const [participantCount, setParticipantCount] = useState(2);
  const [currentParticipant, setCurrentParticipant] = useState(0);
  const [profiles, setProfiles] = useState<TasteProfile[]>([DEFAULT_PROFILE(), DEFAULT_PROFILE()]);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [showAvoidModal, setShowAvoidModal] = useState(false);
  const [avoidSearch, setAvoidSearch] = useState("");

  const currentProfile = profiles[currentParticipant];

  const updateProfile = (update: Partial<TasteProfile>) => {
    const next = [...profiles];
    next[currentParticipant] = { ...next[currentParticipant], ...update };
    setProfiles(next);
  };

  const toggleCategory = (cat: FoodCategory) => {
    const cats = currentProfile.categories;
    if (cats.includes(cat)) {
      updateProfile({ categories: cats.filter((c) => c !== cat) });
    } else {
      updateProfile({ categories: [...cats, cat] });
    }
  };

  const toggleAvoid = (menuName: string) => {
    const avoid = currentProfile.avoid;
    if (avoid.includes(menuName)) {
      updateProfile({ avoid: avoid.filter((m) => m !== menuName) });
    } else if (avoid.length < 2) {
      updateProfile({ avoid: [...avoid, menuName] });
    }
  };

  const goNext = () => {
    haptic();
    if (step === "setup") {
      const newProfiles = Array.from({ length: participantCount }, (_, i) =>
        profiles[i] ?? DEFAULT_PROFILE()
      );
      setProfiles(newProfiles);
      setCurrentParticipant(0);
      setStep("taste");
    } else if (step === "taste") {
      if (currentParticipant < participantCount - 1) {
        setCurrentParticipant(currentParticipant + 1);
      } else {
        setCurrentParticipant(0);
        setStep("avoid");
      }
    } else if (step === "avoid") {
      if (currentParticipant < participantCount - 1) {
        setCurrentParticipant(currentParticipant + 1);
      } else {
        // 결과 계산
        const res = calculateGroupMatch(CONSENSUS_MENUS, profiles);
        setResults(res.slice(0, 10));
        setStep("result");
      }
    }
  };

  const goPrev = () => {
    haptic();
    if (step === "taste" && currentParticipant > 0) {
      setCurrentParticipant(currentParticipant - 1);
    } else if (step === "taste") {
      setStep("setup");
    } else if (step === "avoid" && currentParticipant > 0) {
      setCurrentParticipant(currentParticipant - 1);
    } else if (step === "avoid") {
      setCurrentParticipant(participantCount - 1);
      setStep("taste");
    } else if (step === "result") {
      setCurrentParticipant(participantCount - 1);
      setStep("avoid");
    }
  };

  const restart = () => {
    setStep("setup");
    setCurrentParticipant(0);
    setParticipantCount(2);
    setProfiles([DEFAULT_PROFILE(), DEFAULT_PROFILE()]);
    setResults([]);
  };

  const progress =
    step === "setup" ? 0.1
    : step === "taste" ? 0.1 + (currentParticipant / participantCount) * 0.4
    : step === "avoid" ? 0.5 + (currentParticipant / participantCount) * 0.4
    : 1.0;

  const filteredMenus = CONSENSUS_MENUS.filter((m) =>
    avoidSearch ? m.name.includes(avoidSearch) : true
  );

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 120 }} showsVerticalScrollIndicator={false}>

        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 16 }}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1, alignSelf: "flex-start", marginBottom: 16 })}
          >
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <View style={{ alignItems: "center", marginBottom: 16 }}>
            <Text style={{ fontSize: 26, fontWeight: "900", color: colors.foreground }}>🤝 합의 모드</Text>
            <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>
              {step === "setup" && "인원을 설정하세요"}
              {step === "taste" && `${currentProfile.name || `참여자 ${currentParticipant + 1}`}의 취향을 입력하세요`}
              {step === "avoid" && `${currentProfile.name || `참여자 ${currentParticipant + 1}`}이(가) 절대 싫은 메뉴를 선택하세요`}
              {step === "result" && "그룹 최적 메뉴 추천 결과"}
            </Text>
          </View>

          {/* 진행 바 */}
          <View style={{ height: 6, backgroundColor: colors.border, borderRadius: 3, marginBottom: 24 }}>
            <View style={{ height: 6, backgroundColor: colors.primary, borderRadius: 3, width: `${progress * 100}%` }} />
          </View>
        </View>

        {/* ─── STEP 1: 인원 설정 ─── */}
        {step === "setup" && (
          <View style={{ paddingHorizontal: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground, marginBottom: 16 }}>
              👥 몇 명이 함께 먹나요?
            </Text>
            <View style={{ flexDirection: "row", gap: 12, flexWrap: "wrap" }}>
              {[2, 3, 4, 5, 6].map((n) => (
                <Pressable
                  key={n}
                  onPress={() => { haptic(); setParticipantCount(n); }}
                  style={({ pressed }) => ({
                    flex: 1, minWidth: 80,
                    backgroundColor: participantCount === n ? colors.primary : colors.surface,
                    borderRadius: 16, paddingVertical: 20, alignItems: "center",
                    borderWidth: 2, borderColor: participantCount === n ? colors.primary : colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 28 }}>{["👤", "👥", "👨‍👩‍👦", "👨‍👩‍👧‍👦", "🏘️"][n - 2]}</Text>
                  <Text style={{ fontSize: 18, fontWeight: "800", color: participantCount === n ? "#fff" : colors.foreground, marginTop: 4 }}>{n}명</Text>
                </Pressable>
              ))}
            </View>

            {/* 이름 입력 */}
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginTop: 24, marginBottom: 12 }}>
              참여자 이름 (선택)
            </Text>
            {Array.from({ length: participantCount }).map((_, i) => (
              <TextInput
                key={i}
                value={profiles[i]?.name ?? ""}
                onChangeText={(text) => {
                  const next = [...profiles];
                  while (next.length <= i) next.push(DEFAULT_PROFILE());
                  next[i] = { ...next[i], name: text };
                  setProfiles(next);
                }}
                placeholder={`참여자 ${i + 1} 이름`}
                placeholderTextColor={colors.muted}
                style={{
                  backgroundColor: colors.surface, borderRadius: 12, padding: 14,
                  fontSize: 15, color: colors.foreground, marginBottom: 8,
                  borderWidth: 1, borderColor: colors.border,
                }}
              />
            ))}
          </View>
        )}

        {/* ─── STEP 2: 취향 입력 ─── */}
        {step === "taste" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 참여자 표시 */}
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 20 }}>
              {profiles.map((p, i) => (
                <View key={i} style={{
                  paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20,
                  backgroundColor: i === currentParticipant ? colors.primary : colors.surface,
                  borderWidth: 1, borderColor: i === currentParticipant ? colors.primary : colors.border,
                }}>
                  <Text style={{ fontSize: 13, fontWeight: "700", color: i === currentParticipant ? "#fff" : colors.muted }}>
                    {p.name || `참여자 ${i + 1}`}
                  </Text>
                </View>
              ))}
            </View>

            {/* 매운맛 */}
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginBottom: 10 }}>🌶️ 매운맛 선호도</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
              {(["못먹음", "약간", "보통", "매운거좋아"] as const).map((v) => (
                <Pressable
                  key={v}
                  onPress={() => { haptic(); updateProfile({ spicy: v }); }}
                  style={({ pressed }) => ({
                    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20,
                    backgroundColor: currentProfile.spicy === v ? "#FF6B6B" : colors.surface,
                    borderWidth: 1.5, borderColor: currentProfile.spicy === v ? "#FF6B6B" : colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 14, fontWeight: "700", color: currentProfile.spicy === v ? "#fff" : colors.foreground }}>
                    {v === "못먹음" ? "🚫 못먹음" : v === "약간" ? "🟡 약간" : v === "보통" ? "🟠 보통" : "🔴 매운거좋아"}
                  </Text>
                </Pressable>
              ))}
            </View>

            {/* 고기 선호도 */}
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginBottom: 10 }}>🥩 고기 선호도</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 20 }}>
              {(["좋아함", "상관없음", "채식선호"] as const).map((v) => (
                <Pressable
                  key={v}
                  onPress={() => { haptic(); updateProfile({ meat: v }); }}
                  style={({ pressed }) => ({
                    flex: 1, paddingVertical: 12, borderRadius: 16, alignItems: "center",
                    backgroundColor: currentProfile.meat === v ? "#4CAF50" : colors.surface,
                    borderWidth: 1.5, borderColor: currentProfile.meat === v ? "#4CAF50" : colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 13, fontWeight: "700", color: currentProfile.meat === v ? "#fff" : colors.foreground }}>
                    {v === "좋아함" ? "🥩 좋아함" : v === "상관없음" ? "😊 상관없음" : "🥦 채식선호"}
                  </Text>
                </Pressable>
              ))}
            </View>

            {/* 예산 */}
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginBottom: 10 }}>💰 예산</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
              {(["5천원이하", "1만원이하", "1만5천원이하", "상관없음"] as const).map((v) => (
                <Pressable
                  key={v}
                  onPress={() => { haptic(); updateProfile({ budget: v }); }}
                  style={({ pressed }) => ({
                    paddingHorizontal: 14, paddingVertical: 10, borderRadius: 20,
                    backgroundColor: currentProfile.budget === v ? "#F59E0B" : colors.surface,
                    borderWidth: 1.5, borderColor: currentProfile.budget === v ? "#F59E0B" : colors.border,
                    opacity: pressed ? 0.7 : 1,
                  })}
                >
                  <Text style={{ fontSize: 13, fontWeight: "700", color: currentProfile.budget === v ? "#fff" : colors.foreground }}>{v}</Text>
                </Pressable>
              ))}
            </View>

            {/* 선호 카테고리 */}
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginBottom: 10 }}>
              🍽️ 선호 음식 종류 <Text style={{ fontSize: 12, fontWeight: "400", color: colors.muted }}>(복수 선택 가능)</Text>
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {CATEGORIES.map((cat) => {
                const selected = currentProfile.categories.includes(cat);
                return (
                  <Pressable
                    key={cat}
                    onPress={() => { haptic(); toggleCategory(cat); }}
                    style={({ pressed }) => ({
                      paddingHorizontal: 14, paddingVertical: 10, borderRadius: 20,
                      backgroundColor: selected ? colors.primary : colors.surface,
                      borderWidth: 1.5, borderColor: selected ? colors.primary : colors.border,
                      opacity: pressed ? 0.7 : 1,
                    })}
                  >
                    <Text style={{ fontSize: 13, fontWeight: "700", color: selected ? "#fff" : colors.foreground }}>
                      {CATEGORY_EMOJIS[cat]} {cat}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        )}

        {/* ─── STEP 3: 거부 메뉴 선택 ─── */}
        {step === "avoid" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 참여자 표시 */}
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 16 }}>
              {profiles.map((p, i) => (
                <View key={i} style={{
                  paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20,
                  backgroundColor: i === currentParticipant ? "#EF4444" : colors.surface,
                  borderWidth: 1, borderColor: i === currentParticipant ? "#EF4444" : colors.border,
                }}>
                  <Text style={{ fontSize: 13, fontWeight: "700", color: i === currentParticipant ? "#fff" : colors.muted }}>
                    {p.name || `참여자 ${i + 1}`}
                  </Text>
                </View>
              ))}
            </View>

            <View style={{ backgroundColor: "#FFF0F0", borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: "#FFCDD2" }}>
              <Text style={{ fontSize: 15, fontWeight: "700", color: "#C62828", lineHeight: 22 }}>
                🚫 "이건 절대 안 돼요" 메뉴를 최대 2개 선택하세요{"\n"}
                <Text style={{ fontSize: 13, fontWeight: "400", color: "#EF5350" }}>
                  싫어하는 메뉴를 빼는 게 갈등을 줄이는 가장 쉬운 방법이에요
                </Text>
              </Text>
            </View>

            {/* 선택된 거부 메뉴 */}
            {currentProfile.avoid.length > 0 && (
              <View style={{ flexDirection: "row", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
                {currentProfile.avoid.map((m) => (
                  <Pressable
                    key={m}
                    onPress={() => { haptic(); toggleAvoid(m); }}
                    style={{ backgroundColor: "#EF4444", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6, flexDirection: "row", alignItems: "center", gap: 4 }}
                  >
                    <Text style={{ fontSize: 13, color: "#fff", fontWeight: "700" }}>🚫 {m}</Text>
                    <Text style={{ fontSize: 13, color: "#fff" }}>✕</Text>
                  </Pressable>
                ))}
              </View>
            )}

            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 8 }}>
              {currentProfile.avoid.length}/2개 선택됨 · 메뉴를 눌러 추가/제거
            </Text>

            {/* 메뉴 검색 */}
            <TextInput
              value={avoidSearch}
              onChangeText={setAvoidSearch}
              placeholder="메뉴 이름 검색..."
              placeholderTextColor={colors.muted}
              style={{
                backgroundColor: colors.surface, borderRadius: 12, padding: 12,
                fontSize: 14, color: colors.foreground, marginBottom: 12,
                borderWidth: 1, borderColor: colors.border,
              }}
            />

            {/* 카테고리별 메뉴 목록 */}
            {CATEGORIES.map((cat) => {
              const catMenus = filteredMenus.filter((m) => m.category === cat);
              if (catMenus.length === 0) return null;
              return (
                <View key={cat} style={{ marginBottom: 16 }}>
                  <Text style={{ fontSize: 14, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
                    {CATEGORY_EMOJIS[cat]} {cat}
                  </Text>
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                    {catMenus.map((menu) => {
                      const isAvoided = currentProfile.avoid.includes(menu.name);
                      const canAdd = currentProfile.avoid.length < 2 || isAvoided;
                      return (
                        <Pressable
                          key={menu.id}
                          onPress={() => { if (canAdd) { haptic(); toggleAvoid(menu.name); } }}
                          style={({ pressed }) => ({
                            paddingHorizontal: 12, paddingVertical: 8, borderRadius: 16,
                            backgroundColor: isAvoided ? "#EF4444" : canAdd ? colors.surface : `${colors.surface}80`,
                            borderWidth: 1, borderColor: isAvoided ? "#EF4444" : colors.border,
                            opacity: pressed ? 0.7 : canAdd ? 1 : 0.4,
                          })}
                        >
                          <Text style={{ fontSize: 13, fontWeight: isAvoided ? "700" : "500", color: isAvoided ? "#fff" : colors.foreground }}>
                            {isAvoided ? "🚫 " : ""}{menu.name}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* ─── STEP 4: 결과 ─── */}
        {step === "result" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 요약 */}
            <View style={{ backgroundColor: `${colors.primary}15`, borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: `${colors.primary}30` }}>
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.primary, marginBottom: 8 }}>
                👥 {participantCount}명의 취향을 분석했어요
              </Text>
              {profiles.map((p, i) => (
                <Text key={i} style={{ fontSize: 13, color: colors.muted, lineHeight: 20 }}>
                  • {p.name || `참여자 ${i + 1}`}: 매운맛 {p.spicy}, 고기 {p.meat}, 예산 {p.budget}
                  {p.avoid.length > 0 ? ` | 거부: ${p.avoid.join(", ")}` : ""}
                </Text>
              ))}
            </View>

            {results.length === 0 ? (
              <View style={{ alignItems: "center", padding: 40 }}>
                <Text style={{ fontSize: 40, marginBottom: 12 }}>😅</Text>
                <Text style={{ fontSize: 18, fontWeight: "700", color: colors.foreground, textAlign: "center" }}>
                  모두가 만족할 메뉴를 찾지 못했어요
                </Text>
                <Text style={{ fontSize: 14, color: colors.muted, marginTop: 8, textAlign: "center" }}>
                  거부 메뉴를 줄이거나 취향 조건을 완화해보세요
                </Text>
              </View>
            ) : (
              results.map((r, idx) => (
                <View
                  key={r.menu.id}
                  style={{
                    backgroundColor: idx === 0 ? `${colors.primary}10` : colors.surface,
                    borderRadius: 20, padding: 18, marginBottom: 12,
                    borderWidth: idx === 0 ? 2 : 1,
                    borderColor: idx === 0 ? colors.primary : colors.border,
                    shadowColor: "#000", shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.06, shadowRadius: 8, elevation: 2,
                  }}
                >
                  {/* 순위 + 이름 */}
                  <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
                    <Text style={{ fontSize: 22, marginRight: 10 }}>
                      {idx === 0 ? "🥇" : idx === 1 ? "🥈" : idx === 2 ? "🥉" : `${idx + 1}.`}
                    </Text>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 18, fontWeight: "900", color: colors.foreground }}>{r.menu.name}</Text>
                      <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
                        {CATEGORY_EMOJIS[r.menu.category]} {r.menu.category}
                      </Text>
                    </View>
                    {/* 만족도 점수 */}
                    <View style={{
                      backgroundColor: r.score >= 70 ? "#4CAF50" : r.score >= 50 ? "#F59E0B" : "#EF4444",
                      borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6,
                    }}>
                      <Text style={{ fontSize: 16, fontWeight: "900", color: "#fff" }}>{r.score}%</Text>
                    </View>
                  </View>

                  {/* 참여자별 만족도 */}
                  <View style={{ gap: 6 }}>
                    {r.satisfactionBreakdown.map((b, bi) => (
                      <View key={bi} style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                        <Text style={{ fontSize: 12, color: colors.muted, width: 70 }}>
                          {profiles[bi]?.name || `참여자 ${bi + 1}`}
                        </Text>
                        <View style={{ flex: 1, height: 6, backgroundColor: colors.border, borderRadius: 3 }}>
                          <View style={{
                            height: 6, borderRadius: 3,
                            backgroundColor: b.score >= 70 ? "#4CAF50" : b.score >= 50 ? "#F59E0B" : "#EF4444",
                            width: `${b.score}%`,
                          }} />
                        </View>
                        <Text style={{ fontSize: 12, fontWeight: "700", color: colors.foreground, width: 32, textAlign: "right" }}>
                          {b.score}%
                        </Text>
                      </View>
                    ))}
                  </View>

                  {/* 태그 */}
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
                    {Object.values(r.menu.tags).map((tag, ti) => (
                      <View key={ti} style={{ backgroundColor: `${colors.primary}15`, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3 }}>
                        <Text style={{ fontSize: 11, color: colors.primary, fontWeight: "600" }}>{tag}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              ))
            )}

            {/* 다시하기 버튼 */}
            <Pressable
              onPress={restart}
              style={({ pressed }) => ({
                backgroundColor: colors.surface, borderRadius: 16, padding: 16,
                alignItems: "center", marginTop: 8,
                borderWidth: 1, borderColor: colors.border,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground }}>🔄 다시 설정하기</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>

      {/* 하단 버튼 */}
      {step !== "result" && (
        <View style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          backgroundColor: colors.background, paddingHorizontal: 20, paddingVertical: 16,
          borderTopWidth: 1, borderTopColor: colors.border,
          flexDirection: "row", gap: 12,
        }}>
          {step !== "setup" && (
            <Pressable
              onPress={goPrev}
              style={({ pressed }) => ({
                flex: 1, backgroundColor: colors.surface, borderRadius: 16, padding: 16,
                alignItems: "center", borderWidth: 1, borderColor: colors.border,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground }}>← 이전</Text>
            </Pressable>
          )}
          <Pressable
            onPress={goNext}
            style={({ pressed }) => ({
              flex: 2, backgroundColor: colors.primary, borderRadius: 16, padding: 16,
              alignItems: "center", opacity: pressed ? 0.8 : 1,
              shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.3, shadowRadius: 8, elevation: 4,
            })}
          >
            <Text style={{ fontSize: 15, fontWeight: "800", color: "#fff" }}>
              {step === "avoid" && currentParticipant === participantCount - 1
                ? "✨ 결과 보기"
                : step === "taste" && currentParticipant === participantCount - 1
                ? "다음 단계 →"
                : "다음 →"}
            </Text>
          </Pressable>
        </View>
      )}
    </ScreenContainer>
  );
}
