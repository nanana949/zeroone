import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const ALARMS = [
  {
    id: 1,
    time: "08:00",
    type: "아침",
    message: "좋은 아침! 오늘 아침은 계란 토스트 어때요?",
    enabled: true,
  },
  {
    id: 2,
    time: "12:00",
    type: "점심",
    message: "점심 시간이에요! 돈까스 추천해요 🍖",
    enabled: true,
  },
  {
    id: 3,
    time: "18:00",
    type: "저녁",
    message: "저녁 메뉴 고민 중이신가요? 스파게티는 어때요?",
    enabled: false,
  },
];

export default function SmartAlarmScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    alarmCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            🔔 스마트 알림
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            최적의 시간에 맞춤 알림을 받으세요
          </Text>

          {ALARMS.map((alarm) => (
            <View key={alarm.id} style={styles.alarmCard}>
              <View style={{ flexDirection: "row", alignItems: "flex-start", marginBottom: 10 }}>
                <View
                  style={{
                    width: 50,
                    height: 50,
                    borderRadius: 12,
                    backgroundColor: colors.primary + "20",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Text style={{ fontSize: 20, fontWeight: "700", color: colors.primary }}>
                    {alarm.time}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>
                    {alarm.type} 알림
                  </Text>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 10,
                      backgroundColor: alarm.enabled ? colors.success : colors.border,
                      marginTop: 8,
                    }}
                  />
                </View>
              </View>
              <Text style={{ fontSize: 12, color: colors.muted, lineHeight: 16 }}>
                {alarm.message}
              </Text>
            </View>
          ))}

          <Pressable
            style={{
              marginTop: 20,
              paddingVertical: 12,
              paddingHorizontal: 16,
              backgroundColor: colors.primary,
              borderRadius: 12,
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: "700", color: "#fff" }}>
              알림 설정 수정
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
