import { useState } from "react";
import { ScrollView, Text, View, Pressable, Platform } from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  type WeatherType,
  type TimeSlot,
  type DayType,
  type CategoryScore,
  WEATHER_OPTIONS,
  TIME_OPTIONS,
  DAY_OPTIONS,
  WEATHER_EMOJI,
  TIME_EMOJI,
  DAY_EMOJI,
  CATEGORY_EMOJI,
  calculateCategoryScores,
} from "@/lib/category-weights";
import {
  type FoodCategory,
  CATEGORY_BUTTON_CONFIG,
  CATEGORY_MENUS,
  filterMenusByTags,
  type TaggedMenu,
} from "@/lib/category-menu-db";

type Step = "weather" | "time" | "day" | "result" | "menu-filter" | "menu-result";

// ─── 공통 버튼 ──────────────────────────────────────────────────────

function SelectButton({
  label,
  emoji,
  isSelected,
  onPress,
}: {
  label: string;
  emoji?: string;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        minWidth: "42%",
        borderRadius: 16,
        paddingVertical: 18,
        paddingHorizontal: 12,
        alignItems: "center" as const,
        justifyContent: "center" as const,
        backgroundColor: isSelected ? colors.primary : colors.surface,
        borderWidth: isSelected ? 0 : 1.5,
        borderColor: isSelected ? "transparent" : colors.border,
        marginHorizontal: 5,
        marginVertical: 5,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: isSelected ? 4 : 2 },
        shadowOpacity: isSelected ? 0.25 : 0.06,
        shadowRadius: isSelected ? 8 : 4,
        elevation: isSelected ? 6 : 2,
        transform: [{ scale: pressed ? 0.96 : 1 }],
        opacity: pressed ? 0.9 : 1,
      })}
    >
      {emoji ? <Text style={{ fontSize: 28, marginBottom: 6 }}>{emoji}</Text> : null}
      <Text
        style={{
          fontSize: 14,
          fontWeight: "700",
          color: isSelected ? "#FFFFFF" : colors.foreground,
          textAlign: "center",
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 카테고리 결과 카드 ─────────────────────────────────────────────

function CategoryResultCard({
  rank,
  item,
  isTop,
  onSelect,
}: {
  rank: number;
  item: CategoryScore;
  isTop: boolean;
  onSelect: (category: FoodCategory) => void;
}) {
  const colors = useColors();
  const medal = rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `${rank}위`;

  return (
    <Pressable
      onPress={() => onSelect(item.category as FoodCategory)}
      style={({ pressed }) => ({
        backgroundColor: isTop ? `${colors.primary}12` : colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 10,
        borderWidth: isTop ? 1.5 : 1,
        borderColor: isTop ? `${colors.primary}40` : colors.border,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        elevation: 2,
        transform: [{ scale: pressed ? 0.98 : 1 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Text style={{ fontSize: isTop ? 32 : 26 }}>{CATEGORY_EMOJI[item.category]}</Text>
          <View>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <Text style={{ fontSize: 16 }}>{medal}</Text>
              <Text style={{ fontSize: isTop ? 17 : 15, fontWeight: "700", color: colors.foreground }}>
                {item.category}
              </Text>
            </View>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
              날씨 {item.weatherScore >= 0 ? "+" : ""}{item.weatherScore} · 시간 {item.timeScore >= 0 ? "+" : ""}{item.timeScore} · 요일 {item.dayScore >= 0 ? "+" : ""}{item.dayScore}
            </Text>
          </View>
        </View>
        <View style={{ alignItems: "flex-end", gap: 4 }}>
          <View
            style={{
              backgroundColor: isTop ? colors.primary : `${colors.primary}20`,
              borderRadius: 12,
              paddingHorizontal: 12,
              paddingVertical: 6,
            }}
          >
            <Text style={{ fontSize: 16, fontWeight: "800", color: isTop ? "#FFFFFF" : colors.primary }}>
              {item.score}점
            </Text>
          </View>
          <Text style={{ fontSize: 11, color: colors.muted }}>탭하여 메뉴 보기 →</Text>
        </View>
      </View>
    </Pressable>
  );
}

// ─── 필터 버튼 (작은 크기) ──────────────────────────────────────────

function FilterChip({
  label,
  isSelected,
  onPress,
}: {
  label: string;
  isSelected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        borderRadius: 20,
        paddingVertical: 8,
        paddingHorizontal: 14,
        backgroundColor: isSelected ? colors.primary : colors.surface,
        borderWidth: 1,
        borderColor: isSelected ? "transparent" : colors.border,
        marginRight: 8,
        marginBottom: 8,
        transform: [{ scale: pressed ? 0.95 : 1 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <Text style={{ fontSize: 13, fontWeight: "600", color: isSelected ? "#FFFFFF" : colors.foreground }}>
        {label}
      </Text>
    </Pressable>
  );
}

// ─── 메뉴 카드 ─────────────────────────────────────────────────────

function SingleMenuCard({
  menu,
  currentIndex,
  total,
  category,
  onFindRestaurant,
}: {
  menu: TaggedMenu;
  currentIndex: number;
  total: number;
  category: FoodCategory;
  onFindRestaurant: (menuName: string) => void;
}) {
  const colors = useColors();
  const tagEntries = Object.entries(menu.tags);

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 20,
        padding: 24,
        borderWidth: 1.5,
        borderColor: `${colors.primary}30`,
        shadowColor: colors.primary,
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.12,
        shadowRadius: 16,
        elevation: 6,
      }}
    >
      {/* 카테고리 + 순서 */}
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 18 }}>{CATEGORY_EMOJI[category]}</Text>
          <Text style={{ fontSize: 13, color: colors.muted, fontWeight: "600" }}>{category}</Text>
        </View>
        <Text style={{ fontSize: 12, color: colors.muted }}>{currentIndex + 1} / {total}</Text>
      </View>

      {/* 메뉴 이름 */}
      <Text style={{ fontSize: 32, fontWeight: "900", color: colors.foreground, textAlign: "center", marginBottom: 20, letterSpacing: -0.5 }}>
        {menu.name}
      </Text>

      {/* 추천 이유 */}
      {menu.reason && (
        <View
          style={{
            backgroundColor: `${colors.primary}08`,
            borderRadius: 12,
            padding: 14,
            marginBottom: 16,
            borderLeftWidth: 3,
            borderLeftColor: colors.primary,
          }}
        >
          <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "700", marginBottom: 4 }}>💡 추천 이유</Text>
          <Text style={{ fontSize: 13, color: colors.foreground, lineHeight: 20 }}>{menu.reason}</Text>
        </View>
      )}

      {/* 속성 태그 */}
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center", marginBottom: 20 }}>
        {tagEntries.map(([key, value]) => (
          <View
            key={key}
            style={{
              backgroundColor: `${colors.primary}15`,
              borderRadius: 20,
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderWidth: 1,
              borderColor: `${colors.primary}25`,
            }}
          >
            <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "700" }}>
              {value}
            </Text>
          </View>
        ))}
      </View>

      {/* 식당 찾기 버튼 */}
      <Pressable
        onPress={() => onFindRestaurant(menu.name)}
        style={({ pressed }) => ({
          backgroundColor: `${colors.primary}12`,
          borderRadius: 12,
          paddingVertical: 12,
          alignItems: "center" as const,
          borderWidth: 1,
          borderColor: `${colors.primary}30`,
          transform: [{ scale: pressed ? 0.97 : 1 }],
          opacity: pressed ? 0.85 : 1,
        })}
      >
        <Text style={{ fontSize: 14, color: colors.primary, fontWeight: "700" }}>🏪 이 메뉴 파는 식당 찾기</Text>
      </Pressable>
    </View>
  );
}

// ─── 메인 화면 ─────────────────────────────────────────────────────

export default function CustomRecommendationScreen() {
  const colors = useColors();
  const router = useRouter();
  const [step, setStep] = useState<Step>("weather");
  const [selectedWeather, setSelectedWeather] = useState<WeatherType | null>(null);
  const [selectedTime, setSelectedTime] = useState<TimeSlot | null>(null);
  const [selectedDay, setSelectedDay] = useState<DayType | null>(null);
  const [results, setResults] = useState<CategoryScore[]>([]);

  // 메뉴 필터 단계
  const [selectedCategory, setSelectedCategory] = useState<FoodCategory | null>(null);
  const [activeFilters, setActiveFilters] = useState<Record<string, string | null>>({});
  const [filteredMenus, setFilteredMenus] = useState<TaggedMenu[]>([]);
  const [currentMenuIndex, setCurrentMenuIndex] = useState(0);

  const haptic = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const goNext = () => {
    haptic();
    if (step === "weather") setStep("time");
    else if (step === "time") setStep("day");
    else if (step === "day") {
      setResults(calculateCategoryScores(selectedWeather, selectedTime, selectedDay));
      setStep("result");
    }
  };

  const goPrev = () => {
    haptic();
    if (step === "time") setStep("weather");
    else if (step === "day") setStep("time");
    else if (step === "result") setStep("day");
    else if (step === "menu-filter") setStep("result");
    else if (step === "menu-result") setStep("menu-filter");
  };

  const reset = () => {
    haptic();
    setStep("weather");
    setSelectedWeather(null);
    setSelectedTime(null);
    setSelectedDay(null);
    setResults([]);
    setSelectedCategory(null);
    setActiveFilters({});
    setFilteredMenus([]);
    setCurrentMenuIndex(0);
  };

  // 다른 메뉴 추천받기
  const nextMenu = () => {
    haptic();
    if (filteredMenus.length === 0) return;
    setCurrentMenuIndex((prev) => (prev + 1) % filteredMenus.length);
  };

  // 식당 탭으로 이동
  const goToRestaurant = (menuName: string) => {
    haptic();
    router.push({ pathname: "/(tabs)/restaurants", params: { recommendedMenu: menuName } } as any);
  };

  // 카테고리 선택 → 메뉴 필터 단계로
  const handleCategorySelect = (category: FoodCategory) => {
    haptic();
    setSelectedCategory(category);
    const sections = CATEGORY_BUTTON_CONFIG[category];
    const initialFilters: Record<string, string | null> = {};
    sections.forEach((s) => { initialFilters[s.sectionName] = null; });
    setActiveFilters(initialFilters);
    setStep("menu-filter");
  };

  // 필터 토글
  const toggleFilter = (sectionName: string, value: string) => {
    haptic();
    setActiveFilters((prev) => ({
      ...prev,
      [sectionName]: prev[sectionName] === value ? null : value,
    }));
  };

  // 메뉴 추천 실행
  const showMenuResults = () => {
    haptic();
    if (!selectedCategory) return;
    const menus = filterMenusByTags(selectedCategory, activeFilters);
    // 랜덤 순서로 섞기
    const shuffled = [...menus].sort(() => Math.random() - 0.5);
    setFilteredMenus(shuffled);
    setCurrentMenuIndex(0);
    setStep("menu-result");
  };

  const progress = step === "weather" ? 1 : step === "time" ? 2 : step === "day" ? 3 : 4;

  const stepTitle: Record<Step, string> = {
    weather: "오늘 날씨는 어때요?",
    time: "지금 시간대는?",
    day: "오늘은 무슨 요일?",
    result: "추천 카테고리 순위",
    "menu-filter": `${selectedCategory ?? ""} 메뉴 필터`,
    "menu-result": `${selectedCategory ?? ""} 추천 메뉴`,
  };

  const stepSub: Record<Step, string> = {
    weather: "날씨에 맞는 음식을 추천해드릴게요",
    time: "시간대에 어울리는 메뉴를 찾아볼게요",
    day: "요일에 따라 점수가 달라져요",
    result: "카테고리를 탭하면 메뉴를 볼 수 있어요",
    "menu-filter": "원하는 조건을 선택하세요 (복수 선택 가능)",
    "menu-result": `총 ${filteredMenus.length}개의 메뉴가 있어요`,
  };

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>

        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 }}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({
              flexDirection: "row" as const,
              alignItems: "center" as const,
              marginBottom: 12,
              opacity: pressed ? 0.6 : 1,
              alignSelf: "flex-start" as const,
            })}
          >
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>
          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground }}>🎯 맞춤추천</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>
            조건을 선택하면 최적의 카테고리와 메뉴를 추천해드려요
          </Text>
        </View>

        {/* 진행 바 (카테고리 단계까지만) */}
        {(step === "weather" || step === "time" || step === "day" || step === "result") && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <View style={{ height: 4, backgroundColor: `${colors.primary}20`, borderRadius: 2, overflow: "hidden" }}>
              <View style={{ height: "100%", width: `${(progress / 4) * 100}%`, backgroundColor: colors.primary, borderRadius: 2 }} />
            </View>
            <Text style={{ fontSize: 11, color: colors.muted, marginTop: 4, textAlign: "right" }}>{progress} / 4</Text>
          </View>
        )}

        {/* 스텝 제목 */}
        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground }}>{stepTitle[step]}</Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>{stepSub[step]}</Text>
        </View>

        {/* ── 날씨 선택 ── */}
        {step === "weather" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {WEATHER_OPTIONS.map((w) => (
                <SelectButton
                  key={w}
                  label={w}
                  emoji={WEATHER_EMOJI[w]}
                  isSelected={selectedWeather === w}
                  onPress={() => { haptic(); setSelectedWeather(selectedWeather === w ? null : w); }}
                />
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedWeather(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedWeather === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 시간대 선택 ── */}
        {step === "time" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {TIME_OPTIONS.map((t) => (
                <SelectButton
                  key={t}
                  label={t}
                  emoji={TIME_EMOJI[t]}
                  isSelected={selectedTime === t}
                  onPress={() => { haptic(); setSelectedTime(selectedTime === t ? null : t); }}
                />
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedTime(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedTime === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 요일 선택 ── */}
        {step === "day" && (
          <View style={{ paddingHorizontal: 14 }}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
              {DAY_OPTIONS.map((d) => (
                <SelectButton
                  key={d}
                  label={d}
                  emoji={DAY_EMOJI[d]}
                  isSelected={selectedDay === d}
                  onPress={() => { haptic(); setSelectedDay(selectedDay === d ? null : d); }}
                />
              ))}
            </View>
            <Pressable
              onPress={() => { haptic(); setSelectedDay(null); }}
              style={({ pressed }) => ({ marginTop: 12, alignSelf: "center" as const, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 20, backgroundColor: selectedDay === null ? `${colors.primary}15` : "transparent", opacity: pressed ? 0.7 : 1 })}
            >
              <Text style={{ fontSize: 14, color: colors.muted, fontWeight: "500" }}>상관없음 (건너뛰기)</Text>
            </Pressable>
          </View>
        )}

        {/* ── 카테고리 결과 ── */}
        {step === "result" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 선택 조건 요약 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 12, fontWeight: "600", color: colors.muted, marginBottom: 6 }}>선택한 조건</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                <Text style={{ fontSize: 13, color: colors.foreground }}>
                  {selectedWeather ? `${WEATHER_EMOJI[selectedWeather]} ${selectedWeather}` : "날씨 미선택"}
                </Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>·</Text>
                <Text style={{ fontSize: 13, color: colors.foreground }}>
                  {selectedTime ? `${TIME_EMOJI[selectedTime]} ${selectedTime}` : "시간 미선택"}
                </Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>·</Text>
                <Text style={{ fontSize: 13, color: colors.foreground }}>
                  {selectedDay ? `${DAY_EMOJI[selectedDay]} ${selectedDay}` : "요일 미선택"}
                </Text>
              </View>
            </View>

            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 12, textAlign: "center" }}>
              👇 카테고리를 탭하면 세부 메뉴를 볼 수 있어요
            </Text>

            {results.map((item, index) => (
              <CategoryResultCard
                key={item.category}
                rank={index + 1}
                item={item}
                isTop={index < 3}
                onSelect={handleCategorySelect}
              />
            ))}
          </View>
        )}

        {/* ── 메뉴 필터 ── */}
        {step === "menu-filter" && selectedCategory && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 카테고리 뱃지 */}
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 20, backgroundColor: `${colors.primary}12`, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: `${colors.primary}25` }}>
              <Text style={{ fontSize: 22 }}>{CATEGORY_EMOJI[selectedCategory]}</Text>
              <View>
                <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>{selectedCategory}</Text>
                <Text style={{ fontSize: 12, color: colors.muted }}>총 {CATEGORY_MENUS[selectedCategory]?.length ?? 0}개 메뉴</Text>
              </View>
            </View>

            {/* 섹션별 필터 */}
            {CATEGORY_BUTTON_CONFIG[selectedCategory].map((section) => (
              <View key={section.sectionName} style={{ marginBottom: 20 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginBottom: 10 }}>
                  {section.sectionName}
                </Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                  {/* 상관없음 칩 */}
                  <FilterChip
                    label="상관없음"
                    isSelected={activeFilters[section.sectionName] === null}
                    onPress={() => toggleFilter(section.sectionName, activeFilters[section.sectionName] ?? "")}
                  />
                  {section.buttons.map((btn) => (
                    <FilterChip
                      key={btn}
                      label={btn}
                      isSelected={activeFilters[section.sectionName] === btn}
                      onPress={() => toggleFilter(section.sectionName, btn)}
                    />
                  ))}
                </View>
              </View>
            ))}

            {/* 예상 결과 수 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 10, padding: 12, marginBottom: 4, alignItems: "center" }}>
              <Text style={{ fontSize: 14, color: colors.primary, fontWeight: "600" }}>
                예상 결과: {filterMenusByTags(selectedCategory, activeFilters).length}개 메뉴
              </Text>
            </View>
          </View>
        )}

        {/* ── 메뉴 결과 ── */}
        {step === "menu-result" && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* 적용된 필터 요약 */}
            <View style={{ backgroundColor: `${colors.primary}08`, borderRadius: 12, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
              <Text style={{ fontSize: 12, fontWeight: "600", color: colors.muted, marginBottom: 6 }}>적용된 필터</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {Object.entries(activeFilters).map(([key, val]) =>
                  val ? (
                    <View key={key} style={{ backgroundColor: `${colors.primary}20`, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                      <Text style={{ fontSize: 12, color: colors.primary, fontWeight: "600" }}>{key}: {val}</Text>
                    </View>
                  ) : null
                )}
                {Object.values(activeFilters).every((v) => !v) && (
                  <Text style={{ fontSize: 13, color: colors.muted }}>필터 없음 (전체)</Text>
                )}
              </View>
            </View>

            {filteredMenus.length === 0 ? (
              <View style={{ alignItems: "center", paddingVertical: 40 }}>
                <Text style={{ fontSize: 40, marginBottom: 12 }}>😅</Text>
                <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 6 }}>조건에 맞는 메뉴가 없어요</Text>
                <Text style={{ fontSize: 14, color: colors.muted, textAlign: "center" }}>필터를 조정해보세요</Text>
              </View>
            ) : (
              <SingleMenuCard
                menu={filteredMenus[currentMenuIndex]}
                currentIndex={currentMenuIndex}
                total={filteredMenus.length}
                category={selectedCategory!}
                onFindRestaurant={goToRestaurant}
              />
            )}
          </View>
        )}

        {/* ── 하단 버튼 ── */}
        <View style={{ paddingHorizontal: 20, marginTop: 28, gap: 10 }}>
          {/* 카테고리 선택 단계 */}
          {(step === "weather" || step === "time" || step === "day") && (
            <>
              <Pressable
                onPress={goNext}
                style={({ pressed }) => ({
                  backgroundColor: colors.primary,
                  borderRadius: 14,
                  paddingVertical: 16,
                  alignItems: "center" as const,
                  shadowColor: colors.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 4,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                  opacity: pressed ? 0.9 : 1,
                })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>
                  {step === "day" ? "결과 보기 →" : "다음 →"}
                </Text>
              </Pressable>
              {step !== "weather" && (
                <Pressable
                  onPress={goPrev}
                  style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
                >
                  <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 이전</Text>
                </Pressable>
              )}
            </>
          )}

          {/* 카테고리 결과 단계 */}
          {step === "result" && (
            <>
              <Pressable
                onPress={reset}
                style={({ pressed }) => ({
                  backgroundColor: colors.primary,
                  borderRadius: 14,
                  paddingVertical: 16,
                  alignItems: "center" as const,
                  shadowColor: colors.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 4,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                  opacity: pressed ? 0.9 : 1,
                })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>🔄 다시 추천받기</Text>
              </Pressable>
              <Pressable
                onPress={goPrev}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 조건 수정</Text>
              </Pressable>
            </>
          )}

          {/* 메뉴 필터 단계 */}
          {step === "menu-filter" && (
            <>
              <Pressable
                onPress={showMenuResults}
                style={({ pressed }) => ({
                  backgroundColor: colors.primary,
                  borderRadius: 14,
                  paddingVertical: 16,
                  alignItems: "center" as const,
                  shadowColor: colors.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 4,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                  opacity: pressed ? 0.9 : 1,
                })}
              >
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>메뉴 추천받기 →</Text>
              </Pressable>
              <Pressable
                onPress={goPrev}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 카테고리 순위로</Text>
              </Pressable>
            </>
          )}

          {/* 메뉴 결과 단계 */}
          {step === "menu-result" && (
            <>
              {filteredMenus.length > 1 && (
                <Pressable
                  onPress={nextMenu}
                  style={({ pressed }) => ({
                    backgroundColor: colors.primary,
                    borderRadius: 14,
                    paddingVertical: 16,
                    alignItems: "center" as const,
                    shadowColor: colors.primary,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.3,
                    shadowRadius: 8,
                    elevation: 4,
                    transform: [{ scale: pressed ? 0.97 : 1 }],
                    opacity: pressed ? 0.9 : 1,
                  })}
                >
                  <Text style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>🔀 다른 메뉴 추천받기</Text>
                </Pressable>
              )}
              <Pressable
                onPress={goPrev}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>← 필터 수정</Text>
              </Pressable>
              <Pressable
                onPress={reset}
                style={({ pressed }) => ({ backgroundColor: colors.surface, borderRadius: 14, paddingVertical: 14, alignItems: "center" as const, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.7 : 1 })}
              >
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.muted }}>🔄 처음부터 다시</Text>
              </Pressable>
            </>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
