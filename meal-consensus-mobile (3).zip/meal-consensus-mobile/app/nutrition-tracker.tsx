import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function NutritionTrackerScreen() {
  const colors = useColors();
  const router = useRouter();

  const styles = StyleSheet.create({
    statBox: {
      flex: 1,
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginHorizontal: 6,
      marginBottom: 12,
      alignItems: "center",
      borderWidth: 1,
      borderColor: colors.border,
    },
  });

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground, marginBottom: 8 }}>
            📊 영양 추적
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, marginBottom: 20 }}>
            오늘의 영양 정보를 확인하세요
          </Text>

          <View style={{ marginBottom: 24 }}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
              오늘 섭취량
            </Text>
            <View style={{ flexDirection: "row", marginBottom: 12 }}>
              <View style={styles.statBox}>
                <Text style={{ fontSize: 24, fontWeight: "700", color: colors.primary }}>1,850</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>칼로리</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={{ fontSize: 24, fontWeight: "700", color: "#4CAF50" }}>65g</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>단백질</Text>
              </View>
            </View>
            <View style={{ flexDirection: "row" }}>
              <View style={styles.statBox}>
                <Text style={{ fontSize: 24, fontWeight: "700", color: "#FF9800" }}>220g</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>탄수화물</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={{ fontSize: 24, fontWeight: "700", color: "#E91E63" }}>45g</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>지방</Text>
              </View>
            </View>
          </View>

          <View>
            <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
              식사 기록
            </Text>
            <View style={{ backgroundColor: colors.surface, borderRadius: 12, padding: 14, borderWidth: 1, borderColor: colors.border }}>
              <Text style={{ fontSize: 13, fontWeight: "600", color: colors.foreground }}>아침: 계란 토스트</Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>350 kcal</Text>
              <Text style={{ fontSize: 13, fontWeight: "600", color: colors.foreground, marginTop: 12 }}>점심: 돈까스</Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>800 kcal</Text>
              <Text style={{ fontSize: 13, fontWeight: "600", color: colors.foreground, marginTop: 12 }}>저녁: 스파게티</Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>700 kcal</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
