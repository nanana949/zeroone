import { View, Text, Pressable, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const haptic = () => {
  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
};

export default function HomeCookingHubScreen() {
  const colors = useColors();
  const router = useRouter();

  const modes = [
    {
      id: "fridge",
      emoji: "🍳",
      title: "냉장고 모드",
      subtitle: "지금 있는 재료로 만들 수 있는 집밥 추천",
      description: "냉장고에 있는 재료를 선택하면\n매칭률 높은 레시피를 추천해드려요",
      color: "#FFF0D6",
      borderColor: "#F59E0B",
      steps: ["재료 선택", "날씨·시간·요일", "카테고리 추천", "메뉴 추천"],
      route: "/fridge-mode",
    },
    {
      id: "shopping",
      emoji: "🛒",
      title: "장보기 모드",
      subtitle: "먹고 싶은 메뉴를 정하고 장보기 리스트 생성",
      description: "메뉴를 먼저 정하면\n마트 동선에 맞는 장보기 리스트를 만들어드려요",
      color: "#E8F4FD",
      borderColor: "#3B82F6",
      steps: ["날씨·시간·요일", "카테고리 추천", "난이도·메뉴 선택", "인분 선택", "장보기 리스트"],
      route: "/shopping-mode",
    },
  ];

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>

        {/* 헤더 */}
        <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => ({
              flexDirection: "row" as const,
              alignItems: "center" as const,
              marginBottom: 20,
              opacity: pressed ? 0.6 : 1,
              alignSelf: "flex-start" as const,
            })}
          >
            <Text style={{ fontSize: 16, color: colors.primary, fontWeight: "600" }}>← 돌아가기</Text>
          </Pressable>

          {/* 타이틀 */}
          <View style={{ alignItems: "center", marginBottom: 8 }}>
            <Text style={{ fontSize: 40, marginBottom: 8 }}>🏠</Text>
            <Text style={{ fontSize: 28, fontWeight: "900", color: colors.foreground, textAlign: "center" }}>
              집밥 모드
            </Text>
            <Text style={{ fontSize: 15, color: colors.muted, marginTop: 8, textAlign: "center", lineHeight: 22 }}>
              오늘은 어떤 방식으로{"\n"}집밥을 준비할까요?
            </Text>
          </View>
        </View>

        {/* 구분선 */}
        <View style={{ height: 1, backgroundColor: colors.border, marginHorizontal: 20, marginBottom: 24 }} />

        {/* 모드 카드 */}
        <View style={{ paddingHorizontal: 20, gap: 16 }}>
          {modes.map((mode) => (
            <Pressable
              key={mode.id}
              onPress={() => { haptic(); router.push(mode.route as any); }}
              style={({ pressed }) => ({
                backgroundColor: mode.color,
                borderRadius: 24,
                padding: 24,
                borderWidth: 2,
                borderColor: pressed ? mode.borderColor : `${mode.borderColor}60`,
                shadowColor: mode.borderColor,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: pressed ? 0.25 : 0.12,
                shadowRadius: 12,
                elevation: pressed ? 6 : 3,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              })}
            >
              {/* 이모지 + 제목 */}
              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
                <Text style={{ fontSize: 40, marginRight: 14 }}>{mode.emoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 22, fontWeight: "900", color: "#1a1a1a" }}>{mode.title}</Text>
                  <Text style={{ fontSize: 13, color: "#555", marginTop: 2, fontWeight: "500" }}>{mode.subtitle}</Text>
                </View>
                <Text style={{ fontSize: 22, color: mode.borderColor }}>→</Text>
              </View>

              {/* 설명 */}
              <View style={{ backgroundColor: "rgba(255,255,255,0.6)", borderRadius: 12, padding: 14, marginBottom: 14 }}>
                <Text style={{ fontSize: 14, color: "#333", lineHeight: 22 }}>{mode.description}</Text>
              </View>

              {/* 진행 단계 */}
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {mode.steps.map((step, idx) => (
                  <View key={idx} style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                    <View style={{ backgroundColor: mode.borderColor, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4 }}>
                      <Text style={{ fontSize: 11, color: "#FFFFFF", fontWeight: "700" }}>{step}</Text>
                    </View>
                    {idx < mode.steps.length - 1 && (
                      <Text style={{ fontSize: 11, color: "#999" }}>›</Text>
                    )}
                  </View>
                ))}
              </View>
            </Pressable>
          ))}
        </View>

        {/* 하단 안내 */}
        <View style={{ marginHorizontal: 20, marginTop: 28, backgroundColor: `${colors.primary}08`, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: `${colors.primary}20` }}>
          <Text style={{ fontSize: 13, color: colors.muted, lineHeight: 20, textAlign: "center" }}>
            💡 <Text style={{ fontWeight: "700", color: colors.primary }}>냉장고 모드</Text>는 지금 있는 재료로 만들 수 있는 메뉴를,{"\n"}
            <Text style={{ fontWeight: "700", color: "#3B82F6" }}>장보기 모드</Text>는 먹고 싶은 메뉴의 재료 목록을 알려드려요
          </Text>
        </View>

      </ScrollView>
    </ScreenContainer>
  );
}
