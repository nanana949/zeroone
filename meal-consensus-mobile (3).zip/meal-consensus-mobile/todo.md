# 메뉴메이트 AI — Project TODO

## Phase 1: 식사 후기 & 별점 시스템 ✅
- [x] MealReview 타입 정의 (별점, 맛, 양, 가성비, 분위기, 태그, 메모)
- [x] 후기 모달 컴포넌트 구현 (MealReviewModal)
- [x] 후기 저장 및 로드 함수 (updateMealReview)
- [x] 영양 정보 데이터베이스 추가 (NUTRITION_DATABASE)
- [x] 영양 정보 카드 컴포넌트 (NutritionCard)

## Phase 2: 소셜 & 참여도 기능 ✅
- [x] 빠른 결정 모드 화면 (QuickDecisionScreen)
  - 6가지 모드 (랜덤, 저예산, 건강식, 푸짐, 새로운 맛, 위로 음식)
  - 1초 추천 기능
  - 스와이프로 다음 추천 보기
- [x] 프리미엄 기능 화면 (PremiumScreen)
  - 프리미엄 상태 표시
  - 4가지 프리미엄 기능 소개
  - 월간 구독료 표시
  - FAQ 섹션
- [x] 탭 네비게이션 업데이트 (5탭 → 5탭 재구성)
- [x] 프리미엄 기능 타입 및 저장소 추가

## Phase 3: 고도화 ✅
- [x] 고도화된 자연어 처리 (AdvancedNLP)
  - 12가지 컨디션 감지 (피곤, 스트레스, 행복, 슬픔, 신남, 지루, 아픔, 배고픔, 귀찮음, 축하, 데이트, 팀)
  - 예산 파싱 (만원, 천원, 원 단위)
  - 건강 선호도 감지 (건강식, 푸짐함, 일반)
  - 기분 점수 계산 (-1 ~ 1)
  - 신뢰도 계산 (0 ~ 1)
  - 입력 품질 평가 (poor, fair, good, excellent)
- [x] 자연어 처리 통합 테스트 (19개 테스트)

## 테스트 ✅
- [x] 합의 엔진 테스트 (15개 통과)
- [x] 자연어 파싱 테스트 (15개 통과)
- [x] 고도화된 NLP 테스트 (19개 통과)
- [x] 총 34개 테스트 모두 통과

## 아키텍처 & 데이터 모델 ✅
- [x] MealReview 인터페이스 추가
- [x] PremiumFeature 인터페이스 추가
- [x] NutritionInfo 인터페이스 추가
- [x] AppState에 프리미엄 필드 추가
- [x] 영양 정보 데이터베이스 (8개 메뉴)

## UI 컴포넌트 ✅
- [x] MealReviewModal (후기 작성 모달)
- [x] NutritionCard (영양 정보 표시)
- [x] QuickDecisionScreen (빠른 결정 화면)
- [x] PremiumScreen (프리미엄 화면)

## 유틸리티 함수 ✅
- [x] updateMealReview (후기 업데이트)
- [x] loadPremiumFeatures (프리미엄 기능 로드)
- [x] savePremiumFeatures (프리미엄 기능 저장)
- [x] loadIsPremiumUser (프리미엄 여부 로드)
- [x] setIsPremiumUser (프리미엄 여부 설정)
- [x] getDefaultPremiumFeatures (기본 프리미엄 기능)
- [x] analyzeAdvancedNLP (고도화된 자연어 분석)
- [x] calculateRecommendationConfidence (추천 신뢰도)
- [x] evaluateInputQuality (입력 품질 평가)

## 최종 점검 ✅
- [x] 모든 타입스크립트 오류 해결
- [x] 모든 테스트 통과 (34/34)
- [x] 빈 onPress 핸들러 없음
- [x] 모든 화면 라우트 설정
- [x] 탭 아이콘 매핑 완료

## Phase 4: 5개 탭 구조 재설계 및 홈 화면 개선 ✅
- [x] 탭 구조 최적화 (5개: 홈, AI 추천, 식당, 건강, 커뮤니티)
- [x] 홈 화면 UI 개선 (라면/국물 테마 강화)
- [x] 각 탭 기본 레이아웃 구성
  - AI 추천 탭 (6가지 추천 모드)
  - 식당 탭 (위치 기반, 배달앱, 예약)
  - 건강 탭 (칼로리, 영양소, 알레르기)
  - 커뮤니티 탭 (피드, 투표, 랭킹)

## Phase 5: AI 추천 엔진 고도화 (부분 완료)
- [x] 음식 월드컵 결과 → 식당 탭 연동 (recommendedMenu 파라미터)
- [x] 카테고리별 필터링 완성 (한식, 중식, 일식, 양식, 고기, 치킨, 피자, 카페)
- [ ] 개인 맞춤 추천 (취향, 식이제한, 기분, 날씨, 시간대 분석)
- [ ] 랜덤 추천 (룰렛 인터페이스)
- [ ] 냉장고 레시피 (재료 입력/카메라 인식 → 요리 추천)
- [ ] Gemini AI 통합 (자연어 기반 대화형 추천)

## Phase 6: 식당 & 배달 기능
- [ ] 위치 기반 주변 식당 탐색 (지도 표시)
- [ ] 배달앱 통합 (배민, 쿠팡이츠, 요기요 가격 비교)
- [ ] 실시간 웨이팅 & 예약 시스템
- [ ] 식당 평점 및 리뷰 표시

## Phase 7: 건강 & 식단 관리
- [ ] 칼로리 & 영양소 자동 분석 (메뉴 선택 시)
- [ ] 알레르기 & 식이 제한 필터
- [ ] 식습관 주간/월간 리포트 (그래프 시각화)
- [ ] 일일 목표 대비 영양 상태 표시

## Phase 8: 소셜 & 커뮤니티
- [ ] 친구 피드 (식사 기록, 레시피 공유, 맛집 후기)
- [ ] 그룹 투표 (친구들과 메뉴 결정)
- [ ] 맛집 랭킹 & 리뷰 (동네별, 카테고리별)
- [ ] 팔로우/언팔로우 기능

## Phase 9: 추가 기능
- [ ] 취향 학습 엔진 (피드백 기반 개선)
- [ ] 예산 기반 추천 (식비 범위 설정)
- [ ] 스마트 알림 (점심/저녁 시간대 맞춤 알림)
- [ ] 음식 사진 인식 (AI 기반 자동 기록)
- [ ] 주간 식단 플래너
- [ ] 재료 자동 쇼핑 리스트

## Phase 10: 백엔드 API 구축 ✅
- [x] PostgreSQL 데이터베이스 설계
  - [x] 식당 테이블 (id, name, category, address, rating, phone, delivery_time)
  - [x] 메뉴 테이블 (id, restaurant_id, name, price, calories, protein, carbs, fat, ingredients)
  - [x] 사용자 테이블 (id, email, password, preferences, allergies, location)
  - [x] 추천 기록 테이블 (id, user_id, menu_id, feedback, timestamp)
  - [x] 배달앱 연동 테이블 (restaurant_id, baemin_id, coupang_eats_id, yogiyo_id)
- [x] Node.js/Express API 서버 구현
  - [x] 식당 검색 API (/api/restaurants)
  - [x] 메뉴 추천 API (/api/recommendations)
  - [x] 사용자 프로필 API (/api/users)
  - [x] 피드백 저장 API (/api/feedback)
  - [x] 배달앱 가격 비교 API (/api/delivery-prices)
- [x] 실제 식당/메뉴 데이터 입력 (133개 용인 동백 식당)

## Phase 11: Gemini AI 통합 ✅
- [x] 각 결정 모드별 AI 프롬프트 작성
  - [x] 합의 모드 (그룹 투표 기반)
  - [x] AI 맞춤 추천 (기분, 날씨, 시간대 기반)
  - [x] 1초 결정 (빠른 선택)
  - [x] 냉장고 레시피 (재료 기반)
  - [x] 예산 추천 (가격대 기반)
- [x] Gemini API 연동 (실제 추천 로직)
- [x] 사용자 피드백 학습 시스템

## Phase 12: 위치 기반 서비스 ✅
- [x] Google Maps API 연동
- [x] 실시간 주변 식당 검색
- [x] 거리 계산 및 정렬
- [x] 지도 표시 (카테고리별 필터링)

## Phase 13: 배달앱 API 연동
- [ ] 배민 API 연동 (가격, 배달시간)
- [ ] 쿠팡이츠 API 연동
- [ ] 요기요 API 연동
- [ ] 실시간 가격 비교 기능

## Phase 14: 사용자 인증 및 프로필
- [ ] 로그인/회원가입 (OAuth 또는 이메일)
- [ ] 개인화 프로필 저장
- [ ] 취향/알레르기 설정
- [ ] 추천 기록 저장 및 조회

## Phase 15: 최종 테스트 및 배포
- [ ] 전체 기능 통합 테스트
- [ ] 성능 최적화
- [ ] 버그 수정
- [ ] App Store/Google Play 배포 준비

## 최종 마무리
- [ ] 전체 기능 통합 테스트
- [ ] UI/UX 최종 점검
- [ ] 성능 최적화
- [ ] 최종 체크포인트 저장
