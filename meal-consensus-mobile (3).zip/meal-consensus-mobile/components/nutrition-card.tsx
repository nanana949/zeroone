import React from "react";
import { View, Text } from "react-native";
import { useColors } from "@/hooks/use-colors";
import type { NutritionInfo } from "@/lib/store";

interface NutritionCardProps {
  nutrition: NutritionInfo;
}

export function NutritionCard({ nutrition }: NutritionCardProps) {
  const colors = useColors();

  const getNutrientColor = (nutrient: string, value: number) => {
    // 나트륨 경고 (1500mg 이상)
    if (nutrient === "sodium" && value >= 1500) return "#FF6B6B";
    // 지방 경고 (25g 이상)
    if (nutrient === "fat" && value >= 25) return "#FFA500";
    return colors.primary;
  };

  const nutrients = [
    { label: "칼로리", value: nutrition.calories, unit: "kcal", key: "calories" },
    { label: "단백질", value: nutrition.protein, unit: "g", key: "protein" },
    { label: "탄수화물", value: nutrition.carbs, unit: "g", key: "carbs" },
    { label: "지방", value: nutrition.fat, unit: "g", key: "fat" },
    { label: "나트륨", value: nutrition.sodium, unit: "mg", key: "sodium" },
  ];

  return (
    <View
      style={{
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderRadius: 12,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
        📊 영양 정보
      </Text>

      {/* Main Calories */}
      <View
        style={{
          paddingHorizontal: 12,
          paddingVertical: 12,
          borderRadius: 8,
          backgroundColor: colors.background,
          marginBottom: 12,
          borderLeftWidth: 4,
          borderLeftColor: colors.primary,
        }}
      >
        <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 4 }}>
          1회 제공량 기준
        </Text>
        <Text style={{ fontSize: 24, fontWeight: "700", color: colors.primary }}>
          {nutrition.calories}
        </Text>
        <Text style={{ fontSize: 12, color: colors.muted }}>kcal</Text>
      </View>

      {/* Nutrients Grid */}
      <View style={{ gap: 8 }}>
        {nutrients.slice(1).map((nutrient) => (
          <View
            key={nutrient.key}
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 12,
              paddingVertical: 10,
              borderRadius: 8,
              backgroundColor: colors.background,
            }}
          >
            <Text style={{ fontSize: 13, color: colors.foreground, fontWeight: "600" }}>
              {nutrient.label}
            </Text>
            <View style={{ flexDirection: "row", alignItems: "baseline", gap: 4 }}>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "700",
                  color: getNutrientColor(nutrient.key, nutrient.value),
                }}
              >
                {nutrient.value}
              </Text>
              <Text style={{ fontSize: 11, color: colors.muted }}>
                {nutrient.unit}
              </Text>
            </View>
          </View>
        ))}
      </View>

      {/* Warnings */}
      <View style={{ marginTop: 12, gap: 6 }}>
        {nutrition.sodium >= 1500 && (
          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 8,
              borderRadius: 6,
              backgroundColor: "rgba(255, 107, 107, 0.1)",
              borderLeftWidth: 3,
              borderLeftColor: "#FF6B6B",
            }}
          >
            <Text style={{ fontSize: 12, color: "#FF6B6B", fontWeight: "600" }}>
              ⚠️ 나트륨 주의: {nutrition.sodium}mg (권장량 초과)
            </Text>
          </View>
        )}
        {nutrition.fat >= 25 && (
          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 8,
              borderRadius: 6,
              backgroundColor: "rgba(255, 165, 0, 0.1)",
              borderLeftWidth: 3,
              borderLeftColor: "#FFA500",
            }}
          >
            <Text style={{ fontSize: 12, color: "#FFA500", fontWeight: "600" }}>
              ⚠️ 지방 주의: {nutrition.fat}g (권장량 초과)
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}
