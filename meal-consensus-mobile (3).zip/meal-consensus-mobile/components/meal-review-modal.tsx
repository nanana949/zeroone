import React, { useState } from "react";
import {
  Modal,
  View,
  Text,
  Pressable,
  ScrollView,
  TextInput,
  StyleSheet,
} from "react-native";
import { useColors } from "@/hooks/use-colors";
import type { MealReview } from "@/lib/store";

interface MealReviewModalProps {
  visible: boolean;
  menuName: string;
  onClose: () => void;
  onSubmit: (review: MealReview) => void;
}

const REVIEW_TAGS = [
  { id: "recommend", label: "추천", emoji: "👍" },
  { id: "again", label: "다시 먹고 싶어", emoji: "🔄" },
  { id: "notbad", label: "괜찮아", emoji: "😊" },
  { id: "disappointed", label: "별로였어", emoji: "😞" },
  { id: "expensive", label: "비싸", emoji: "💸" },
  { id: "cheap", label: "저렴해", emoji: "💰" },
];

export function MealReviewModal({
  visible,
  menuName,
  onClose,
  onSubmit,
}: MealReviewModalProps) {
  const colors = useColors();
  const [rating, setRating] = useState(3);
  const [taste, setTaste] = useState(3);
  const [quantity, setQuantity] = useState(3);
  const [price, setPrice] = useState(3);
  const [atmosphere, setAtmosphere] = useState(3);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [comment, setComment] = useState("");

  const handleTagToggle = (tagId: string) => {
    setSelectedTags((prev) =>
      prev.includes(tagId) ? prev.filter((t) => t !== tagId) : [...prev, tagId]
    );
  };

  const handleSubmit = () => {
    const review: MealReview = {
      rating,
      taste,
      quantity,
      price,
      atmosphere,
      tags: selectedTags,
      comment,
      createdAt: new Date().toISOString(),
    };
    onSubmit(review);
    onClose();
  };

  const RatingBar = ({
    label,
    value,
    onChange,
  }: {
    label: string;
    value: number;
    onChange: (v: number) => void;
  }) => (
    <View style={{ marginBottom: 16 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 8 }}>
        <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground }}>
          {label}
        </Text>
        <Text style={{ fontSize: 14, fontWeight: "700", color: colors.primary }}>
          {value}/5
        </Text>
      </View>
      <View style={{ flexDirection: "row", gap: 6 }}>
        {[1, 2, 3, 4, 5].map((star) => (
          <Pressable
            key={star}
            onPress={() => onChange(star)}
            style={({ pressed }) => [
              {
                flex: 1,
                paddingVertical: 10,
                borderRadius: 8,
                backgroundColor: star <= value ? colors.primary : colors.surface,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
          >
            <Text
              style={{
                textAlign: "center",
                fontSize: 16,
                fontWeight: "700",
                color: star <= value ? colors.background : colors.muted,
              }}
            >
              {star}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}>
        <View
          style={{
            flex: 1,
            marginTop: 60,
            backgroundColor: colors.background,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingHorizontal: 16,
            paddingVertical: 20,
          }}
        >
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Header */}
            <View style={{ marginBottom: 24 }}>
              <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground }}>
                "{menuName}" 평가하기
              </Text>
              <Text style={{ fontSize: 14, color: colors.muted, marginTop: 4 }}>
                당신의 솔직한 후기가 다른 사람들을 도와줍니다
              </Text>
            </View>

            {/* Overall Rating */}
            <View style={{ marginBottom: 24 }}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
                전체 만족도
              </Text>
              <View style={{ flexDirection: "row", justifyContent: "center", gap: 8 }}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <Pressable
                    key={star}
                    onPress={() => setRating(star)}
                    style={({ pressed }) => [
                      {
                        width: 50,
                        height: 50,
                        borderRadius: 25,
                        backgroundColor: star <= rating ? colors.primary : colors.surface,
                        justifyContent: "center",
                        alignItems: "center",
                        opacity: pressed ? 0.7 : 1,
                      },
                    ]}
                  >
                    <Text style={{ fontSize: 24 }}>⭐</Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Detailed Ratings */}
            <View style={{ marginBottom: 24 }}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
                세부 평가
              </Text>
              <RatingBar label="맛" value={taste} onChange={setTaste} />
              <RatingBar label="양" value={quantity} onChange={setQuantity} />
              <RatingBar label="가성비" value={price} onChange={setPrice} />
              <RatingBar label="분위기" value={atmosphere} onChange={setAtmosphere} />
            </View>

            {/* Tags */}
            <View style={{ marginBottom: 24 }}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
                태그 선택
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {REVIEW_TAGS.map((tag) => (
                  <Pressable
                    key={tag.id}
                    onPress={() => handleTagToggle(tag.id)}
                    style={({ pressed }) => [
                      {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 20,
                        backgroundColor: selectedTags.includes(tag.id)
                          ? colors.primary
                          : colors.surface,
                        borderWidth: 1,
                        borderColor: selectedTags.includes(tag.id)
                          ? colors.primary
                          : colors.border,
                        opacity: pressed ? 0.7 : 1,
                      },
                    ]}
                  >
                    <Text
                      style={{
                        fontSize: 13,
                        fontWeight: "600",
                        color: selectedTags.includes(tag.id)
                          ? colors.background
                          : colors.foreground,
                      }}
                    >
                      {tag.emoji} {tag.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Comment */}
            <View style={{ marginBottom: 24 }}>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
                한줄 메모
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 12,
                  paddingVertical: 10,
                  color: colors.foreground,
                  fontSize: 14,
                  minHeight: 60,
                  textAlignVertical: "top",
                }}
                placeholder="이 메뉴에 대해 한줄 평을 남겨주세요"
                placeholderTextColor={colors.muted}
                value={comment}
                onChangeText={setComment}
                multiline
                maxLength={200}
              />
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>
                {comment.length}/200
              </Text>
            </View>

            {/* Buttons */}
            <View style={{ flexDirection: "row", gap: 12, marginBottom: 20 }}>
              <Pressable
                onPress={onClose}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 12,
                    borderRadius: 12,
                    backgroundColor: colors.surface,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
              >
                <Text
                  style={{
                    textAlign: "center",
                    fontSize: 16,
                    fontWeight: "600",
                    color: colors.foreground,
                  }}
                >
                  취소
                </Text>
              </Pressable>
              <Pressable
                onPress={handleSubmit}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 12,
                    borderRadius: 12,
                    backgroundColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <Text
                  style={{
                    textAlign: "center",
                    fontSize: 16,
                    fontWeight: "600",
                    color: colors.background,
                  }}
                >
                  저장하기
                </Text>
              </Pressable>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
