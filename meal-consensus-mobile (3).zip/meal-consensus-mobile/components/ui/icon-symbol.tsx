// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

/**
 * Add your SF Symbols to Material Icons mappings here.
 * - see Material Icons in the [Icons Directory](https://icons.expo.fyi).
 * - see SF Symbols in the [SF Symbols](https://developer.apple.com/sf-symbols/) app.
 */
const MAPPING = {
  // Default
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  // App-specific
  "fork.knife": "restaurant",
  "person.2.fill": "group",
  "brain.head.profile": "psychology",
  "calendar": "calendar-month",
  "person.fill": "person",
  "sparkles": "auto-awesome",
  "checkmark.circle.fill": "check-circle",
  "xmark.circle.fill": "cancel",
  "plus.circle.fill": "add-circle",
  "minus.circle.fill": "remove-circle",
  "arrow.right.circle.fill": "arrow-circle-right",
  "location.fill": "location-on",
  "clock.fill": "schedule",
  "dollarsign.circle.fill": "attach-money",
  "star.fill": "star",
  "heart.fill": "favorite",
  "flame.fill": "local-fire-department",
  "leaf.fill": "eco",
  "bolt.fill": "bolt",
  "trophy.fill": "emoji-events",
  "map.fill": "map",
  "phone.fill": "phone",
  "square.and.arrow.up": "share",
  "chevron.left": "chevron-left",
  "chevron.down": "expand-more",
  "ellipsis": "more-horiz",
  "trash.fill": "delete",
  "pencil": "edit",
  "info.circle.fill": "info",
  "exclamationmark.triangle.fill": "warning",
} as IconMapping;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 * This ensures a consistent look across platforms, and optimal resource usage.
 * Icon `name`s are based on SF Symbols and require manual mapping to Material Icons.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
